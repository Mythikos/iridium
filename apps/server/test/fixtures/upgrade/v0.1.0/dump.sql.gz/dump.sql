-- MySQL dump 10.13  Distrib 9.7.2, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: iridium
-- ------------------------------------------------------
-- Server version	8.4.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE REPLICATION SOURCE TO SOURCE_LOG_FILE='binlog.000003', SOURCE_LOG_POS=168451;

--
-- Current Database: `iridium`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `iridium` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `iridium`;

--
-- Table structure for table `access_log`
--

DROP TABLE IF EXISTS `access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime(6) NOT NULL,
  `token_id` binary(16) DEFAULT NULL,
  `user_id` binary(16) NOT NULL,
  `surface` enum('mcp','rest','export','oauth') NOT NULL,
  `action` varchar(64) NOT NULL,
  `vault_id` binary(16) DEFAULT NULL,
  `note_ids` json DEFAULT NULL,
  `note_ids_truncated` tinyint(1) NOT NULL DEFAULT '0',
  `revision` bigint unsigned DEFAULT NULL,
  `status` enum('ok','denied','not_found','error','rate_limited') NOT NULL,
  `latency_ms` int unsigned NOT NULL,
  `bytes_out` int unsigned DEFAULT NULL,
  `client_name` varchar(64) DEFAULT NULL,
  `client_version` varchar(32) DEFAULT NULL,
  `ip` varbinary(16) DEFAULT NULL,
  `request_id` binary(16) DEFAULT NULL,
  `oauth_client_id` binary(16) DEFAULT NULL,
  PRIMARY KEY (`id`,`occurred_at`),
  KEY `ix_access_token_time` (`token_id`,`occurred_at`),
  KEY `ix_access_vault_time` (`vault_id`,`occurred_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
/*!50500 PARTITION BY RANGE  COLUMNS(occurred_at)
(PARTITION p2026_09 VALUES LESS THAN ('2026-10-01 00:00:00.000000') ENGINE = InnoDB,
 PARTITION p2026_10 VALUES LESS THAN ('2026-11-01 00:00:00.000000') ENGINE = InnoDB,
 PARTITION p_overflow VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_log`
--

LOCK TABLES `access_log` WRITE;
/*!40000 ALTER TABLE `access_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `access_token_vaults`
--

DROP TABLE IF EXISTS `access_token_vaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_token_vaults` (
  `token_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  PRIMARY KEY (`token_id`,`vault_id`),
  KEY `ix_atv_vault` (`vault_id`),
  CONSTRAINT `fk_atv_token` FOREIGN KEY (`token_id`) REFERENCES `access_tokens` (`id`),
  CONSTRAINT `fk_atv_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_token_vaults`
--

LOCK TABLES `access_token_vaults` WRITE;
/*!40000 ALTER TABLE `access_token_vaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_token_vaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `access_tokens`
--

DROP TABLE IF EXISTS `access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_tokens` (
  `id` binary(16) NOT NULL,
  `token_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `kind` enum('pat','oauth','scim') NOT NULL DEFAULT 'pat',
  `name` varchar(120) NOT NULL,
  `display_prefix` char(26) NOT NULL,
  `scopes` json NOT NULL,
  `all_vaults` tinyint(1) NOT NULL DEFAULT '0',
  `admin_owned` tinyint(1) NOT NULL DEFAULT '0',
  `expires_at` datetime(6) NOT NULL,
  `last_used_at` datetime(6) DEFAULT NULL,
  `last_used_ip` varbinary(16) DEFAULT NULL,
  `last_client` varchar(120) DEFAULT NULL,
  `rate_limit_per_hour` int unsigned DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `created_from_session_id` binary(16) DEFAULT NULL,
  `created_ip` varbinary(16) DEFAULT NULL,
  `created_user_agent` varchar(255) DEFAULT NULL,
  `rotated_from_id` binary(16) DEFAULT NULL,
  `rotation_overlap_until` datetime(6) DEFAULT NULL,
  `revoked_at` datetime(6) DEFAULT NULL,
  `revoked_by` binary(16) DEFAULT NULL,
  `revoke_reason` varchar(120) DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `client_id` binary(16) DEFAULT NULL,
  `consent_id` binary(16) DEFAULT NULL,
  `refresh_id` binary(16) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tokens_token_id` (`token_id`),
  KEY `ix_tokens_user` (`user_id`,`revoked_at`,`expires_at`),
  KEY `ix_tokens_expires` (`expires_at`),
  KEY `ix_tokens_consent` (`consent_id`,`revoked_at`),
  KEY `ix_tokens_client` (`client_id`,`revoked_at`),
  CONSTRAINT `fk_tokens_oauth_client` FOREIGN KEY (`client_id`) REFERENCES `oauth_clients` (`id`),
  CONSTRAINT `fk_tokens_oauth_consent` FOREIGN KEY (`consent_id`) REFERENCES `oauth_consents` (`id`),
  CONSTRAINT `fk_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_tokens`
--

LOCK TABLES `access_tokens` WRITE;
/*!40000 ALTER TABLE `access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachments` (
  `id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `sha256` binary(32) NOT NULL,
  `size_bytes` bigint unsigned NOT NULL,
  `mime` varchar(127) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `path_hint` varchar(760) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci DEFAULT NULL,
  `storage_key` varchar(512) NOT NULL,
  `encryption` enum('none','aes256gcm') NOT NULL DEFAULT 'none',
  `key_version` tinyint unsigned DEFAULT NULL,
  `iv` varbinary(12) DEFAULT NULL,
  `auth_tag` varbinary(16) DEFAULT NULL,
  `uploaded_by` binary(16) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `live` tinyint GENERATED ALWAYS AS (if((`deleted_at` is null),1,NULL)) VIRTUAL,
  `version` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_attachment_vault_sha` (`vault_id`,`sha256`),
  UNIQUE KEY `uq_attachment_path` (`vault_id`,`path_hint`,`live`),
  KEY `ix_attachments_vault` (`vault_id`,`deleted_at`),
  CONSTRAINT `fk_att_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_chain_heads`
--

DROP TABLE IF EXISTS `audit_chain_heads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_chain_heads` (
  `chain_id` varchar(40) NOT NULL,
  `last_id` bigint unsigned NOT NULL,
  `last_hash` binary(32) NOT NULL,
  PRIMARY KEY (`chain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_chain_heads`
--

LOCK TABLES `audit_chain_heads` WRITE;
/*!40000 ALTER TABLE `audit_chain_heads` DISABLE KEYS */;
INSERT INTO `audit_chain_heads` VALUES ('server',69,0x7951F687D6FBDD6A83E9C41A239439E9CF4047423CC46A7FCA4DD1C4F6D3E27C),('vault:01a0bdac6be971609398433d802aee01',75,0xDFD4BAD29FA345CB1761B0A2643D0D53B8202EDBE36251D24D4704C924832EF5);
/*!40000 ALTER TABLE `audit_chain_heads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_events`
--

DROP TABLE IF EXISTS `audit_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime(6) NOT NULL,
  `schema_version` smallint unsigned NOT NULL DEFAULT '1',
  `chain_id` varchar(40) NOT NULL,
  `action` varchar(64) NOT NULL,
  `actor_type` enum('user','token','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `actor_display` varchar(160) DEFAULT NULL,
  `on_behalf_of_user_id` binary(16) DEFAULT NULL,
  `credential_type` enum('session','pat','oauth','ticket','setpw','cli','system','none') NOT NULL,
  `credential_id` binary(16) DEFAULT NULL,
  `vault_id` binary(16) DEFAULT NULL,
  `target_type` varchar(32) DEFAULT NULL,
  `target_id` binary(16) DEFAULT NULL,
  `targets` json DEFAULT NULL,
  `outcome` enum('success','failure') NOT NULL,
  `reason` varchar(128) DEFAULT NULL,
  `context` json NOT NULL,
  `metadata` json DEFAULT NULL,
  `prev_hash` binary(32) NOT NULL,
  `hash` binary(32) NOT NULL,
  `key_version` tinyint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_audit_chain` (`chain_id`,`id`),
  KEY `ix_audit_vault_time` (`vault_id`,`occurred_at`),
  KEY `ix_audit_actor_time` (`actor_id`,`occurred_at`),
  KEY `ix_audit_action_time` (`action`,`occurred_at`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_events`
--

LOCK TABLES `audit_events` WRITE;
/*!40000 ALTER TABLE `audit_events` DISABLE KEYS */;
INSERT INTO `audit_events` VALUES (1,'2026-09-20 07:16:25.153000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0001_users\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x0000000000000000000000000000000000000000000000000000000000000000,0xA2EDF8929DA23E6E603C4DC067C7D4712B80580C34DD2A2678BA1D488F6D9924,1),(2,'2026-09-20 07:16:25.158000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0002_user_credentials\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xA2EDF8929DA23E6E603C4DC067C7D4712B80580C34DD2A2678BA1D488F6D9924,0x74FDA678D0F0E126864C511C207BF48926A064F84DD08EEE95EFDCE74B07100A,1),(3,'2026-09-20 07:16:25.161000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0003_password_setup_tokens\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x74FDA678D0F0E126864C511C207BF48926A064F84DD08EEE95EFDCE74B07100A,0xF235713A2BC12E31DE00D4EE67890CB45567A6FB02299BBBFF7384EF893505B8,1),(4,'2026-09-20 07:16:25.164000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0004_sessions\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xF235713A2BC12E31DE00D4EE67890CB45567A6FB02299BBBFF7384EF893505B8,0x08FF175CECE15D1DE5C466B409E2CB16B5F285206F77CAE0A8D66D236BB3305D,1),(5,'2026-09-20 07:16:25.166000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0005_login_throttle\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x08FF175CECE15D1DE5C466B409E2CB16B5F285206F77CAE0A8D66D236BB3305D,0x187B1058146DBCDC184168821F0C3D1B4C22013C0FF9D2720293CA0009F84491,1),(6,'2026-09-20 07:16:25.169000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0006_vaults\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x187B1058146DBCDC184168821F0C3D1B4C22013C0FF9D2720293CA0009F84491,0xB61DFD2221C186962E065491BAADFA7F6935E0FAB54C53665A2DF8687112E9C6,1),(7,'2026-09-20 07:16:25.172000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0007_vault_members\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xB61DFD2221C186962E065491BAADFA7F6935E0FAB54C53665A2DF8687112E9C6,0xCDCCDCD584441DB525978E5E5B4087DDA2F4E71265042FAB3BFFA1877F55D483,1),(8,'2026-09-20 07:16:25.174000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0008_access_tokens\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xCDCCDCD584441DB525978E5E5B4087DDA2F4E71265042FAB3BFFA1877F55D483,0xFB18E1810E49A06FE48DD2DBC82AF1D86BE6F36E9246FAB85C8B278E60DC42F4,1),(9,'2026-09-20 07:16:25.177000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0009_access_token_vaults\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xFB18E1810E49A06FE48DD2DBC82AF1D86BE6F36E9246FAB85C8B278E60DC42F4,0x742E98D2A6E1D11E866F0CB716C3E2FD85C248D3A2AFA078DB6EB43918F8D643,1),(10,'2026-09-20 07:16:25.179000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0010_nodes\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x742E98D2A6E1D11E866F0CB716C3E2FD85C248D3A2AFA078DB6EB43918F8D643,0xF6DFA851399324A1221A6D8D9BEEF2080A70639297955B63881A8DCFF1EA4119,1),(11,'2026-09-20 07:16:25.181000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0011_nodes_uq_sibling\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xF6DFA851399324A1221A6D8D9BEEF2080A70639297955B63881A8DCFF1EA4119,0xFE2E94445047D2DFF25C594073E944534801F92744F3879A159216FD4FA54CAA,1),(12,'2026-09-20 07:16:25.183000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0012_trash_entries\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xFE2E94445047D2DFF25C594073E944534801F92744F3879A159216FD4FA54CAA,0x1A7661442DC0D6DCA2744089C9D9005CE40BC678BC2C15821A0584D5199E4809,1),(13,'2026-09-20 07:16:25.185000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0013_notes\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x1A7661442DC0D6DCA2744089C9D9005CE40BC678BC2C15821A0584D5199E4809,0x0AF048E42712A582C66F3A4219B0872E2D4AE0794BC7244EDB6BF19ACB538582,1),(14,'2026-09-20 07:16:25.187000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0014_note_docs\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x0AF048E42712A582C66F3A4219B0872E2D4AE0794BC7244EDB6BF19ACB538582,0x441146F54C5F42D8A26A2BA8EFEE79C23911B8C26A992B1B72CD5FD0C46B0F55,1),(15,'2026-09-20 07:16:25.189000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0015_note_updates\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x441146F54C5F42D8A26A2BA8EFEE79C23911B8C26A992B1B72CD5FD0C46B0F55,0x53C0ABDDFE9008C60CE147DEAB7707F047F710C53F159DD520ABEFB0046D8651,1),(16,'2026-09-20 07:16:25.197000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0016_note_revisions\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x53C0ABDDFE9008C60CE147DEAB7707F047F710C53F159DD520ABEFB0046D8651,0xDEDA718DD6076DA9B47FB1AC886867C01327B0439750F13A54163930EAC504DE,1),(17,'2026-09-20 07:16:25.199000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0017_note_projections\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xDEDA718DD6076DA9B47FB1AC886867C01327B0439750F13A54163930EAC504DE,0xB562FB89499E53908F0D2F04519367ACB5C3D1B21629E2DF5B05EC18222E54D1,1),(18,'2026-09-20 07:16:25.200000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0018_note_projections_fm_indexes\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xB562FB89499E53908F0D2F04519367ACB5C3D1B21629E2DF5B05EC18222E54D1,0xCEC8EA4BDFD4A78BEDF3C51413BFA8614081D828A5AC79457335FCE8D83DAFB6,1),(19,'2026-09-20 07:16:25.202000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0019_note_search\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xCEC8EA4BDFD4A78BEDF3C51413BFA8614081D828A5AC79457335FCE8D83DAFB6,0x7D123487455E4201BC0BA7B4D8421B2B5C318F27ADECB277C2CDB5F7ED9182BD,1),(20,'2026-09-20 07:16:25.204000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0020_note_search_fulltext\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x7D123487455E4201BC0BA7B4D8421B2B5C318F27ADECB277C2CDB5F7ED9182BD,0x1D6832BAEF77668D34EB59E5BCECA4322253FC99492D6705154C3448513F42F4,1),(21,'2026-09-20 07:16:25.206000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0021_note_links\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x1D6832BAEF77668D34EB59E5BCECA4322253FC99492D6705154C3448513F42F4,0x983FF723E23609D8EF5BC8BDBEFB4851B19D0AE35D2FDAABCF2BAA02A74C4E95,1),(22,'2026-09-20 07:16:25.208000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0022_attachments\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x983FF723E23609D8EF5BC8BDBEFB4851B19D0AE35D2FDAABCF2BAA02A74C4E95,0x516E805F2C10D7D21E001F0CEFB777D167141B3A618215A995765B26D3A066D5,1),(23,'2026-09-20 07:16:25.210000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0023_jobs\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x516E805F2C10D7D21E001F0CEFB777D167141B3A618215A995765B26D3A066D5,0xE0FCFBA0E31CC199E0BC346E962EECF8A3F7D4C04A2CD2A8F353A53968C107A1,1),(24,'2026-09-20 07:16:25.212000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0024_import_jobs\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xE0FCFBA0E31CC199E0BC346E962EECF8A3F7D4C04A2CD2A8F353A53968C107A1,0x459B5B7457B507CCF8596FDD08AD10A1695CF4A40B310EBBB3D5432B90EE37E5,1),(25,'2026-09-20 07:16:25.213000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0025_export_jobs\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x459B5B7457B507CCF8596FDD08AD10A1695CF4A40B310EBBB3D5432B90EE37E5,0x4644E411750D4A58AF06E5A014ABC036162216C27F23B81D97E349538CE7759B,1),(26,'2026-09-20 07:16:25.215000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0026_audit_events\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x4644E411750D4A58AF06E5A014ABC036162216C27F23B81D97E349538CE7759B,0x8B7D6511FC2857B23795EA5376D328F18F87157D1E894E43AC8F26565DD97E8F,1),(27,'2026-09-20 07:16:25.217000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0027_audit_chain_heads\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x8B7D6511FC2857B23795EA5376D328F18F87157D1E894E43AC8F26565DD97E8F,0xF477344A8E611EC5BB108783A857C77EA69D9A4772D1AC6A6103A950529030CE,1),(28,'2026-09-20 07:16:25.219000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0028_audit_events_triggers\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xF477344A8E611EC5BB108783A857C77EA69D9A4772D1AC6A6103A950529030CE,0xCA717A3AB8F4A8A1C0BF87FB17442FEC3941855CE4A8226D14E053E7451A3C4A,1),(29,'2026-09-20 07:16:25.221000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0029_audit_events_archive\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xCA717A3AB8F4A8A1C0BF87FB17442FEC3941855CE4A8226D14E053E7451A3C4A,0xDB059FBAB3D3A8619CE001A0A8D2CDDB284383C91B8DBC46B61F84F2E0A99FE5,1),(30,'2026-09-20 07:16:25.223000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0030_access_log\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xDB059FBAB3D3A8619CE001A0A8D2CDDB284383C91B8DBC46B61F84F2E0A99FE5,0x21DA98F82A9276193E3DA472D5B9F721CB479B58C104CE9314AA632E7639DF7F,1),(31,'2026-09-20 07:16:25.224000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0031_server_settings\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x21DA98F82A9276193E3DA472D5B9F721CB479B58C104CE9314AA632E7639DF7F,0x597CE4EAB701D1FE75B037BBCFB1CB0187B5ADF57FFEED620255C965A7DBB96F,1),(32,'2026-09-20 07:16:25.226000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0032_schema_meta\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x597CE4EAB701D1FE75B037BBCFB1CB0187B5ADF57FFEED620255C965A7DBB96F,0x7513A40CD366BF2C53D96821063415C73EA7744598612C42E8222CA6B8BF21D4,1),(33,'2026-09-20 07:16:25.228000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0033_desktop_releases\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x7513A40CD366BF2C53D96821063415C73EA7744598612C42E8222CA6B8BF21D4,0x0D2F8CA4DEC9447A033FCAA389BF0BB5D62AE38358637CC62FD2E1C406083390,1),(34,'2026-09-20 07:16:25.230000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0034_grants\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x0D2F8CA4DEC9447A033FCAA389BF0BB5D62AE38358637CC62FD2E1C406083390,0x2A7F845B7E02A1496B004CA8E342FC63BABD2DCEF893668CDAEF0B8A8D04DF2D,1),(35,'2026-09-20 07:16:25.232000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0035_oauth_clients\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x2A7F845B7E02A1496B004CA8E342FC63BABD2DCEF893668CDAEF0B8A8D04DF2D,0x0A7909AD92A9C9FAFE41D83F8E5A2E43E4B60B194C3D07ED08C9702DA9C73D15,1),(36,'2026-09-20 07:16:25.233000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0036_oauth_clients_grants\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x0A7909AD92A9C9FAFE41D83F8E5A2E43E4B60B194C3D07ED08C9702DA9C73D15,0x45E385CEC9DCD90834D0EE64C1B5CCF8133965CC6BFFA92A502903292E9441A1,1),(37,'2026-09-20 07:16:25.236000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0037_oauth_consents\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x45E385CEC9DCD90834D0EE64C1B5CCF8133965CC6BFFA92A502903292E9441A1,0x13F949EEFAA4CC00B46DDA0D35E8D4F2CD28C7AAF25299213620106AF1B4CA01,1),(38,'2026-09-20 07:16:25.237000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0038_oauth_consents_uq_live\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x13F949EEFAA4CC00B46DDA0D35E8D4F2CD28C7AAF25299213620106AF1B4CA01,0x3B73D93547E03D35472DEF8D16D08B85ADD429388DD50C90AEA23F128C20BF54,1),(39,'2026-09-20 07:16:25.239000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0039_oauth_consents_grants\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x3B73D93547E03D35472DEF8D16D08B85ADD429388DD50C90AEA23F128C20BF54,0x6954E8D85A8EE01FB2230563311423AB73E4413DCBA554869D6381AF64A6E425,1),(40,'2026-09-20 07:16:25.241000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0040_oauth_consent_vaults\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x6954E8D85A8EE01FB2230563311423AB73E4413DCBA554869D6381AF64A6E425,0xF22F8BCDB4D5F0D44CF4444839BA931D7CC431F108DCEE808C4CBB229F4215A0,1),(41,'2026-09-20 07:16:25.243000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0041_oauth_consent_vaults_grants\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xF22F8BCDB4D5F0D44CF4444839BA931D7CC431F108DCEE808C4CBB229F4215A0,0x7395D474A1BF997AA39AD58ADC1E07BE4397CC66709B566912020904B8B0C9B6,1),(42,'2026-09-20 07:16:25.245000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0042_oauth_authorization_codes\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x7395D474A1BF997AA39AD58ADC1E07BE4397CC66709B566912020904B8B0C9B6,0xE00A0C8E1AC97A84C076255469E5FAFDB0696732FA3FF8E1AE0ABD2A7270DFCC,1),(43,'2026-09-20 07:16:25.247000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0043_oauth_authorization_codes_grants\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xE00A0C8E1AC97A84C076255469E5FAFDB0696732FA3FF8E1AE0ABD2A7270DFCC,0xF189792142B93A5AB1E3178798711AD6E54CB7D65F1726E6740E55FBF6FC07D5,1),(44,'2026-09-20 07:16:25.250000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0044_oauth_refresh_tokens\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xF189792142B93A5AB1E3178798711AD6E54CB7D65F1726E6740E55FBF6FC07D5,0x807E9AABD3DCB1C680167EC1DF712C3927340D30123728F6A3EEE9A47A5D43DD,1),(45,'2026-09-20 07:16:25.252000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0045_oauth_refresh_tokens_grants\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x807E9AABD3DCB1C680167EC1DF712C3927340D30123728F6A3EEE9A47A5D43DD,0x76217CC8BF34E14855C77D7364BC04DA8005513573EECF62B850F5960C286EFC,1),(46,'2026-09-20 07:16:25.254000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0046_access_tokens_oauth_columns\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x76217CC8BF34E14855C77D7364BC04DA8005513573EECF62B850F5960C286EFC,0xBF28E39BD8DBF394EF82E0E4E591470AC360660C14B681200EBCE0F965E8A11D,1),(47,'2026-09-20 07:16:25.256000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0047_access_tokens_oauth_indexes\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xBF28E39BD8DBF394EF82E0E4E591470AC360660C14B681200EBCE0F965E8A11D,0x3DEEF12A241FDA515D802299E7F19A6ACF83CFC36015FADCAC058306CC535AE0,1),(48,'2026-09-20 07:16:25.258000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0048_access_log_oauth_client\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x3DEEF12A241FDA515D802299E7F19A6ACF83CFC36015FADCAC058306CC535AE0,0x783EFD224B0D5720C0E6D34A240D30BE6416B4B3789A8F970C71A0C4F5F0F5E5,1),(49,'2026-09-20 07:16:25.260000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0049_admin_users_lock\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x783EFD224B0D5720C0E6D34A240D30BE6416B4B3789A8F970C71A0C4F5F0F5E5,0x9E84753E2C2F8F193D153D4FAC97283891F50B5FDA0304D55ED420FD7E058034,1),(50,'2026-09-20 07:16:25.261000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0050_session_revocation_commands\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x9E84753E2C2F8F193D153D4FAC97283891F50B5FDA0304D55ED420FD7E058034,0xECC5111777B5F476E71ADE384324DEBBADB0AC47F1E57C803B3F9B2A47AF613D,1),(51,'2026-09-20 07:16:25.263000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0051_session_revocation_commands_grants\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xECC5111777B5F476E71ADE384324DEBBADB0AC47F1E57C803B3F9B2A47AF613D,0xCBFACA6F4E6ADE49E112A26ECDDF85BA074F5887650941CE21ECECE0F12C33D4,1),(52,'2026-09-20 07:16:25.265000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0052_collab_owner_fence\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xCBFACA6F4E6ADE49E112A26ECDDF85BA074F5887650941CE21ECECE0F12C33D4,0xAEFA9C0C7378FFA0B0C9DB9F5F67FF626E1DE63F7A8FDC41D4C5DF0AA9CD9432,1),(53,'2026-09-20 07:16:25.267000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0053_collab_owner_fence_grants\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xAEFA9C0C7378FFA0B0C9DB9F5F67FF626E1DE63F7A8FDC41D4C5DF0AA9CD9432,0xA44DAE5071253CE94AFC244D787C93DEC190D2CF14694F3822984FE71D3F2990,1),(54,'2026-09-20 07:16:25.269000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0054_grants_provenance\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0xA44DAE5071253CE94AFC244D787C93DEC190D2CF14694F3822984FE71D3F2990,0x11B6DF34E338EE0754ED7130032C9EF6BB84B2CD4A1E5D1CBED871238B0DA859,1),(55,'2026-09-20 07:16:25.271000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\"}','{\"name\": \"0055_min_client_version\", \"batch\": \"01a0bdac-5b4c-771a-a3d8-ade6871111a8\", \"duration_ms\": null}',0x11B6DF34E338EE0754ED7130032C9EF6BB84B2CD4A1E5D1CBED871238B0DA859,0x17168E3D5916F2DF874D91E5FC7596736E2C8A34316839E68CF0857C271EFF05,1),(56,'2026-09-20 07:16:28.113000',1,'server','admin.user.created','system',NULL,NULL,NULL,'cli',NULL,NULL,'user',0x01A0BDAC693F7116BBAFBC107DAA39A7,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"admin create-user --email <value> --display-name <value> --server-admin\", \"request_id\": \"01a0bdac-6791-7569-9e86-6374b0c2ef8d\"}','{\"displayName\": \"Kernel Admin\", \"isServerAdmin\": true, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0bdac-694c-7280-b0e0-25e0658177fa\"}',0x17168E3D5916F2DF874D91E5FC7596736E2C8A34316839E68CF0857C271EFF05,0x3D53DDDAE4C06D517696824417536E48778B33CBEB1BF0FF6A3016EBFA565DD5,1),(57,'2026-09-20 07:16:28.322000',1,'server','user.password.set','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,NULL,NULL,'setpw',0x01A0BDAC694C7280B0E025E0658177FA,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-69de-7f46-a9a3-ec9be1556c1d\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0x3D53DDDAE4C06D517696824417536E48778B33CBEB1BF0FF6A3016EBFA565DD5,0xD73C5F522FEA16869251E5C4B118DFFB67B911368C29836D2893247BF7EC9317,1),(58,'2026-09-20 07:16:28.415000',1,'server','user.login.succeeded','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,'admin@iridium.test',NULL,'session',0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6a44-7796-95cb-7558da5328c7\", \"user_agent\": \"node\"}','{\"kind\": \"web\", \"method\": \"password\", \"clientVersion\": \"0.0.0\"}',0xD73C5F522FEA16869251E5C4B118DFFB67B911368C29836D2893247BF7EC9317,0x6B9B271CD61DA9544B8BCF382E4C08C6472DA902DFBA73E125C7D84828E3A940,1),(59,'2026-09-20 07:16:28.456000',1,'server','user.reauth.succeeded','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,'admin@iridium.test',NULL,'session',0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6a93-75cd-bfe3-f45a3f0e941a\", \"user_agent\": \"node\"}','{}',0x6B9B271CD61DA9544B8BCF382E4C08C6472DA902DFBA73E125C7D84828E3A940,0xA2416CBC8AE4871DAAC22D5E73A897EF54CD816A79633ED2B599135924EC9A61,1),(60,'2026-09-20 07:16:28.531000',1,'server','admin.user.created','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,'Kernel Admin',NULL,'session',0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,NULL,'user',0x01A0BDAC6AC57E539DBB9A8EBE357023,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6ab5-72d4-a137-126e22128487\", \"user_agent\": \"node\"}','{\"displayName\": \"editorA\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0bdac-6af0-765f-ad15-b81769444f8d\"}',0xA2416CBC8AE4871DAAC22D5E73A897EF54CD816A79633ED2B599135924EC9A61,0x2780AE0589E924215BD11CF4392E87C63C61097C6080F240C3A6681C2C3831B0,1),(61,'2026-09-20 07:16:28.547000',1,'server','admin.user.created','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,'Kernel Admin',NULL,'session',0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,NULL,'user',0x01A0BDAC6AD07DAEA209D93BF2DCC041,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6ab9-73db-b904-9b7a9a4c282d\", \"user_agent\": \"node\"}','{\"displayName\": \"editorB\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0bdac-6aff-7e88-a5d6-2d266ce743bd\"}',0x2780AE0589E924215BD11CF4392E87C63C61097C6080F240C3A6681C2C3831B0,0xD15304F0ACB392A580717001AABB4298AA8ACF1330EE4C93118BCAC783D022DC,1),(62,'2026-09-20 07:16:28.575000',1,'server','admin.user.created','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,'Kernel Admin',NULL,'session',0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,NULL,'user',0x01A0BDAC6AE2797385451341F5519E58,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6ac0-7ee3-9cd8-da5ef3b1b79a\", \"user_agent\": \"node\"}','{\"displayName\": \"editorC\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0bdac-6b1c-7662-8517-c111f5174918\"}',0xD15304F0ACB392A580717001AABB4298AA8ACF1330EE4C93118BCAC783D022DC,0xE81302653968AE1F344DFF9FFC747DDE13F13807CCD87E9724037A5C00E907DF,1),(63,'2026-09-20 07:16:28.592000',1,'server','admin.user.created','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,'Kernel Admin',NULL,'session',0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,NULL,'user',0x01A0BDAC6AE57454B8C0EA00657AC589,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6ace-7683-a54d-8e01919adba5\", \"user_agent\": \"node\"}','{\"displayName\": \"viewer\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0bdac-6b2c-77a4-8e7a-26285d36d2c6\"}',0xE81302653968AE1F344DFF9FFC747DDE13F13807CCD87E9724037A5C00E907DF,0x9241B49F1F32EED66AC4E144532A51D67399EB45019E05A0DDB91C788E2EB51D,1),(64,'2026-09-20 07:16:28.646000',1,'server','admin.user.created','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,'Kernel Admin',NULL,'session',0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,NULL,'user',0x01A0BDAC6AEB7C668B6DF5F6F7C077FE,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6ad2-7b64-80f2-d2c4c2048177\", \"user_agent\": \"node\"}','{\"displayName\": \"outsider\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0bdac-6b51-789e-aedf-876aefea26ce\"}',0x9241B49F1F32EED66AC4E144532A51D67399EB45019E05A0DDB91C788E2EB51D,0x0B3D8AA2F9F3291E580604481EBFB779276B0AF46E46B60F272937EFBBE10DE2,1),(65,'2026-09-20 07:16:28.659000',1,'server','user.password.set','user',0x01A0BDAC6AD07DAEA209D93BF2DCC041,NULL,NULL,'setpw',0x01A0BDAC6AFF7E88A5D62D266CE743BD,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6b19-7a5c-b1b3-6de38c22bf8e\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0x0B3D8AA2F9F3291E580604481EBFB779276B0AF46E46B60F272937EFBBE10DE2,0x7866B7B80AB31E6D208AD272560185A7E7BD8D0C56B10DDE7C5597043FD5E869,1),(66,'2026-09-20 07:16:28.683000',1,'server','user.password.set','user',0x01A0BDAC6AC57E539DBB9A8EBE357023,NULL,NULL,'setpw',0x01A0BDAC6AF0765FAD15B81769444F8D,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6afe-76e5-a9bf-ccfba08606f7\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0x7866B7B80AB31E6D208AD272560185A7E7BD8D0C56B10DDE7C5597043FD5E869,0x4FFFBC9BB481C7D2D77629F1480A3AFD15752627E97460512E7718B63A363FC3,1),(67,'2026-09-20 07:16:28.692000',1,'server','user.password.set','user',0x01A0BDAC6AE2797385451341F5519E58,NULL,NULL,'setpw',0x01A0BDAC6B1C76628517C111F5174918,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6b2b-7260-9879-cceba006da7b\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0x4FFFBC9BB481C7D2D77629F1480A3AFD15752627E97460512E7718B63A363FC3,0xCB0398FC80B517247A8F23BC452C0C6584A484E15C19EE1B818290DF5AFA7E10,1),(68,'2026-09-20 07:16:28.710000',1,'server','user.password.set','user',0x01A0BDAC6AE57454B8C0EA00657AC589,NULL,NULL,'setpw',0x01A0BDAC6B2C77A48E7A26285D36D2C6,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6b4e-72e1-a970-f54a5c2c7a56\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0xCB0398FC80B517247A8F23BC452C0C6584A484E15C19EE1B818290DF5AFA7E10,0xF1061EACFFE398A74FA49722BA4E8FCF525D79DBA9C803FC362C7E622E322376,1),(69,'2026-09-20 07:16:28.741000',1,'server','user.password.set','user',0x01A0BDAC6AEB7C668B6DF5F6F7C077FE,NULL,NULL,'setpw',0x01A0BDAC6B51789EAEDF876AEFEA26CE,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6b80-76e6-8526-3b984e313f87\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0xF1061EACFFE398A74FA49722BA4E8FCF525D79DBA9C803FC362C7E622E322376,0x7951F687D6FBDD6A83E9C41A239439E9CF4047423CC46A7FCA4DD1C4F6D3E27C,1),(70,'2026-09-20 07:16:28.789000',1,'vault:01a0bdac6be971609398433d802aee01','vault.created','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,'Kernel Admin',NULL,'session',0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,0x01A0BDAC6BE971609398433D802AEE01,'vault',0x01A0BDAC6BE971609398433D802AEE01,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6bdb-7e5c-94c8-462ecfb3800c\", \"user_agent\": \"node\"}','{\"name\": \"Kernel\", \"slug\": \"kernel\", \"memberCount\": 0}',0x0000000000000000000000000000000000000000000000000000000000000000,0x26FB047DE465DF22D6985754878FE657AE2DF0C2DA09517E200F517104D669CD,1),(71,'2026-09-20 07:16:28.843000',1,'vault:01a0bdac6be971609398433d802aee01','vault.member.added','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,'Kernel Admin',NULL,'session',0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,0x01A0BDAC6BE971609398433D802AEE01,'user',0x01A0BDAC6AC57E539DBB9A8EBE357023,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6c16-7e57-bd81-979e3923f1fd\", \"user_agent\": \"node\"}','{\"role\": \"editor\", \"targetDisplay\": \"editorA\"}',0x26FB047DE465DF22D6985754878FE657AE2DF0C2DA09517E200F517104D669CD,0x64B52BEDFF40325ADC47926E418E911BE086E6051E683AAEF77C0CC1DA430661,1),(72,'2026-09-20 07:16:28.870000',1,'vault:01a0bdac6be971609398433d802aee01','vault.member.added','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,'Kernel Admin',NULL,'session',0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,0x01A0BDAC6BE971609398433D802AEE01,'user',0x01A0BDAC6AD07DAEA209D93BF2DCC041,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6c35-7855-8cb0-a204371b96d7\", \"user_agent\": \"node\"}','{\"role\": \"editor\", \"targetDisplay\": \"editorB\"}',0x64B52BEDFF40325ADC47926E418E911BE086E6051E683AAEF77C0CC1DA430661,0xEDFB4A50D0EE986E9D169B0375F9B6BE2BFB3F95C51AA4E80EA7DFD09AB71040,1),(73,'2026-09-20 07:16:28.895000',1,'vault:01a0bdac6be971609398433d802aee01','vault.member.added','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,'Kernel Admin',NULL,'session',0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,0x01A0BDAC6BE971609398433D802AEE01,'user',0x01A0BDAC6AE2797385451341F5519E58,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6c4f-7ab9-8e63-17001e66d773\", \"user_agent\": \"node\"}','{\"role\": \"editor\", \"targetDisplay\": \"editorC\"}',0xEDFB4A50D0EE986E9D169B0375F9B6BE2BFB3F95C51AA4E80EA7DFD09AB71040,0x7AC72AC0C68B3803CCBE5ED8F3A7946487E0054FD69594E590676B2279221F7D,1),(74,'2026-09-20 07:16:28.922000',1,'vault:01a0bdac6be971609398433d802aee01','vault.member.added','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,'Kernel Admin',NULL,'session',0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,0x01A0BDAC6BE971609398433D802AEE01,'user',0x01A0BDAC6AE57454B8C0EA00657AC589,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6c68-7320-9556-701ca2eedf03\", \"user_agent\": \"node\"}','{\"role\": \"viewer\", \"targetDisplay\": \"viewer\"}',0x7AC72AC0C68B3803CCBE5ED8F3A7946487E0054FD69594E590676B2279221F7D,0x15A093CA726D0DA7BA450AD2E142B3D792266A9112007AEE49F21136456BB3C9,1),(75,'2026-09-20 07:16:28.982000',1,'vault:01a0bdac6be971609398433d802aee01','node.created','user',0x01A0BDAC693F7116BBAFBC107DAA39A7,'Kernel Admin',NULL,'session',0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,0x01A0BDAC6BE971609398433D802AEE01,'node',0x01A0BDAC6C8F7C0FBA796BAE9C42E0DD,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bdac-6c82-7bfd-a63e-0f1621c0a20f\", \"user_agent\": \"node\"}','{\"kind\": \"note\", \"name\": \"Kernel Note\", \"parentId\": \"01a0bdac-6be9-7161-a993-f2b436e98968\"}',0x15A093CA726D0DA7BA450AD2E142B3D792266A9112007AEE49F21136456BB3C9,0xDFD4BAD29FA345CB1761B0A2643D0D53B8202EDBE36251D24D4704C924832EF5,1);
/*!40000 ALTER TABLE `audit_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_events_archive`
--

DROP TABLE IF EXISTS `audit_events_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_events_archive` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime(6) NOT NULL,
  `schema_version` smallint unsigned NOT NULL DEFAULT '1',
  `chain_id` varchar(40) NOT NULL,
  `action` varchar(64) NOT NULL,
  `actor_type` enum('user','token','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `actor_display` varchar(160) DEFAULT NULL,
  `on_behalf_of_user_id` binary(16) DEFAULT NULL,
  `credential_type` enum('session','pat','oauth','ticket','setpw','cli','system','none') NOT NULL,
  `credential_id` binary(16) DEFAULT NULL,
  `vault_id` binary(16) DEFAULT NULL,
  `target_type` varchar(32) DEFAULT NULL,
  `target_id` binary(16) DEFAULT NULL,
  `targets` json DEFAULT NULL,
  `outcome` enum('success','failure') NOT NULL,
  `reason` varchar(128) DEFAULT NULL,
  `context` json NOT NULL,
  `metadata` json DEFAULT NULL,
  `prev_hash` binary(32) NOT NULL,
  `hash` binary(32) NOT NULL,
  `key_version` tinyint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_audit_chain` (`chain_id`,`id`),
  KEY `ix_audit_vault_time` (`vault_id`,`occurred_at`),
  KEY `ix_audit_actor_time` (`actor_id`,`occurred_at`),
  KEY `ix_audit_action_time` (`action`,`occurred_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_events_archive`
--

LOCK TABLES `audit_events_archive` WRITE;
/*!40000 ALTER TABLE `audit_events_archive` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_events_archive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collab_owner_fence`
--

DROP TABLE IF EXISTS `collab_owner_fence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collab_owner_fence` (
  `id` tinyint unsigned NOT NULL,
  `generation` binary(16) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `chk_collab_owner_fence_singleton` CHECK ((`id` = 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collab_owner_fence`
--

LOCK TABLES `collab_owner_fence` WRITE;
/*!40000 ALTER TABLE `collab_owner_fence` DISABLE KEYS */;
INSERT INTO `collab_owner_fence` VALUES (1,0xB3A232FCEE33AD381D9BDB02B6EF32A5);
/*!40000 ALTER TABLE `collab_owner_fence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `desktop_releases`
--

DROP TABLE IF EXISTS `desktop_releases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `desktop_releases` (
  `version` varchar(32) NOT NULL,
  `channel` enum('stable','beta') NOT NULL,
  `published_at` datetime(6) NOT NULL,
  `published_by` binary(16) DEFAULT NULL,
  `notes` text,
  `files` json NOT NULL,
  `withdrawn_at` datetime(6) DEFAULT NULL,
  `withdrawn_by` binary(16) DEFAULT NULL,
  PRIMARY KEY (`version`,`channel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `desktop_releases`
--

LOCK TABLES `desktop_releases` WRITE;
/*!40000 ALTER TABLE `desktop_releases` DISABLE KEYS */;
/*!40000 ALTER TABLE `desktop_releases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `export_jobs`
--

DROP TABLE IF EXISTS `export_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `export_jobs` (
  `job_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `scope_node_id` binary(16) DEFAULT NULL,
  `format` enum('zip') NOT NULL,
  `restore_eol` tinyint(1) NOT NULL DEFAULT '1',
  `include_attachments` tinyint(1) NOT NULL DEFAULT '1',
  `include_trashed` tinyint(1) NOT NULL DEFAULT '0',
  `manifest` json DEFAULT NULL,
  `artifact_key` varchar(512) DEFAULT NULL,
  `artifact_sha256` binary(32) DEFAULT NULL,
  `size_bytes` bigint unsigned DEFAULT NULL,
  `expires_at` datetime(6) NOT NULL,
  PRIMARY KEY (`job_id`),
  CONSTRAINT `fk_export_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export_jobs`
--

LOCK TABLES `export_jobs` WRITE;
/*!40000 ALTER TABLE `export_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `export_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_jobs`
--

DROP TABLE IF EXISTS `import_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_jobs` (
  `job_id` binary(16) NOT NULL,
  `target_vault_id` binary(16) DEFAULT NULL,
  `target_parent_id` binary(16) DEFAULT NULL,
  `source_kind` enum('zip','files') NOT NULL,
  `source_sha256` binary(32) DEFAULT NULL,
  `staging_key` varchar(512) NOT NULL,
  `phase` enum('uploading','scanning','reported','committing','done','failed','aborted') NOT NULL,
  `report` json DEFAULT NULL,
  `options` json DEFAULT NULL,
  `stats` json DEFAULT NULL,
  `committed_at` datetime(6) DEFAULT NULL,
  `expires_at` datetime(6) NOT NULL,
  PRIMARY KEY (`job_id`),
  CONSTRAINT `fk_import_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_jobs`
--

LOCK TABLES `import_jobs` WRITE;
/*!40000 ALTER TABLE `import_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `import_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` binary(16) NOT NULL,
  `type` varchar(48) NOT NULL,
  `status` enum('queued','running','succeeded','failed','cancelled') NOT NULL,
  `vault_id` binary(16) DEFAULT NULL,
  `requested_by` binary(16) DEFAULT NULL,
  `payload` json NOT NULL,
  `progress` json DEFAULT NULL,
  `result` json DEFAULT NULL,
  `error` text,
  `attempts` tinyint unsigned NOT NULL DEFAULT '0',
  `locked_by` varchar(64) DEFAULT NULL,
  `locked_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `started_at` datetime(6) DEFAULT NULL,
  `finished_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_jobs_status` (`status`,`created_at`),
  KEY `ix_jobs_vault_type` (`vault_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kysely_migration`
--

DROP TABLE IF EXISTS `kysely_migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kysely_migration` (
  `name` varchar(255) NOT NULL,
  `timestamp` varchar(255) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kysely_migration`
--

LOCK TABLES `kysely_migration` WRITE;
/*!40000 ALTER TABLE `kysely_migration` DISABLE KEYS */;
INSERT INTO `kysely_migration` VALUES ('0001_users','2026-09-20T07:16:24.642Z'),('0002_user_credentials','2026-09-20T07:16:24.652Z'),('0003_password_setup_tokens','2026-09-20T07:16:24.661Z'),('0004_sessions','2026-09-20T07:16:24.673Z'),('0005_login_throttle','2026-09-20T07:16:24.678Z'),('0006_vaults','2026-09-20T07:16:24.687Z'),('0007_vault_members','2026-09-20T07:16:24.697Z'),('0008_access_tokens','2026-09-20T07:16:24.710Z'),('0009_access_token_vaults','2026-09-20T07:16:24.723Z'),('0010_nodes','2026-09-20T07:16:24.735Z'),('0011_nodes_uq_sibling','2026-09-20T07:16:24.750Z'),('0012_trash_entries','2026-09-20T07:16:24.758Z'),('0013_notes','2026-09-20T07:16:24.769Z'),('0014_note_docs','2026-09-20T07:16:24.776Z'),('0015_note_updates','2026-09-20T07:16:24.786Z'),('0016_note_revisions','2026-09-20T07:16:24.795Z'),('0017_note_projections','2026-09-20T07:16:24.804Z'),('0018_note_projections_fm_indexes','2026-09-20T07:16:24.815Z'),('0019_note_search','2026-09-20T07:16:24.822Z'),('0020_note_search_fulltext','2026-09-20T07:16:24.846Z'),('0021_note_links','2026-09-20T07:16:24.854Z'),('0022_attachments','2026-09-20T07:16:24.861Z'),('0023_jobs','2026-09-20T07:16:24.866Z'),('0024_import_jobs','2026-09-20T07:16:24.871Z'),('0025_export_jobs','2026-09-20T07:16:24.877Z'),('0026_audit_events','2026-09-20T07:16:24.883Z'),('0027_audit_chain_heads','2026-09-20T07:16:24.886Z'),('0028_audit_events_triggers','2026-09-20T07:16:24.893Z'),('0029_audit_events_archive','2026-09-20T07:16:24.904Z'),('0030_access_log','2026-09-20T07:16:24.912Z'),('0031_server_settings','2026-09-20T07:16:24.914Z'),('0032_schema_meta','2026-09-20T07:16:24.918Z'),('0033_desktop_releases','2026-09-20T07:16:24.921Z'),('0034_grants','2026-09-20T07:16:24.956Z'),('0035_oauth_clients','2026-09-20T07:16:24.965Z'),('0036_oauth_clients_grants','2026-09-20T07:16:24.968Z'),('0037_oauth_consents','2026-09-20T07:16:24.976Z'),('0038_oauth_consents_uq_live','2026-09-20T07:16:24.984Z'),('0039_oauth_consents_grants','2026-09-20T07:16:24.987Z'),('0040_oauth_consent_vaults','2026-09-20T07:16:24.995Z'),('0041_oauth_consent_vaults_grants','2026-09-20T07:16:24.997Z'),('0042_oauth_authorization_codes','2026-09-20T07:16:25.009Z'),('0043_oauth_authorization_codes_grants','2026-09-20T07:16:25.012Z'),('0044_oauth_refresh_tokens','2026-09-20T07:16:25.027Z'),('0045_oauth_refresh_tokens_grants','2026-09-20T07:16:25.030Z'),('0046_access_tokens_oauth_columns','2026-09-20T07:16:25.057Z'),('0047_access_tokens_oauth_indexes','2026-09-20T07:16:25.073Z'),('0048_access_log_oauth_client','2026-09-20T07:16:25.087Z'),('0049_admin_users_lock','2026-09-20T07:16:25.088Z'),('0050_session_revocation_commands','2026-09-20T07:16:25.093Z'),('0051_session_revocation_commands_grants','2026-09-20T07:16:25.096Z'),('0052_collab_owner_fence','2026-09-20T07:16:25.101Z'),('0053_collab_owner_fence_grants','2026-09-20T07:16:25.104Z'),('0054_grants_provenance','2026-09-20T07:16:25.127Z'),('0055_min_client_version','2026-09-20T07:16:25.128Z');
/*!40000 ALTER TABLE `kysely_migration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kysely_migration_lock`
--

DROP TABLE IF EXISTS `kysely_migration_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kysely_migration_lock` (
  `id` varchar(255) NOT NULL,
  `is_locked` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kysely_migration_lock`
--

LOCK TABLES `kysely_migration_lock` WRITE;
/*!40000 ALTER TABLE `kysely_migration_lock` DISABLE KEYS */;
INSERT INTO `kysely_migration_lock` VALUES ('migration_lock',0);
/*!40000 ALTER TABLE `kysely_migration_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_throttle`
--

DROP TABLE IF EXISTS `login_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_throttle` (
  `key` varchar(191) NOT NULL,
  `points` int NOT NULL,
  `expire` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_throttle`
--

LOCK TABLES `login_throttle` WRITE;
/*!40000 ALTER TABLE `login_throttle` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nodes`
--

DROP TABLE IF EXISTS `nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nodes` (
  `id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `parent_id` binary(16) NOT NULL,
  `kind` enum('category','note') NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `live` tinyint GENERATED ALWAYS AS (if((`deleted_at` is null),1,NULL)) VIRTUAL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_by` binary(16) NOT NULL,
  `updated_by` binary(16) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sibling` (`parent_id`,`name`,`live`),
  KEY `ix_nodes_vault_parent` (`vault_id`,`parent_id`,`kind`),
  KEY `ix_nodes_vault_deleted` (`vault_id`,`deleted_at`),
  KEY `ix_nodes_vault_name` (`vault_id`,`name`),
  CONSTRAINT `fk_nodes_parent` FOREIGN KEY (`parent_id`) REFERENCES `nodes` (`id`),
  CONSTRAINT `fk_nodes_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nodes`
--

LOCK TABLES `nodes` WRITE;
/*!40000 ALTER TABLE `nodes` DISABLE KEYS */;
INSERT INTO `nodes` (`id`, `vault_id`, `parent_id`, `kind`, `name`, `deleted_at`, `version`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES (0x01A0BDAC6BE97161A993F2B436E98968,0x01A0BDAC6BE971609398433D802AEE01,0x01A0BDAC6BE97161A993F2B436E98968,'category','',NULL,1,0x01A0BDAC693F7116BBAFBC107DAA39A7,0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-20 07:16:28.774000','2026-09-20 07:16:28.774000'),(0x01A0BDAC6C8F7C0FBA796BAE9C42E0DD,0x01A0BDAC6BE971609398433D802AEE01,0x01A0BDAC6BE97161A993F2B436E98968,'note','Kernel Note',NULL,1,0x01A0BDAC693F7116BBAFBC107DAA39A7,0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-20 07:16:28.953000','2026-09-20 07:16:28.953000');
/*!40000 ALTER TABLE `nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_docs`
--

DROP TABLE IF EXISTS `note_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_docs` (
  `note_id` binary(16) NOT NULL,
  `head_seq` bigint unsigned NOT NULL DEFAULT '0',
  `snapshot_format` tinyint unsigned NOT NULL DEFAULT '2',
  `yjs_major` tinyint unsigned NOT NULL DEFAULT '13',
  `snapshot` longblob,
  `snapshot_sv` varbinary(4096) DEFAULT NULL,
  `snapshot_through_seq` bigint unsigned NOT NULL DEFAULT '0',
  `snapshot_size` int unsigned NOT NULL DEFAULT '0',
  `snapshot_at` datetime(6) DEFAULT NULL,
  `projected_seq` bigint unsigned NOT NULL DEFAULT '0',
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`note_id`),
  CONSTRAINT `fk_docs_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_docs`
--

LOCK TABLES `note_docs` WRITE;
/*!40000 ALTER TABLE `note_docs` DISABLE KEYS */;
INSERT INTO `note_docs` VALUES (0x01A0BDAC6C8F7C0FBA796BAE9C42E0DD,1,2,13,0x000005BDA5C4900C000001042825636F6E74656E74E29FA6494D504F52542D4D41524BE29FA7206B65726E656C206E6F74650A071A0101000001010000,0x01FD92A288061A,1,61,'2026-09-20 07:16:28.953000',1,'2026-09-20 07:16:28.953000');
/*!40000 ALTER TABLE `note_docs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_links`
--

DROP TABLE IF EXISTS `note_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `from_note_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `revision` bigint unsigned NOT NULL,
  `ordinal` int unsigned NOT NULL,
  `kind` enum('markdown','image','wikilink','embed','definition') NOT NULL,
  `raw_target` varchar(2048) NOT NULL,
  `resolved_node_id` binary(16) DEFAULT NULL,
  `resolved_attachment_id` binary(16) DEFAULT NULL,
  `fragment` varchar(255) DEFAULT NULL,
  `status` enum('resolved','ambiguous','broken','external') NOT NULL,
  `start_offset` int unsigned NOT NULL,
  `end_offset` int unsigned NOT NULL,
  `line` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_links_from_ordinal` (`from_note_id`,`ordinal`),
  KEY `ix_links_target_node` (`vault_id`,`resolved_node_id`),
  KEY `ix_links_target_attachment` (`resolved_attachment_id`),
  KEY `ix_links_status` (`vault_id`,`status`),
  CONSTRAINT `fk_links_note` FOREIGN KEY (`from_note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_links`
--

LOCK TABLES `note_links` WRITE;
/*!40000 ALTER TABLE `note_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_projections`
--

DROP TABLE IF EXISTS `note_projections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_projections` (
  `note_id` binary(16) NOT NULL,
  `revision` bigint unsigned NOT NULL,
  `markdown` mediumtext NOT NULL,
  `content_hash` binary(32) NOT NULL,
  `heading_title` varchar(255) DEFAULT NULL,
  `frontmatter_raw` text,
  `frontmatter` json DEFAULT NULL,
  `frontmatter_error` varchar(500) DEFAULT NULL,
  `fm_tags` json DEFAULT NULL,
  `fm_aliases` json DEFAULT NULL,
  `headings` json DEFAULT NULL,
  `tasks` json DEFAULT NULL,
  `code_langs` json DEFAULT NULL,
  `obsidian_findings` json DEFAULT NULL,
  `word_count` int unsigned DEFAULT NULL,
  `line_count` int unsigned DEFAULT NULL,
  `status` enum('ok','pending','too_large','too_complex','timeout','error','invalid_content') NOT NULL,
  `pipeline_version` smallint unsigned NOT NULL,
  `projected_at` datetime(6) NOT NULL,
  PRIMARY KEY (`note_id`),
  KEY `ix_proj_pipeline` (`pipeline_version`),
  KEY `ix_proj_fm_tags` ((cast(`fm_tags` as char(64) array))),
  KEY `ix_proj_fm_aliases` ((cast(`fm_aliases` as char(255) array))),
  CONSTRAINT `fk_proj_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_projections`
--

LOCK TABLES `note_projections` WRITE;
/*!40000 ALTER TABLE `note_projections` DISABLE KEYS */;
INSERT INTO `note_projections` VALUES (0x01A0BDAC6C8F7C0FBA796BAE9C42E0DD,1,'⟦IMPORT-MARK⟧ kernel note\n',0xE2E20748D12A460DD24A3772DE532B67556FC3096F8343ED08E01149CF4310DD,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ok',1,'2026-09-20 07:16:28.953000');
/*!40000 ALTER TABLE `note_projections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_revisions`
--

DROP TABLE IF EXISTS `note_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_revisions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `note_id` binary(16) NOT NULL,
  `seq` bigint unsigned NOT NULL,
  `kind` enum('create','import','checkpoint','unload','named','pre_restore','restore','trash') NOT NULL,
  `label` varchar(200) DEFAULT NULL,
  `markdown` mediumtext NOT NULL,
  `content_hash` binary(32) NOT NULL,
  `size_chars` int unsigned NOT NULL,
  `snapshot` longblob,
  `snapshot_format` tinyint unsigned DEFAULT NULL,
  `yjs_major` tinyint unsigned DEFAULT NULL,
  `snapshot_sv` varbinary(4096) DEFAULT NULL,
  `actor_type` enum('user','token','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `restored_from_revision_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_revisions_note_seq_kind` (`note_id`,`seq`,`kind`),
  KEY `ix_revisions_note_created` (`note_id`,`created_at`),
  CONSTRAINT `fk_revisions_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_revisions`
--

LOCK TABLES `note_revisions` WRITE;
/*!40000 ALTER TABLE `note_revisions` DISABLE KEYS */;
INSERT INTO `note_revisions` VALUES (1,0x01A0BDAC6C8F7C0FBA796BAE9C42E0DD,1,'create',NULL,'⟦IMPORT-MARK⟧ kernel note\n',0xE2E20748D12A460DD24A3772DE532B67556FC3096F8343ED08E01149CF4310DD,26,0x000005BDA5C4900C000001042825636F6E74656E74E29FA6494D504F52542D4D41524BE29FA7206B65726E656C206E6F74650A071A0101000001010000,2,13,0x01FD92A288061A,'user',0x01A0BDAC693F7116BBAFBC107DAA39A7,NULL,'2026-09-20 07:16:28.953000');
/*!40000 ALTER TABLE `note_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_search`
--

DROP TABLE IF EXISTS `note_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_search` (
  `note_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body_text` mediumtext NOT NULL,
  `revision` bigint unsigned NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`note_id`),
  KEY `ix_search_vault` (`vault_id`),
  FULLTEXT KEY `ft_note_search` (`title`,`body_text`),
  CONSTRAINT `fk_search_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_search`
--

LOCK TABLES `note_search` WRITE;
/*!40000 ALTER TABLE `note_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_updates`
--

DROP TABLE IF EXISTS `note_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_updates` (
  `note_id` binary(16) NOT NULL,
  `seq` bigint unsigned NOT NULL,
  `update_v1` mediumblob NOT NULL,
  `yjs_major` tinyint unsigned NOT NULL DEFAULT '13',
  `sv_after` varbinary(4096) NOT NULL,
  `actor_type` enum('user','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `session_id` binary(16) DEFAULT NULL,
  `origin` enum('connection','create','import','restore','repair') NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`note_id`,`seq`),
  KEY `ix_updates_created` (`created_at`),
  CONSTRAINT `fk_updates_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_updates`
--

LOCK TABLES `note_updates` WRITE;
/*!40000 ALTER TABLE `note_updates` DISABLE KEYS */;
INSERT INTO `note_updates` VALUES (0x01A0BDAC6C8F7C0FBA796BAE9C42E0DD,1,0x0101FD92A2880600040107636F6E74656E741EE29FA6494D504F52542D4D41524BE29FA7206B65726E656C206E6F74650A00,13,0x01FD92A288061A,'user',0x01A0BDAC693F7116BBAFBC107DAA39A7,0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,'create','2026-09-20 07:16:28.953000');
/*!40000 ALTER TABLE `note_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `node_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `initialized_at` datetime(6) DEFAULT NULL,
  `original_eol` enum('lf','crlf','cr','mixed') NOT NULL DEFAULT 'lf',
  `had_bom` tinyint(1) NOT NULL DEFAULT '0',
  `size_chars` int unsigned NOT NULL DEFAULT '0',
  `oversize` tinyint(1) NOT NULL DEFAULT '0',
  `content_invalid` tinyint(1) NOT NULL DEFAULT '0',
  `last_edited_by` binary(16) DEFAULT NULL,
  `last_edited_at` datetime(6) DEFAULT NULL,
  `last_checkpoint_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`node_id`),
  KEY `ix_notes_vault` (`vault_id`),
  CONSTRAINT `fk_notes_node` FOREIGN KEY (`node_id`) REFERENCES `nodes` (`id`),
  CONSTRAINT `fk_notes_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES (0x01A0BDAC6C8F7C0FBA796BAE9C42E0DD,0x01A0BDAC6BE971609398433D802AEE01,'2026-09-20 07:16:28.953000','lf',0,26,0,0,0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-20 07:16:28.953000',NULL,'2026-09-20 07:16:28.953000','2026-09-20 07:16:28.953000');
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_authorization_codes`
--

DROP TABLE IF EXISTS `oauth_authorization_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_authorization_codes` (
  `id` binary(16) NOT NULL,
  `code_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `client_id` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `consent_id` binary(16) NOT NULL,
  `session_id` binary(16) NOT NULL,
  `redirect_uri` varchar(512) NOT NULL,
  `code_challenge` char(43) NOT NULL,
  `code_challenge_method` enum('S256') NOT NULL,
  `resource` varchar(255) NOT NULL,
  `scopes` json NOT NULL,
  `issued_at` datetime(6) NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  `consumed_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_oauth_codes_code_id` (`code_id`),
  KEY `ix_oauth_codes_expires` (`expires_at`),
  KEY `fk_oauth_codes_client` (`client_id`),
  KEY `fk_oauth_codes_user` (`user_id`),
  KEY `fk_oauth_codes_consent` (`consent_id`),
  CONSTRAINT `fk_oauth_codes_client` FOREIGN KEY (`client_id`) REFERENCES `oauth_clients` (`id`),
  CONSTRAINT `fk_oauth_codes_consent` FOREIGN KEY (`consent_id`) REFERENCES `oauth_consents` (`id`),
  CONSTRAINT `fk_oauth_codes_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_authorization_codes`
--

LOCK TABLES `oauth_authorization_codes` WRITE;
/*!40000 ALTER TABLE `oauth_authorization_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_authorization_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_clients` (
  `id` binary(16) NOT NULL,
  `client_id` varchar(512) NOT NULL,
  `registration_kind` enum('cimd','dynamic','manual') NOT NULL,
  `client_name` varchar(120) NOT NULL,
  `client_uri` varchar(512) DEFAULT NULL,
  `logo_uri` varchar(512) DEFAULT NULL,
  `application_type` enum('native','web') NOT NULL,
  `token_endpoint_auth_method` enum('none','client_secret_basic') NOT NULL DEFAULT 'none',
  `client_secret_hash` binary(32) DEFAULT NULL,
  `client_secret_prefix` char(26) DEFAULT NULL,
  `redirect_uris` json NOT NULL,
  `grant_types` json NOT NULL,
  `scopes` json DEFAULT NULL,
  `cimd_document` json DEFAULT NULL,
  `cimd_fetched_at` datetime(6) DEFAULT NULL,
  `cimd_etag` varchar(120) DEFAULT NULL,
  `status` enum('active','disabled') NOT NULL DEFAULT 'active',
  `created_at` datetime(6) NOT NULL,
  `created_by_user_id` binary(16) DEFAULT NULL,
  `last_authorized_at` datetime(6) DEFAULT NULL,
  `disabled_at` datetime(6) DEFAULT NULL,
  `disabled_by` binary(16) DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_oauth_clients_client_id` (`client_id`(191)),
  KEY `ix_oauth_clients_status` (`status`,`created_at`),
  KEY `ix_oauth_clients_unused` (`last_authorized_at`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_consent_vaults`
--

DROP TABLE IF EXISTS `oauth_consent_vaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_consent_vaults` (
  `consent_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  PRIMARY KEY (`consent_id`,`vault_id`),
  KEY `ix_ocv_vault` (`vault_id`),
  CONSTRAINT `fk_ocv_consent` FOREIGN KEY (`consent_id`) REFERENCES `oauth_consents` (`id`),
  CONSTRAINT `fk_ocv_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_consent_vaults`
--

LOCK TABLES `oauth_consent_vaults` WRITE;
/*!40000 ALTER TABLE `oauth_consent_vaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_consent_vaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_consents`
--

DROP TABLE IF EXISTS `oauth_consents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_consents` (
  `id` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `client_id` binary(16) NOT NULL,
  `scopes` json NOT NULL,
  `all_vaults` tinyint(1) NOT NULL DEFAULT '0',
  `admin_owned` tinyint(1) NOT NULL DEFAULT '0',
  `granted_at` datetime(6) NOT NULL,
  `granted_session_id` binary(16) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `last_authorized_at` datetime(6) DEFAULT NULL,
  `revoked_at` datetime(6) DEFAULT NULL,
  `revoked_by` binary(16) DEFAULT NULL,
  `revoke_reason` varchar(120) DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `live_consent_key` varbinary(32) GENERATED ALWAYS AS (if((`revoked_at` is null),concat(`user_id`,`client_id`),NULL)) VIRTUAL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_oauth_consents_live` (`live_consent_key`),
  KEY `ix_oauth_consents_user` (`user_id`,`revoked_at`),
  KEY `ix_oauth_consents_client` (`client_id`,`revoked_at`),
  CONSTRAINT `fk_oauth_consents_client` FOREIGN KEY (`client_id`) REFERENCES `oauth_clients` (`id`),
  CONSTRAINT `fk_oauth_consents_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_consents`
--

LOCK TABLES `oauth_consents` WRITE;
/*!40000 ALTER TABLE `oauth_consents` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_consents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` binary(16) NOT NULL,
  `token_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `family_id` binary(16) NOT NULL,
  `rotated_from_id` binary(16) DEFAULT NULL,
  `client_id` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `consent_id` binary(16) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `scopes` json NOT NULL,
  `issued_at` datetime(6) NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  `absolute_expires_at` datetime(6) NOT NULL,
  `last_used_at` datetime(6) DEFAULT NULL,
  `rotated_at` datetime(6) DEFAULT NULL,
  `revoked_at` datetime(6) DEFAULT NULL,
  `revoke_reason` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_oauth_refresh_token_id` (`token_id`),
  KEY `ix_oauth_refresh_family` (`family_id`,`revoked_at`),
  KEY `ix_oauth_refresh_consent` (`consent_id`,`revoked_at`),
  KEY `ix_oauth_refresh_expires` (`absolute_expires_at`),
  KEY `fk_oauth_refresh_client` (`client_id`),
  KEY `fk_oauth_refresh_user` (`user_id`),
  CONSTRAINT `fk_oauth_refresh_client` FOREIGN KEY (`client_id`) REFERENCES `oauth_clients` (`id`),
  CONSTRAINT `fk_oauth_refresh_consent` FOREIGN KEY (`consent_id`) REFERENCES `oauth_consents` (`id`),
  CONSTRAINT `fk_oauth_refresh_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_setup_tokens`
--

DROP TABLE IF EXISTS `password_setup_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_setup_tokens` (
  `id` binary(16) NOT NULL,
  `token_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `purpose` enum('initial','reset') NOT NULL,
  `issued_by` binary(16) NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  `consumed_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_spl_token_id` (`token_id`),
  KEY `ix_spl_user` (`user_id`,`consumed_at`),
  CONSTRAINT `fk_spl_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_setup_tokens`
--

LOCK TABLES `password_setup_tokens` WRITE;
/*!40000 ALTER TABLE `password_setup_tokens` DISABLE KEYS */;
INSERT INTO `password_setup_tokens` VALUES (0x01A0BDAC694C7280B0E025E0658177FA,'7eTXruUAegVXJOeb',0x6EAD923A87A25F4C795EDCAF2D138BF5476F96A0B8DF21826E6BF19765BB3D99,0x01A0BDAC693F7116BBAFBC107DAA39A7,'initial',0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-21 07:16:28.105000','2026-09-20 07:16:28.302000','2026-09-20 07:16:28.105000'),(0x01A0BDAC6AF0765FAD15B81769444F8D,'9TgXOkD6MKLGiSJ5',0xB768C9EA66CD2FC8C8AFA4905A5701BC1A434F8D8F39D2EFF86364888C23641A,0x01A0BDAC6AC57E539DBB9A8EBE357023,'initial',0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-21 07:16:28.526000','2026-09-20 07:16:28.570000','2026-09-20 07:16:28.526000'),(0x01A0BDAC6AFF7E88A5D62D266CE743BD,'BvudSQd7zyHH4WNM',0x3A9FC7C85FAF8B66E8C38A8746F29A33D3A0427B948372741E517081D3D01155,0x01A0BDAC6AD07DAEA209D93BF2DCC041,'initial',0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-21 07:16:28.541000','2026-09-20 07:16:28.582000','2026-09-20 07:16:28.541000'),(0x01A0BDAC6B1C76628517C111F5174918,'1buzYTLDmxP7cqtn',0x912267182FEA9117AAB5E6710CE397C113430050639BFBA2E8773DBDDEFCEA04,0x01A0BDAC6AE2797385451341F5519E58,'initial',0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-21 07:16:28.570000','2026-09-20 07:16:28.625000','2026-09-20 07:16:28.570000'),(0x01A0BDAC6B2C77A48E7A26285D36D2C6,'NiFAfnerHTn0otWi',0x18866FEACC5E049D43E99A5ECE88581E22D733DDD317C38876EDACE468D342C1,0x01A0BDAC6AE57454B8C0EA00657AC589,'initial',0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-21 07:16:28.586000','2026-09-20 07:16:28.675000','2026-09-20 07:16:28.586000'),(0x01A0BDAC6B51789EAEDF876AEFEA26CE,'shiO6AOtSNPDGeGT',0xD1851541605CDB92B852A7945D397A603D9DB45685C6B8636FACC8C09FBF661F,0x01A0BDAC6AEB7C668B6DF5F6F7C077FE,'initial',0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-21 07:16:28.614000','2026-09-20 07:16:28.705000','2026-09-20 07:16:28.614000');
/*!40000 ALTER TABLE `password_setup_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_meta`
--

DROP TABLE IF EXISTS `schema_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_meta` (
  `key` varchar(32) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_meta`
--

LOCK TABLES `schema_meta` WRITE;
/*!40000 ALTER TABLE `schema_meta` DISABLE KEYS */;
INSERT INTO `schema_meta` VALUES ('acl.access_log','{\"applied\":true,\"fingerprint\":\"3cb05ad81cb510aa65bc7dbff4b59ac9b8ccf070be4480dae6a2e5595271c8f6\"}'),('acl.access_token_vaults','{\"applied\":true,\"fingerprint\":\"68b911e5b92bb9d90846c791c74c40047a7f2da0022ae0da84d51479e9bcb7ca\"}'),('acl.access_tokens','{\"applied\":true,\"fingerprint\":\"bdfbd1c8e849e12264649353fe1032b9ca270a9e2af5ee45657e9031900c1650\"}'),('acl.attachments','{\"applied\":true,\"fingerprint\":\"723b9d57613881d040162ab632e6bcc834243e2f1e2979b1906e61411a230615\"}'),('acl.audit_chain_heads','{\"applied\":true,\"fingerprint\":\"09bbf8d7503aa4e44b7635070bb4954504e8458b2f780659cfdd306c8c035b93\"}'),('acl.audit_events','{\"applied\":true,\"fingerprint\":\"0d021f69a450993d66c44fac10e927a4d92ef76e0e136057361b526fd26eca47\"}'),('acl.audit_events_archive','{\"applied\":true,\"fingerprint\":\"9245bc26a1a2ec7a41c9151dac9b7da67463e5bb0b83f464251e06e58871daa0\"}'),('acl.collab_owner_fence','{\"applied\":true,\"fingerprint\":\"60ca2453617aefa174bbde43d3da8ba7a38f1a42c65e0c271708aa7c129dad22\"}'),('acl.desktop_releases','{\"applied\":true,\"fingerprint\":\"cbe40c21e12c5efc3c74858dfbff81d4f0f7ca072934459d3a630b090054c178\"}'),('acl.export_jobs','{\"applied\":true,\"fingerprint\":\"54166a5f90330c33611fcae2aa1d34ebb8af0e1d597f53c9d6347055c7dc9e32\"}'),('acl.import_jobs','{\"applied\":true,\"fingerprint\":\"8421e3bcf12234ffbb3368c03eead01fb4187039904df4cd17ea9d939e4bef0d\"}'),('acl.jobs','{\"applied\":true,\"fingerprint\":\"aafb728ee85aa56cb620f691a28ed571a95005ebd55b22b441c54ccb4fa20ab6\"}'),('acl.kysely_migration','{\"applied\":true,\"fingerprint\":\"b364934c8871a0572104874fc864b5b764879ddd870006f197615931e34c1c13\"}'),('acl.kysely_migration_lock','{\"applied\":true,\"fingerprint\":\"51021f74746159bf4f61ad5d713f8cb7ea8bdfdc65ec5dafeacc8f7f475000ed\"}'),('acl.login_throttle','{\"applied\":true,\"fingerprint\":\"2e0520a72039d214fe19cd34c5d11e0dbce39b5fa8eaed6217ac654cc1d53ac7\"}'),('acl.nodes','{\"applied\":true,\"fingerprint\":\"7faa7ee251146e70f596a81bfb009b162bcb6a2f33cfbd175c061106cbdf7e2a\"}'),('acl.note_docs','{\"applied\":true,\"fingerprint\":\"9be49954ad662abfe9dfc8eabbbdbd3b297d586171989e37d17f90505b4c8785\"}'),('acl.note_links','{\"applied\":true,\"fingerprint\":\"795c9fdeeafc80d5453f1df962de09d0f04ff3179eff1adb01ff9359ab67b541\"}'),('acl.note_projections','{\"applied\":true,\"fingerprint\":\"186c0c4cd81ee039b9e37b968dbd6961ec67553b898156104aa4382ca5dac89d\"}'),('acl.note_revisions','{\"applied\":true,\"fingerprint\":\"bdc901cf8bae963ea7af081ee1d534f326dc8284153f13fdc6c06233fe4739c9\"}'),('acl.note_search','{\"applied\":true,\"fingerprint\":\"2a051511f38517eadd587824a069abad3ba927b579d251ba184bed5fda603097\"}'),('acl.note_updates','{\"applied\":true,\"fingerprint\":\"071dc16dfecb9daf0acc7016c61e7f991e1da36441aaeb3877cd23fe256aa5d6\"}'),('acl.notes','{\"applied\":true,\"fingerprint\":\"d771b524137a6d8a634d3bf770b3c76c3d7ff7319ee57f4ca910a8aa2147b08b\"}'),('acl.oauth_authorization_codes','{\"applied\":true,\"fingerprint\":\"977d39eee4d1ac6af76a1a92430c602c949684ce05955506006c990741f003b1\"}'),('acl.oauth_clients','{\"applied\":true,\"fingerprint\":\"24b77335f71aeb6a23bf71d70cff6f4829329fe1147a2897d8dc0d618a1bb7f4\"}'),('acl.oauth_consent_vaults','{\"applied\":true,\"fingerprint\":\"caed8e3500fefa0e34df565008eb71ce930b2916acb44e62883a59a2f9c7a247\"}'),('acl.oauth_consents','{\"applied\":true,\"fingerprint\":\"0e644943db192f7ea9a12a09071c93e567fb1913a46cc11eb10eb2f3ab510d7d\"}'),('acl.oauth_refresh_tokens','{\"applied\":true,\"fingerprint\":\"58e7d98d6b9e595a600b6f0b59e37d31bec0ab3b422bedbb1048e70d137e9601\"}'),('acl.password_setup_tokens','{\"applied\":true,\"fingerprint\":\"338280c5b6e7046d97b1b3c8589c607af96c616c9752ee5be8013b979b85b30c\"}'),('acl.schema_meta','{\"applied\":true,\"fingerprint\":\"cb7265c4a3f24d38872b9828716c27551bbc2d0b52211d0e8761e21f4e72b444\"}'),('acl.server_settings','{\"applied\":true,\"fingerprint\":\"eb4ea243f596142a9657008af4eca3f17ea41288b4c5ccf0f1387ea847ae768c\"}'),('acl.session_revocation_commands','{\"applied\":true,\"fingerprint\":\"04105afeb1b1103d05ee6888550001576396cd8c51186fb443ba1463a5780553\"}'),('acl.sessions','{\"applied\":true,\"fingerprint\":\"4f8066e4177db802da539b9bfc1de4a4c62f5008d9fc9cf3ed33d85c5eb268bf\"}'),('acl.trash_entries','{\"applied\":true,\"fingerprint\":\"4e72de20258f7e35a7420323888ca6bbd7b9e1af1ed2d51fc9adf75e7df09f3b\"}'),('acl.user_credentials','{\"applied\":true,\"fingerprint\":\"d31f8e8409ed598603f5811ac676fb89c3cad26d913de7ce31989b9272338d67\"}'),('acl.users','{\"applied\":true,\"fingerprint\":\"a2927f57314bc380d4a91c1b106ccc1b94fadfbb27f320ac08e04020245cdb48\"}'),('acl.vault_members','{\"applied\":true,\"fingerprint\":\"def08bb5a1358fdf86c7057558280e72987b5503eed056d5ef3f6d0eae7e5f35\"}'),('acl.vaults','{\"applied\":true,\"fingerprint\":\"1af3101abc5ec86fbf8d7bdf5acb316c454d5a2a0892713d256b7e80e05637f8\"}'),('admin_users_lock','1'),('api_version','1'),('attachment_key_version','1'),('audit_key_version','1'),('cursor_key_version','1'),('iridium_version','0.0.0'),('min_client_version','0.0.0'),('pepper_version','1'),('pipeline_version','1');
/*!40000 ALTER TABLE `schema_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server_settings`
--

DROP TABLE IF EXISTS `server_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `server_settings` (
  `key` varchar(64) NOT NULL,
  `value` json NOT NULL,
  `updated_by` binary(16) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server_settings`
--

LOCK TABLES `server_settings` WRITE;
/*!40000 ALTER TABLE `server_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `server_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_revocation_commands`
--

DROP TABLE IF EXISTS `session_revocation_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session_revocation_commands` (
  `id` binary(16) NOT NULL,
  `user_id` binary(16) DEFAULT NULL,
  `actor_type` enum('user','token','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `actor_display` varchar(120) DEFAULT NULL,
  `context` json NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `result` json DEFAULT NULL,
  `delivered_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_session_commands_pending` (`delivered_at`,`created_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_revocation_commands`
--

LOCK TABLES `session_revocation_commands` WRITE;
/*!40000 ALTER TABLE `session_revocation_commands` DISABLE KEYS */;
/*!40000 ALTER TABLE `session_revocation_commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` binary(16) NOT NULL,
  `token_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `kind` enum('web','desktop') NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `last_seen_at` datetime(6) NOT NULL,
  `idle_expires_at` datetime(6) NOT NULL,
  `absolute_expires_at` datetime(6) NOT NULL,
  `last_authenticated_at` datetime(6) NOT NULL,
  `mfa_verified_at` datetime(6) DEFAULT NULL,
  `ip` varbinary(16) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `client_name` varchar(64) DEFAULT NULL,
  `device_name` varchar(120) DEFAULT NULL,
  `client_version` varchar(32) DEFAULT NULL,
  `revoked_at` datetime(6) DEFAULT NULL,
  `revoked_reason` enum('logout','admin','password_change','user_disabled','expired','replaced') DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sessions_token_id` (`token_id`),
  KEY `ix_sessions_user` (`user_id`,`revoked_at`),
  KEY `ix_sessions_absolute` (`absolute_expires_at`),
  CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (0x01A0BDAC6A787F1EAD30B1E5C8CA63C2,'QhC9SqhJLh9vyFSS',0x0D0891242314B1AF69EF75F9E2FDF44D4A62E155DD2A3503FEB5783F60FDF39B,0x01A0BDAC693F7116BBAFBC107DAA39A7,'web','2026-09-20 07:16:28.398000','2026-09-20 07:16:28.398000','2026-09-21 07:16:28.398000','2026-10-04 07:16:28.398000','2026-09-20 07:16:28.450000',NULL,0x7F000001,'node','web',NULL,'0.0.0',NULL,NULL);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trash_entries`
--

DROP TABLE IF EXISTS `trash_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trash_entries` (
  `node_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `cascade_root_id` binary(16) NOT NULL,
  `deleted_by` binary(16) NOT NULL,
  `deleted_at` datetime(6) NOT NULL,
  `original_parent_id` binary(16) NOT NULL,
  `original_path` text NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  PRIMARY KEY (`node_id`),
  KEY `ix_trash_vault_expires` (`vault_id`,`expires_at`),
  KEY `ix_trash_vault_root` (`vault_id`,`cascade_root_id`),
  CONSTRAINT `fk_trash_node` FOREIGN KEY (`node_id`) REFERENCES `nodes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trash_entries`
--

LOCK TABLES `trash_entries` WRITE;
/*!40000 ALTER TABLE `trash_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `trash_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_credentials`
--

DROP TABLE IF EXISTS `user_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_credentials` (
  `user_id` binary(16) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `pepper_version` tinyint unsigned NOT NULL,
  `password_changed_at` datetime(6) NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_cred_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_credentials`
--

LOCK TABLES `user_credentials` WRITE;
/*!40000 ALTER TABLE `user_credentials` DISABLE KEYS */;
INSERT INTO `user_credentials` VALUES (0x01A0BDAC693F7116BBAFBC107DAA39A7,'$argon2id$v=19$m=8192,t=1,p=1$Rj7hBnHXGyl4ZuW7QRqEzQ$MeZ0kHs3osMZnbBF+qa8GMDAgFIdVQpMdhIY/ZxFkoM',1,'2026-09-20 07:16:28.302000'),(0x01A0BDAC6AC57E539DBB9A8EBE357023,'$argon2id$v=19$m=8192,t=1,p=1$2x9qY8XQpP7ExB3enu3Puw$YN3mG/TNpXWms4BG21+pI094eSI2TR7XLEoxKEaB5eo',1,'2026-09-20 07:16:28.570000'),(0x01A0BDAC6AD07DAEA209D93BF2DCC041,'$argon2id$v=19$m=8192,t=1,p=1$lVRe62rrxP7bS11hrr+iiQ$i2W/Vd+4mrNQ8DGqRjo7Dc0u4bkRKDrFSp2VQAdNrIk',1,'2026-09-20 07:16:28.582000'),(0x01A0BDAC6AE2797385451341F5519E58,'$argon2id$v=19$m=8192,t=1,p=1$FMn0DjRaufmpP2cmC44DSA$LvHD9KttZGOtsZme6r4ImVQCp4Ax4AgiFC23NfVcrzE',1,'2026-09-20 07:16:28.625000'),(0x01A0BDAC6AE57454B8C0EA00657AC589,'$argon2id$v=19$m=8192,t=1,p=1$6CMNrxrLQoYr4iGq5gafgg$MqSbJ7HYMcp15gHcppWLfLLhPtbyk3YWuhH8EW2Iy3Q',1,'2026-09-20 07:16:28.675000'),(0x01A0BDAC6AEB7C668B6DF5F6F7C077FE,'$argon2id$v=19$m=8192,t=1,p=1$PYtfyqC9rlFy0ThTWk4v2A$+TJC9a84mLdhMa2cINYUivSRPJEAa7UvqGBj99VxzWw',1,'2026-09-20 07:16:28.705000');
/*!40000 ALTER TABLE `user_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` binary(16) NOT NULL,
  `email` varchar(320) NOT NULL,
  `email_key` varchar(320) GENERATED ALWAYS AS (lower(`email`)) STORED,
  `display_name` varchar(120) NOT NULL,
  `is_server_admin` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('active','disabled','deleted') NOT NULL DEFAULT 'active',
  `color_hue` smallint unsigned NOT NULL,
  `authz_version` int unsigned NOT NULL DEFAULT '1',
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `last_login_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email_key` (`email_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `email`, `display_name`, `is_server_admin`, `status`, `color_hue`, `authz_version`, `version`, `created_at`, `updated_at`, `last_login_at`) VALUES (0x01A0BDAC693F7116BBAFBC107DAA39A7,'admin@iridium.test','Kernel Admin',1,'active',0,2,1,'2026-09-20 07:16:28.095000','2026-09-20 07:16:28.302000','2026-09-20 07:16:28.398000'),(0x01A0BDAC6AC57E539DBB9A8EBE357023,'editorA@iridium.test','editorA',0,'active',138,3,1,'2026-09-20 07:16:28.485000','2026-09-20 07:16:28.830000',NULL),(0x01A0BDAC6AD07DAEA209D93BF2DCC041,'editorB@iridium.test','editorB',0,'active',275,3,1,'2026-09-20 07:16:28.496000','2026-09-20 07:16:28.860000',NULL),(0x01A0BDAC6AE2797385451341F5519E58,'editorC@iridium.test','editorC',0,'active',53,3,1,'2026-09-20 07:16:28.514000','2026-09-20 07:16:28.885000',NULL),(0x01A0BDAC6AE57454B8C0EA00657AC589,'viewer@iridium.test','viewer',0,'active',190,3,1,'2026-09-20 07:16:28.517000','2026-09-20 07:16:28.911000',NULL),(0x01A0BDAC6AEB7C668B6DF5F6F7C077FE,'outsider@iridium.test','outsider',0,'active',328,2,1,'2026-09-20 07:16:28.523000','2026-09-20 07:16:28.705000',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vault_members`
--

DROP TABLE IF EXISTS `vault_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vault_members` (
  `vault_id` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `role` enum('viewer','editor','manager') NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `granted_by` binary(16) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`vault_id`,`user_id`),
  KEY `ix_members_user` (`user_id`),
  CONSTRAINT `fk_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_members_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vault_members`
--

LOCK TABLES `vault_members` WRITE;
/*!40000 ALTER TABLE `vault_members` DISABLE KEYS */;
INSERT INTO `vault_members` VALUES (0x01A0BDAC6BE971609398433D802AEE01,0x01A0BDAC6AC57E539DBB9A8EBE357023,'editor',1,0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-20 07:16:28.830000','2026-09-20 07:16:28.830000'),(0x01A0BDAC6BE971609398433D802AEE01,0x01A0BDAC6AD07DAEA209D93BF2DCC041,'editor',1,0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-20 07:16:28.860000','2026-09-20 07:16:28.860000'),(0x01A0BDAC6BE971609398433D802AEE01,0x01A0BDAC6AE2797385451341F5519E58,'editor',1,0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-20 07:16:28.885000','2026-09-20 07:16:28.885000'),(0x01A0BDAC6BE971609398433D802AEE01,0x01A0BDAC6AE57454B8C0EA00657AC589,'viewer',1,0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-20 07:16:28.911000','2026-09-20 07:16:28.911000');
/*!40000 ALTER TABLE `vault_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vaults`
--

DROP TABLE IF EXISTS `vaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vaults` (
  `id` binary(16) NOT NULL,
  `name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `slug` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `root_node_id` binary(16) DEFAULT NULL,
  `status` enum('importing','active','archived','deleting') NOT NULL DEFAULT 'active',
  `archived_at` datetime(6) DEFAULT NULL,
  `markdown_flavor` enum('gfm','obsidian-compat') NOT NULL DEFAULT 'gfm',
  `soft_breaks` tinyint(1) NOT NULL DEFAULT '0',
  `attachment_folder` varchar(255) NOT NULL DEFAULT 'attachments',
  `load_external_images` enum('never','click','always') NOT NULL DEFAULT 'click',
  `mcp_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `ai_guidance` text,
  `trash_retention_days` smallint unsigned NOT NULL DEFAULT '30',
  `auto_checkpoint_interval_min` smallint unsigned NOT NULL DEFAULT '10',
  `tree_version` bigint unsigned NOT NULL DEFAULT '0',
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_by` binary(16) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vaults_name` (`name`),
  UNIQUE KEY `uq_vaults_slug` (`slug`),
  KEY `ix_vaults_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vaults`
--

LOCK TABLES `vaults` WRITE;
/*!40000 ALTER TABLE `vaults` DISABLE KEYS */;
INSERT INTO `vaults` VALUES (0x01A0BDAC6BE971609398433D802AEE01,'Kernel','kernel',NULL,0x01A0BDAC6BE97161A993F2B436E98968,'active',NULL,'gfm',0,'attachments','click',1,NULL,30,10,1,1,0x01A0BDAC693F7116BBAFBC107DAA39A7,'2026-09-20 07:16:28.774000','2026-09-20 07:16:28.979000');
/*!40000 ALTER TABLE `vaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'iridium'
--

--
-- Dumping routines for database 'iridium'
--
--
-- WARNING: can't read the INFORMATION_SCHEMA.libraries table. It's most probably an old server 8.4.11.
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-20  7:16:35
