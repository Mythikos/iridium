-- MySQL dump 10.13  Distrib 9.7.2, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: iridium
-- ------------------------------------------------------
-- Server version	8.4.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE REPLICATION SOURCE TO SOURCE_LOG_FILE='binlog.000003', SOURCE_LOG_POS=168619;

--
-- Current Database: `iridium`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `iridium` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `iridium`;

--
-- Table structure for table `access_log`
--

DROP TABLE IF EXISTS `access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime(6) NOT NULL,
  `token_id` binary(16) DEFAULT NULL,
  `user_id` binary(16) NOT NULL,
  `surface` enum('mcp','rest','export','oauth') NOT NULL,
  `action` varchar(64) NOT NULL,
  `vault_id` binary(16) DEFAULT NULL,
  `note_ids` json DEFAULT NULL,
  `note_ids_truncated` tinyint(1) NOT NULL DEFAULT '0',
  `revision` bigint unsigned DEFAULT NULL,
  `status` enum('ok','denied','not_found','error','rate_limited') NOT NULL,
  `latency_ms` int unsigned NOT NULL,
  `bytes_out` int unsigned DEFAULT NULL,
  `client_name` varchar(64) DEFAULT NULL,
  `client_version` varchar(32) DEFAULT NULL,
  `ip` varbinary(16) DEFAULT NULL,
  `request_id` binary(16) DEFAULT NULL,
  `oauth_client_id` binary(16) DEFAULT NULL,
  PRIMARY KEY (`id`,`occurred_at`),
  KEY `ix_access_token_time` (`token_id`,`occurred_at`),
  KEY `ix_access_vault_time` (`vault_id`,`occurred_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
/*!50500 PARTITION BY RANGE  COLUMNS(occurred_at)
(PARTITION p2026_09 VALUES LESS THAN ('2026-10-01 00:00:00.000000') ENGINE = InnoDB,
 PARTITION p2026_10 VALUES LESS THAN ('2026-11-01 00:00:00.000000') ENGINE = InnoDB,
 PARTITION p_overflow VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_log`
--

LOCK TABLES `access_log` WRITE;
/*!40000 ALTER TABLE `access_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `access_token_vaults`
--

DROP TABLE IF EXISTS `access_token_vaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_token_vaults` (
  `token_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  PRIMARY KEY (`token_id`,`vault_id`),
  KEY `ix_atv_vault` (`vault_id`),
  CONSTRAINT `fk_atv_token` FOREIGN KEY (`token_id`) REFERENCES `access_tokens` (`id`),
  CONSTRAINT `fk_atv_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_token_vaults`
--

LOCK TABLES `access_token_vaults` WRITE;
/*!40000 ALTER TABLE `access_token_vaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_token_vaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `access_tokens`
--

DROP TABLE IF EXISTS `access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_tokens` (
  `id` binary(16) NOT NULL,
  `token_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `kind` enum('pat','oauth','scim') NOT NULL DEFAULT 'pat',
  `name` varchar(120) NOT NULL,
  `display_prefix` char(26) NOT NULL,
  `scopes` json NOT NULL,
  `all_vaults` tinyint(1) NOT NULL DEFAULT '0',
  `admin_owned` tinyint(1) NOT NULL DEFAULT '0',
  `expires_at` datetime(6) NOT NULL,
  `last_used_at` datetime(6) DEFAULT NULL,
  `last_used_ip` varbinary(16) DEFAULT NULL,
  `last_client` varchar(120) DEFAULT NULL,
  `rate_limit_per_hour` int unsigned DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `created_from_session_id` binary(16) DEFAULT NULL,
  `created_ip` varbinary(16) DEFAULT NULL,
  `created_user_agent` varchar(255) DEFAULT NULL,
  `rotated_from_id` binary(16) DEFAULT NULL,
  `rotation_overlap_until` datetime(6) DEFAULT NULL,
  `revoked_at` datetime(6) DEFAULT NULL,
  `revoked_by` binary(16) DEFAULT NULL,
  `revoke_reason` varchar(120) DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `client_id` binary(16) DEFAULT NULL,
  `consent_id` binary(16) DEFAULT NULL,
  `refresh_id` binary(16) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tokens_token_id` (`token_id`),
  KEY `ix_tokens_user` (`user_id`,`revoked_at`,`expires_at`),
  KEY `ix_tokens_expires` (`expires_at`),
  KEY `ix_tokens_consent` (`consent_id`,`revoked_at`),
  KEY `ix_tokens_client` (`client_id`,`revoked_at`),
  CONSTRAINT `fk_tokens_oauth_client` FOREIGN KEY (`client_id`) REFERENCES `oauth_clients` (`id`),
  CONSTRAINT `fk_tokens_oauth_consent` FOREIGN KEY (`consent_id`) REFERENCES `oauth_consents` (`id`),
  CONSTRAINT `fk_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_tokens`
--

LOCK TABLES `access_tokens` WRITE;
/*!40000 ALTER TABLE `access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachments` (
  `id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `sha256` binary(32) NOT NULL,
  `size_bytes` bigint unsigned NOT NULL,
  `mime` varchar(127) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `path_hint` varchar(760) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci DEFAULT NULL,
  `storage_key` varchar(512) NOT NULL,
  `encryption` enum('none','aes256gcm') NOT NULL DEFAULT 'none',
  `key_version` tinyint unsigned DEFAULT NULL,
  `iv` varbinary(12) DEFAULT NULL,
  `auth_tag` varbinary(16) DEFAULT NULL,
  `uploaded_by` binary(16) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `live` tinyint GENERATED ALWAYS AS (if((`deleted_at` is null),1,NULL)) VIRTUAL,
  `version` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_attachment_vault_sha` (`vault_id`,`sha256`),
  UNIQUE KEY `uq_attachment_path` (`vault_id`,`path_hint`,`live`),
  KEY `ix_attachments_vault` (`vault_id`,`deleted_at`),
  CONSTRAINT `fk_att_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_chain_heads`
--

DROP TABLE IF EXISTS `audit_chain_heads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_chain_heads` (
  `chain_id` varchar(40) NOT NULL,
  `last_id` bigint unsigned NOT NULL,
  `last_hash` binary(32) NOT NULL,
  PRIMARY KEY (`chain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_chain_heads`
--

LOCK TABLES `audit_chain_heads` WRITE;
/*!40000 ALTER TABLE `audit_chain_heads` DISABLE KEYS */;
INSERT INTO `audit_chain_heads` VALUES ('server',69,0xF8FF94DA9389A63C1ED2CC7258935B2C990599BDBBD0DCC0507336B93B51A769),('vault:01a0b93912ca7336a5ccc1ecb6631f4f',75,0xF2468A0A9602F527D625B6AD0BF4DF08A6A495A763BB8181A9347FA6DB77C2D7);
/*!40000 ALTER TABLE `audit_chain_heads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_events`
--

DROP TABLE IF EXISTS `audit_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime(6) NOT NULL,
  `schema_version` smallint unsigned NOT NULL DEFAULT '1',
  `chain_id` varchar(40) NOT NULL,
  `action` varchar(64) NOT NULL,
  `actor_type` enum('user','token','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `actor_display` varchar(160) DEFAULT NULL,
  `on_behalf_of_user_id` binary(16) DEFAULT NULL,
  `credential_type` enum('session','pat','oauth','ticket','setpw','cli','system','none') NOT NULL,
  `credential_id` binary(16) DEFAULT NULL,
  `vault_id` binary(16) DEFAULT NULL,
  `target_type` varchar(32) DEFAULT NULL,
  `target_id` binary(16) DEFAULT NULL,
  `targets` json DEFAULT NULL,
  `outcome` enum('success','failure') NOT NULL,
  `reason` varchar(128) DEFAULT NULL,
  `context` json NOT NULL,
  `metadata` json DEFAULT NULL,
  `prev_hash` binary(32) NOT NULL,
  `hash` binary(32) NOT NULL,
  `key_version` tinyint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_audit_chain` (`chain_id`,`id`),
  KEY `ix_audit_vault_time` (`vault_id`,`occurred_at`),
  KEY `ix_audit_actor_time` (`actor_id`,`occurred_at`),
  KEY `ix_audit_action_time` (`action`,`occurred_at`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_events`
--

LOCK TABLES `audit_events` WRITE;
/*!40000 ALTER TABLE `audit_events` DISABLE KEYS */;
INSERT INTO `audit_events` VALUES (1,'2026-09-19 10:31:58.854000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0001_users\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x0000000000000000000000000000000000000000000000000000000000000000,0x3B9C17B7B9007C59FF26854EDC24F3D7FF4E5D46106980D619F052714FD35D39,1),(2,'2026-09-19 10:31:58.857000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0002_user_credentials\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x3B9C17B7B9007C59FF26854EDC24F3D7FF4E5D46106980D619F052714FD35D39,0xD674DD5EBE584465CAEC9B66A0A87622C839BBAE733AF8205A72E544A4AA3AF2,1),(3,'2026-09-19 10:31:58.859000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0003_password_setup_tokens\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xD674DD5EBE584465CAEC9B66A0A87622C839BBAE733AF8205A72E544A4AA3AF2,0x879850D406A175E51D1FE1C5C3B0AA31D5318DD03F7B25882C5438B0C556A2A3,1),(4,'2026-09-19 10:31:58.861000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0004_sessions\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x879850D406A175E51D1FE1C5C3B0AA31D5318DD03F7B25882C5438B0C556A2A3,0x8204F69A7209863C653A363DAC35B14497D5CFFE71CDEFC9483266FA58ABCC2B,1),(5,'2026-09-19 10:31:58.862000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0005_login_throttle\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x8204F69A7209863C653A363DAC35B14497D5CFFE71CDEFC9483266FA58ABCC2B,0xC6C51F6AB38219019E0961B50CD05DAC35E89A4EB9CE9D7363FCBCFDB7E62E54,1),(6,'2026-09-19 10:31:58.864000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0006_vaults\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xC6C51F6AB38219019E0961B50CD05DAC35E89A4EB9CE9D7363FCBCFDB7E62E54,0xA88E0BAC0E272DED6D9A20AE88123DC4ECC920EB11BC139D69F8DC8BCC7D8485,1),(7,'2026-09-19 10:31:58.866000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0007_vault_members\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xA88E0BAC0E272DED6D9A20AE88123DC4ECC920EB11BC139D69F8DC8BCC7D8485,0xF5208D64585E953E15AE56115278DC82DE0C016FE1975055B856CB98437F5E4A,1),(8,'2026-09-19 10:31:58.867000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0008_access_tokens\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xF5208D64585E953E15AE56115278DC82DE0C016FE1975055B856CB98437F5E4A,0x9A765937CC7DC9864C3D052FC0E4B895BA2BA15C3B20A4824E162E30F0D3FE53,1),(9,'2026-09-19 10:31:58.869000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0009_access_token_vaults\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x9A765937CC7DC9864C3D052FC0E4B895BA2BA15C3B20A4824E162E30F0D3FE53,0xBB063B66D2CD2FC3791EA9A1A72C1B974737F6520C4B6852BDD9699D7A667D22,1),(10,'2026-09-19 10:31:58.871000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0010_nodes\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xBB063B66D2CD2FC3791EA9A1A72C1B974737F6520C4B6852BDD9699D7A667D22,0xBD1B7DDDE0D724B1878B10BB9394182AA2C784AECE95D7E9DA8A95404BB231C1,1),(11,'2026-09-19 10:31:58.872000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0011_nodes_uq_sibling\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xBD1B7DDDE0D724B1878B10BB9394182AA2C784AECE95D7E9DA8A95404BB231C1,0x4B083A10E033D025DCE69817DE70B8A8516A4D24691343CDED3DF10EADC5EAD8,1),(12,'2026-09-19 10:31:58.874000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0012_trash_entries\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x4B083A10E033D025DCE69817DE70B8A8516A4D24691343CDED3DF10EADC5EAD8,0x6585C122E9CAFA45C635FD2F5EBFD5BF4D7260020B0FB101ECCD13A89137D6E3,1),(13,'2026-09-19 10:31:58.875000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0013_notes\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x6585C122E9CAFA45C635FD2F5EBFD5BF4D7260020B0FB101ECCD13A89137D6E3,0xD883DC3227C594382DE9E6AC74AEB4E4775ACD1ABDFF390A77A5342AF5247A6E,1),(14,'2026-09-19 10:31:58.877000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0014_note_docs\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xD883DC3227C594382DE9E6AC74AEB4E4775ACD1ABDFF390A77A5342AF5247A6E,0x5BD7A49EF51198690A2ED77392BB8EA005F3194FC47014816733C21977DDB1C7,1),(15,'2026-09-19 10:31:58.878000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0015_note_updates\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x5BD7A49EF51198690A2ED77392BB8EA005F3194FC47014816733C21977DDB1C7,0xD6441A92B5B7AD52594BCD0ACEC26A246F2EC6BDC5E5946E63B9286E3049D547,1),(16,'2026-09-19 10:31:58.880000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0016_note_revisions\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xD6441A92B5B7AD52594BCD0ACEC26A246F2EC6BDC5E5946E63B9286E3049D547,0x0DEEC27CE3AE13F3593FCC25AD6C94D6F618CC0CEC08CF7800C33DD8FB0A183F,1),(17,'2026-09-19 10:31:58.881000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0017_note_projections\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x0DEEC27CE3AE13F3593FCC25AD6C94D6F618CC0CEC08CF7800C33DD8FB0A183F,0x76305D2FAE9136A6435DF4ED457950A304B507620C1A95115AF7F4107AF114D1,1),(18,'2026-09-19 10:31:58.883000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0018_note_projections_fm_indexes\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x76305D2FAE9136A6435DF4ED457950A304B507620C1A95115AF7F4107AF114D1,0x24658369724094A77D65DB7517106541E4D23B9025E1D3A4DC924DCEEBF0F328,1),(19,'2026-09-19 10:31:58.884000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0019_note_search\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x24658369724094A77D65DB7517106541E4D23B9025E1D3A4DC924DCEEBF0F328,0x5EB3A174592FF33F3A0E92973A6B1395CA2D15B6A6167316AD87FD814C37E616,1),(20,'2026-09-19 10:31:58.886000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0020_note_search_fulltext\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x5EB3A174592FF33F3A0E92973A6B1395CA2D15B6A6167316AD87FD814C37E616,0x5DB4CD6DEAE963E906A20987B659165A6584DA0C300E74CB56F930F7747E0336,1),(21,'2026-09-19 10:31:58.889000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0021_note_links\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x5DB4CD6DEAE963E906A20987B659165A6584DA0C300E74CB56F930F7747E0336,0x53CC45F44DEFF5D56E170D9988E0C71715161080DF2B487B25A3FD6B6D2CEEB9,1),(22,'2026-09-19 10:31:58.890000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0022_attachments\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x53CC45F44DEFF5D56E170D9988E0C71715161080DF2B487B25A3FD6B6D2CEEB9,0xC66D5356A5509E4C565AE966F74CD529915F285B3B5BD9109DC44418BFF144DE,1),(23,'2026-09-19 10:31:58.892000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0023_jobs\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xC66D5356A5509E4C565AE966F74CD529915F285B3B5BD9109DC44418BFF144DE,0x3D34297782A1E7FD7DABB3BB78FF360EAF43840EE17984B71765DF00C1E36809,1),(24,'2026-09-19 10:31:58.893000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0024_import_jobs\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x3D34297782A1E7FD7DABB3BB78FF360EAF43840EE17984B71765DF00C1E36809,0xAE6496B5D2AEB35206F1E11D856559595A46AD2367940EA7C290D9334AB8D428,1),(25,'2026-09-19 10:31:58.895000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0025_export_jobs\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xAE6496B5D2AEB35206F1E11D856559595A46AD2367940EA7C290D9334AB8D428,0x5DFCC52A0BCE0582D9A10B467AF57A1A8D1BBF3B7469EB4FC1813550A764B753,1),(26,'2026-09-19 10:31:58.896000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0026_audit_events\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x5DFCC52A0BCE0582D9A10B467AF57A1A8D1BBF3B7469EB4FC1813550A764B753,0x28944D8AD88C63FABE454B8FC361110AFBF10C0C624138FD5136C20CCD430FB1,1),(27,'2026-09-19 10:31:58.897000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0027_audit_chain_heads\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x28944D8AD88C63FABE454B8FC361110AFBF10C0C624138FD5136C20CCD430FB1,0x3F53C29904F3C0A3A9D64F28B4BAB832FB5D54DA5BEE06A092EC31D740601C72,1),(28,'2026-09-19 10:31:58.899000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0028_audit_events_triggers\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x3F53C29904F3C0A3A9D64F28B4BAB832FB5D54DA5BEE06A092EC31D740601C72,0xA550ACE0E05DD22997776452098033E3AF09CDD76A754B83F6E44C00A49B4FEE,1),(29,'2026-09-19 10:31:58.900000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0029_audit_events_archive\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xA550ACE0E05DD22997776452098033E3AF09CDD76A754B83F6E44C00A49B4FEE,0x230FF77C93F9D7AAF8C284CE8A20FB437B35D7C7B00B742ADB2A8173E2E658D2,1),(30,'2026-09-19 10:31:58.902000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0030_access_log\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x230FF77C93F9D7AAF8C284CE8A20FB437B35D7C7B00B742ADB2A8173E2E658D2,0x271C38229D618DAD672F317C4EC1CDE0CD717AC0AE838BE4ED6EF9FBA1A2040E,1),(31,'2026-09-19 10:31:58.903000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0031_server_settings\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x271C38229D618DAD672F317C4EC1CDE0CD717AC0AE838BE4ED6EF9FBA1A2040E,0x6D4F438D3DF78529F6330FFE4C8EA5B06724C8C23EDE9BC122328C8ABA9B2022,1),(32,'2026-09-19 10:31:58.905000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0032_schema_meta\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x6D4F438D3DF78529F6330FFE4C8EA5B06724C8C23EDE9BC122328C8ABA9B2022,0x4B1828DDF4FE4FFF3AC6FA08155E1B868ED13610ECB93C2A6A135709E34202FA,1),(33,'2026-09-19 10:31:58.906000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0033_desktop_releases\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x4B1828DDF4FE4FFF3AC6FA08155E1B868ED13610ECB93C2A6A135709E34202FA,0x1388F95782E9693A6105D2431E3E6648AAB393D3073A60B1B8F1EFCAF19DB340,1),(34,'2026-09-19 10:31:58.907000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0034_grants\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x1388F95782E9693A6105D2431E3E6648AAB393D3073A60B1B8F1EFCAF19DB340,0x836DBA43B6A103E2B90F2694CF7B12974DA868F6197D6902A31BE2E06E33FB0A,1),(35,'2026-09-19 10:31:58.909000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0035_oauth_clients\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x836DBA43B6A103E2B90F2694CF7B12974DA868F6197D6902A31BE2E06E33FB0A,0x65F0C5C24459F08EB66DE4754348996BC60E9DCF2F1FF26DE93C6631D2946C0B,1),(36,'2026-09-19 10:31:58.910000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0036_oauth_clients_grants\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x65F0C5C24459F08EB66DE4754348996BC60E9DCF2F1FF26DE93C6631D2946C0B,0x1B3AEDEE61DCC0881C1F2FCC187150C89D54CDB270A7469FF501275C6B7CF6D4,1),(37,'2026-09-19 10:31:58.912000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0037_oauth_consents\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x1B3AEDEE61DCC0881C1F2FCC187150C89D54CDB270A7469FF501275C6B7CF6D4,0x5711205E00284F959B5565A89B1A4077149F2EA11CEBE8BC85C6CEF82344418B,1),(38,'2026-09-19 10:31:58.913000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0038_oauth_consents_uq_live\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x5711205E00284F959B5565A89B1A4077149F2EA11CEBE8BC85C6CEF82344418B,0xAF40E910EE53AB7EDB5BEB3E5608BCD00B53F33E4792ED8D418E806A3D001FFE,1),(39,'2026-09-19 10:31:58.915000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0039_oauth_consents_grants\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xAF40E910EE53AB7EDB5BEB3E5608BCD00B53F33E4792ED8D418E806A3D001FFE,0x42C2E8EB49E4C05548F8A553F90717E202E25D0E6E79350B897CD9B1F9E3EE7D,1),(40,'2026-09-19 10:31:58.916000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0040_oauth_consent_vaults\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x42C2E8EB49E4C05548F8A553F90717E202E25D0E6E79350B897CD9B1F9E3EE7D,0x18218CBE2D8BD7225AF811FA371F0138F566B5F76758B105C02A4F94088CB1B1,1),(41,'2026-09-19 10:31:58.918000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0041_oauth_consent_vaults_grants\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x18218CBE2D8BD7225AF811FA371F0138F566B5F76758B105C02A4F94088CB1B1,0x12AA639D8508C8CC5241551FAAABC110DF9E725A0AA6743251EB5A09C972D3E0,1),(42,'2026-09-19 10:31:58.920000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0042_oauth_authorization_codes\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x12AA639D8508C8CC5241551FAAABC110DF9E725A0AA6743251EB5A09C972D3E0,0x482EE48A80EAD80A3C3CFED0F69C79D6C4BDC53A599066CAED85409E625E9609,1),(43,'2026-09-19 10:31:58.921000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0043_oauth_authorization_codes_grants\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x482EE48A80EAD80A3C3CFED0F69C79D6C4BDC53A599066CAED85409E625E9609,0x75786E70C5437D6023C45206EDDF9D830BCD7A7859FC0CBA2513959C5B97039E,1),(44,'2026-09-19 10:31:58.923000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0044_oauth_refresh_tokens\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x75786E70C5437D6023C45206EDDF9D830BCD7A7859FC0CBA2513959C5B97039E,0xC704DBE1079FA84ADA067D591B648A83379F8AE5BE010EE55C518A11FF70BD94,1),(45,'2026-09-19 10:31:58.924000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0045_oauth_refresh_tokens_grants\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xC704DBE1079FA84ADA067D591B648A83379F8AE5BE010EE55C518A11FF70BD94,0xBBFA6F86B1792C8B9C50E0851382918EE253C270D8E8099B19CCE86FB2D00C59,1),(46,'2026-09-19 10:31:58.926000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0046_access_tokens_oauth_columns\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xBBFA6F86B1792C8B9C50E0851382918EE253C270D8E8099B19CCE86FB2D00C59,0x1527F1AABC697F7FED34074EA76FC112D0336B796128D89FA01DD984D1583507,1),(47,'2026-09-19 10:31:58.927000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0047_access_tokens_oauth_indexes\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x1527F1AABC697F7FED34074EA76FC112D0336B796128D89FA01DD984D1583507,0xBEDB3EAE6BDED977C3BC56D7FB6628EC566EF3DA24A5DE12737D1C41844E3134,1),(48,'2026-09-19 10:31:58.929000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0048_access_log_oauth_client\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xBEDB3EAE6BDED977C3BC56D7FB6628EC566EF3DA24A5DE12737D1C41844E3134,0x497CB2A77004744BB987F89F8955B78A21F3E4FA3B6780A246A86EC3A3955EF4,1),(49,'2026-09-19 10:31:58.930000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0049_admin_users_lock\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x497CB2A77004744BB987F89F8955B78A21F3E4FA3B6780A246A86EC3A3955EF4,0x7924173D1782589CCEFF40E4926483FA8A11F330D5B7FD8090833885602F31F5,1),(50,'2026-09-19 10:31:58.931000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0050_session_revocation_commands\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x7924173D1782589CCEFF40E4926483FA8A11F330D5B7FD8090833885602F31F5,0xA2B3EA10A0E41D0C6BAE528EB47269737756DB2B4E2C897377EB718863290D21,1),(51,'2026-09-19 10:31:58.933000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0051_session_revocation_commands_grants\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xA2B3EA10A0E41D0C6BAE528EB47269737756DB2B4E2C897377EB718863290D21,0x8E4C68A6F28D02E69BEEEA82F7ACC63EBA8A0DFCCD66A9F5CFF144B62D7226EC,1),(52,'2026-09-19 10:31:58.935000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0052_collab_owner_fence\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x8E4C68A6F28D02E69BEEEA82F7ACC63EBA8A0DFCCD66A9F5CFF144B62D7226EC,0x4AC57554E365514D7068E78D512811CFB75D76890EE7C919A3172AA4AD5B085E,1),(53,'2026-09-19 10:31:58.936000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0053_collab_owner_fence_grants\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x4AC57554E365514D7068E78D512811CFB75D76890EE7C919A3172AA4AD5B085E,0x054D0F2F894951D9A78537122258F21CFE8A95621FF56806955D0F06A7B4DCCA,1),(54,'2026-09-19 10:31:58.937000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0054_grants_provenance\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0x054D0F2F894951D9A78537122258F21CFE8A95621FF56806955D0F06A7B4DCCA,0xAE59278277145E8289E581ACF8882915AF0B56829882166721F5E3885BD3AAB9,1),(55,'2026-09-19 10:31:58.939000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\"}','{\"name\": \"0055_min_client_version\", \"batch\": \"01a0b939-0b5e-7a85-b852-cf7b4fca7db2\", \"duration_ms\": null}',0xAE59278277145E8289E581ACF8882915AF0B56829882166721F5E3885BD3AAB9,0xFB5357E79CA6E49915B9945770B00972EE6D14550ECEE8C022F8D6A327945E6E,1),(56,'2026-09-19 10:32:00.303000',1,'server','admin.user.created','system',NULL,NULL,NULL,'cli',NULL,NULL,'user',0x01A0B939122973D0A4903107FB7D87B5,NULL,'success',NULL,'{\"host\": \"DESKTOP-6PDT5SM\", \"os_user\": \"Vincent\", \"argv_shape\": \"admin create-user --email <value> --display-name <value> --server-admin\", \"request_id\": \"01a0b939-116f-7cb1-a790-e9ef233e21ca\"}','{\"displayName\": \"Kernel Admin\", \"isServerAdmin\": true, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0b939-122e-7434-a192-f0e787b5eab9\"}',0xFB5357E79CA6E49915B9945770B00972EE6D14550ECEE8C022F8D6A327945E6E,0x96D7EFDB02082CA1E68AB4873375755715044E9E16629411FEC9915C9BB4DF93,1),(57,'2026-09-19 10:32:00.356000',1,'server','user.password.set','user',0x01A0B939122973D0A4903107FB7D87B5,NULL,NULL,'setpw',0x01A0B939122E7434A192F0E787B5EAB9,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-124e-721c-9d54-9ae5c367ba16\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0x96D7EFDB02082CA1E68AB4873375755715044E9E16629411FEC9915C9BB4DF93,0x03DF58B0DDD665968302AA0987AAFA2DCA908AA3A7B4771594A172E0009D18D5,1),(58,'2026-09-19 10:32:00.376000',1,'server','user.login.succeeded','user',0x01A0B939122973D0A4903107FB7D87B5,'admin@iridium.test',NULL,'session',0x01A0B9391275789A9991C73F6156CCC7,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-126b-70d8-8ddb-cb377136260e\", \"user_agent\": \"node\"}','{\"kind\": \"web\", \"method\": \"password\", \"clientVersion\": \"0.0.0\"}',0x03DF58B0DDD665968302AA0987AAFA2DCA908AA3A7B4771594A172E0009D18D5,0xD3742B28430A1991AA4FA5042941972F8261B19B016707127FF778231ABA133D,1),(59,'2026-09-19 10:32:00.393000',1,'server','user.reauth.succeeded','user',0x01A0B939122973D0A4903107FB7D87B5,'admin@iridium.test',NULL,'session',0x01A0B9391275789A9991C73F6156CCC7,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-127f-71a0-a306-5a372de49cf4\", \"user_agent\": \"node\"}','{}',0xD3742B28430A1991AA4FA5042941972F8261B19B016707127FF778231ABA133D,0xE5758EEF660B23A17E02CF16742890F610FED783B5A950E5B40A566180A442CD,1),(60,'2026-09-19 10:32:00.411000',1,'server','admin.user.created','user',0x01A0B939122973D0A4903107FB7D87B5,'Kernel Admin',NULL,'session',0x01A0B9391275789A9991C73F6156CCC7,NULL,'user',0x01A0B93912947BD1B6B5232888D9BD1D,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-128e-7260-9ef9-eb8b28167b8c\", \"user_agent\": \"node\"}','{\"displayName\": \"editorA\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0b939-129a-7af8-adf1-16970842f35d\"}',0xE5758EEF660B23A17E02CF16742890F610FED783B5A950E5B40A566180A442CD,0xD36B71CD9B8A97D4C740BA8CBF5DC79C75EA2D2BF2B9B84BDA1E557B01E8140F,1),(61,'2026-09-19 10:32:00.418000',1,'server','admin.user.created','user',0x01A0B939122973D0A4903107FB7D87B5,'Kernel Admin',NULL,'session',0x01A0B9391275789A9991C73F6156CCC7,NULL,'user',0x01A0B93912947BD29D4BA56C33A58B9D,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-128f-7bd1-88cc-aead75878c81\", \"user_agent\": \"node\"}','{\"displayName\": \"editorB\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0b939-12a0-7ff7-ba56-7b74ebfa0369\"}',0xD36B71CD9B8A97D4C740BA8CBF5DC79C75EA2D2BF2B9B84BDA1E557B01E8140F,0x155D75DD10E4384A6A00D282B94598400FF0034873394504001F1A4C68B36314,1),(62,'2026-09-19 10:32:00.424000',1,'server','admin.user.created','user',0x01A0B939122973D0A4903107FB7D87B5,'Kernel Admin',NULL,'session',0x01A0B9391275789A9991C73F6156CCC7,NULL,'user',0x01A0B93912987880ACFD8BF2B9513BC7,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-128f-7bd3-9984-2d898dec6ca3\", \"user_agent\": \"node\"}','{\"displayName\": \"editorC\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0b939-12a7-7d2e-8e36-816f85141e90\"}',0x155D75DD10E4384A6A00D282B94598400FF0034873394504001F1A4C68B36314,0x22E599029E82E1B63C87CC4BAC41BFE43654AD635DE98975479459786A53EEFC,1),(63,'2026-09-19 10:32:00.431000',1,'server','admin.user.created','user',0x01A0B939122973D0A4903107FB7D87B5,'Kernel Admin',NULL,'session',0x01A0B9391275789A9991C73F6156CCC7,NULL,'user',0x01A0B93912987881A432F1816775E7D1,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-1290-7c40-8412-57890831796d\", \"user_agent\": \"node\"}','{\"displayName\": \"viewer\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0b939-12ad-702e-8a84-760dd1af1b33\"}',0x22E599029E82E1B63C87CC4BAC41BFE43654AD635DE98975479459786A53EEFC,0xEDB448832EC54A762C52CCDDA30C18660D2F7AFD4A7A4DF3A20AFC8306968F08,1),(64,'2026-09-19 10:32:00.433000',1,'server','user.password.set','user',0x01A0B93912947BD1B6B5232888D9BD1D,NULL,NULL,'setpw',0x01A0B939129A7AF8ADF116970842F35D,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-129f-7ca6-9046-1e926b7d2f77\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0xEDB448832EC54A762C52CCDDA30C18660D2F7AFD4A7A4DF3A20AFC8306968F08,0x29BD4E777FBDD3C70DE6A8E92BB9A1B8BB115FA07F09AB565629D035562D401F,1),(65,'2026-09-19 10:32:00.437000',1,'server','user.password.set','user',0x01A0B93912947BD29D4BA56C33A58B9D,NULL,NULL,'setpw',0x01A0B93912A07FF7BA567B74EBFA0369,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-12a6-7ae4-a6a9-282d0e5790b3\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0x29BD4E777FBDD3C70DE6A8E92BB9A1B8BB115FA07F09AB565629D035562D401F,0xDBB91C2D719BF41B4129C6A720D261547DBA556D50461988E7C8F7FB8BC13385,1),(66,'2026-09-19 10:32:00.439000',1,'server','admin.user.created','user',0x01A0B939122973D0A4903107FB7D87B5,'Kernel Admin',NULL,'session',0x01A0B9391275789A9991C73F6156CCC7,NULL,'user',0x01A0B93912987882947FE533AEB9000F,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-1290-7c42-a446-487652aa9b03\", \"user_agent\": \"node\"}','{\"displayName\": \"outsider\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0b939-12b5-7238-9ffb-cf0ae5eff753\"}',0xDBB91C2D719BF41B4129C6A720D261547DBA556D50461988E7C8F7FB8BC13385,0xA8864712D9E12BFB1AADC8AFF7B7403BE715E6214A55448337DB775A04EB4C10,1),(67,'2026-09-19 10:32:00.441000',1,'server','user.password.set','user',0x01A0B93912987880ACFD8BF2B9513BC7,NULL,NULL,'setpw',0x01A0B93912A77D2E8E36816F85141E90,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-12ac-7f97-b6bf-d135fe787f4e\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0xA8864712D9E12BFB1AADC8AFF7B7403BE715E6214A55448337DB775A04EB4C10,0xA97078A4F8BAE05C81E266B2164E236E284DE3CED75BFBA57D7DB83CE1FA0F7A,1),(68,'2026-09-19 10:32:00.447000',1,'server','user.password.set','user',0x01A0B93912987881A432F1816775E7D1,NULL,NULL,'setpw',0x01A0B93912AD702E8A84760DD1AF1B33,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-12b3-7432-900f-ecbf1a33f8b0\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0xA97078A4F8BAE05C81E266B2164E236E284DE3CED75BFBA57D7DB83CE1FA0F7A,0xCDCB09654418AC034D17F3E9CF56C0ACA787CF040149A2E7DFEDB03A2D7DC38B,1),(69,'2026-09-19 10:32:00.453000',1,'server','user.password.set','user',0x01A0B93912987882947FE533AEB9000F,NULL,NULL,'setpw',0x01A0B93912B572389FFBCF0AE5EFF753,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-12bb-72b4-8f60-45c96c797428\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0xCDCB09654418AC034D17F3E9CF56C0ACA787CF040149A2E7DFEDB03A2D7DC38B,0xF8FF94DA9389A63C1ED2CC7258935B2C990599BDBBD0DCC0507336B93B51A769,1),(70,'2026-09-19 10:32:00.462000',1,'vault:01a0b93912ca7336a5ccc1ecb6631f4f','vault.created','user',0x01A0B939122973D0A4903107FB7D87B5,'Kernel Admin',NULL,'session',0x01A0B9391275789A9991C73F6156CCC7,0x01A0B93912CA7336A5CCC1ECB6631F4F,'vault',0x01A0B93912CA7336A5CCC1ECB6631F4F,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-12c7-7117-8b85-4ae644c54a25\", \"user_agent\": \"node\"}','{\"name\": \"Kernel\", \"slug\": \"kernel\", \"memberCount\": 0}',0x0000000000000000000000000000000000000000000000000000000000000000,0x35F9A798065A5CB4D9F3B5CB2CCDA2B1CC9E5CF6A77B21621655888D0E635842,1),(71,'2026-09-19 10:32:00.477000',1,'vault:01a0b93912ca7336a5ccc1ecb6631f4f','vault.member.added','user',0x01A0B939122973D0A4903107FB7D87B5,'Kernel Admin',NULL,'session',0x01A0B9391275789A9991C73F6156CCC7,0x01A0B93912CA7336A5CCC1ECB6631F4F,'user',0x01A0B93912947BD1B6B5232888D9BD1D,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-12d4-7bd4-98bf-ba70f0daf9b0\", \"user_agent\": \"node\"}','{\"role\": \"editor\", \"targetDisplay\": \"editorA\"}',0x35F9A798065A5CB4D9F3B5CB2CCDA2B1CC9E5CF6A77B21621655888D0E635842,0xD9367F891252ADF69F15D8BC99FCA0C37BAC525DACAFDC06847DFCDA89B693A4,1),(72,'2026-09-19 10:32:00.487000',1,'vault:01a0b93912ca7336a5ccc1ecb6631f4f','vault.member.added','user',0x01A0B939122973D0A4903107FB7D87B5,'Kernel Admin',NULL,'session',0x01A0B9391275789A9991C73F6156CCC7,0x01A0B93912CA7336A5CCC1ECB6631F4F,'user',0x01A0B93912947BD29D4BA56C33A58B9D,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-12e0-79e7-9cd1-f08db802cd31\", \"user_agent\": \"node\"}','{\"role\": \"editor\", \"targetDisplay\": \"editorB\"}',0xD9367F891252ADF69F15D8BC99FCA0C37BAC525DACAFDC06847DFCDA89B693A4,0x6CEBC8D8C65571F73A1013D75F69EB510B473CDDB7A413F6F2983DCAE971F05D,1),(73,'2026-09-19 10:32:00.495000',1,'vault:01a0b93912ca7336a5ccc1ecb6631f4f','vault.member.added','user',0x01A0B939122973D0A4903107FB7D87B5,'Kernel Admin',NULL,'session',0x01A0B9391275789A9991C73F6156CCC7,0x01A0B93912CA7336A5CCC1ECB6631F4F,'user',0x01A0B93912987880ACFD8BF2B9513BC7,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-12e9-7f1b-a413-84591ceceeb8\", \"user_agent\": \"node\"}','{\"role\": \"editor\", \"targetDisplay\": \"editorC\"}',0x6CEBC8D8C65571F73A1013D75F69EB510B473CDDB7A413F6F2983DCAE971F05D,0xD60E95174FD216DC8D1697584D1F42D0D927B8D925A9C1854F2537DBCD07FC2D,1),(74,'2026-09-19 10:32:00.504000',1,'vault:01a0b93912ca7336a5ccc1ecb6631f4f','vault.member.added','user',0x01A0B939122973D0A4903107FB7D87B5,'Kernel Admin',NULL,'session',0x01A0B9391275789A9991C73F6156CCC7,0x01A0B93912CA7336A5CCC1ECB6631F4F,'user',0x01A0B93912987881A432F1816775E7D1,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-12f2-7640-a2de-c297d7da2700\", \"user_agent\": \"node\"}','{\"role\": \"viewer\", \"targetDisplay\": \"viewer\"}',0xD60E95174FD216DC8D1697584D1F42D0D927B8D925A9C1854F2537DBCD07FC2D,0x90CCB227C05A20B3736EB8E15C335C3645158D0985B5FD2CE7E92E6124AF67E2,1),(75,'2026-09-19 10:32:00.523000',1,'vault:01a0b93912ca7336a5ccc1ecb6631f4f','node.created','user',0x01A0B939122973D0A4903107FB7D87B5,'Kernel Admin',NULL,'session',0x01A0B9391275789A9991C73F6156CCC7,0x01A0B93912CA7336A5CCC1ECB6631F4F,'node',0x01A0B93912FE74A5A0829D7AB7881277,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0b939-12fb-777f-9e44-ebc0f0349f7d\", \"user_agent\": \"node\"}','{\"kind\": \"note\", \"name\": \"Kernel Note\", \"parentId\": \"01a0b939-12ca-7337-81e2-e5acf72411f0\"}',0x90CCB227C05A20B3736EB8E15C335C3645158D0985B5FD2CE7E92E6124AF67E2,0xF2468A0A9602F527D625B6AD0BF4DF08A6A495A763BB8181A9347FA6DB77C2D7,1);
/*!40000 ALTER TABLE `audit_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_events_archive`
--

DROP TABLE IF EXISTS `audit_events_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_events_archive` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime(6) NOT NULL,
  `schema_version` smallint unsigned NOT NULL DEFAULT '1',
  `chain_id` varchar(40) NOT NULL,
  `action` varchar(64) NOT NULL,
  `actor_type` enum('user','token','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `actor_display` varchar(160) DEFAULT NULL,
  `on_behalf_of_user_id` binary(16) DEFAULT NULL,
  `credential_type` enum('session','pat','oauth','ticket','setpw','cli','system','none') NOT NULL,
  `credential_id` binary(16) DEFAULT NULL,
  `vault_id` binary(16) DEFAULT NULL,
  `target_type` varchar(32) DEFAULT NULL,
  `target_id` binary(16) DEFAULT NULL,
  `targets` json DEFAULT NULL,
  `outcome` enum('success','failure') NOT NULL,
  `reason` varchar(128) DEFAULT NULL,
  `context` json NOT NULL,
  `metadata` json DEFAULT NULL,
  `prev_hash` binary(32) NOT NULL,
  `hash` binary(32) NOT NULL,
  `key_version` tinyint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_audit_chain` (`chain_id`,`id`),
  KEY `ix_audit_vault_time` (`vault_id`,`occurred_at`),
  KEY `ix_audit_actor_time` (`actor_id`,`occurred_at`),
  KEY `ix_audit_action_time` (`action`,`occurred_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_events_archive`
--

LOCK TABLES `audit_events_archive` WRITE;
/*!40000 ALTER TABLE `audit_events_archive` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_events_archive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collab_owner_fence`
--

DROP TABLE IF EXISTS `collab_owner_fence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collab_owner_fence` (
  `id` tinyint unsigned NOT NULL,
  `generation` binary(16) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `chk_collab_owner_fence_singleton` CHECK ((`id` = 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collab_owner_fence`
--

LOCK TABLES `collab_owner_fence` WRITE;
/*!40000 ALTER TABLE `collab_owner_fence` DISABLE KEYS */;
INSERT INTO `collab_owner_fence` VALUES (1,0xDEBAE2CED920FF476CD5477F5DA22495);
/*!40000 ALTER TABLE `collab_owner_fence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `desktop_releases`
--

DROP TABLE IF EXISTS `desktop_releases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `desktop_releases` (
  `version` varchar(32) NOT NULL,
  `channel` enum('stable','beta') NOT NULL,
  `published_at` datetime(6) NOT NULL,
  `published_by` binary(16) DEFAULT NULL,
  `notes` text,
  `files` json NOT NULL,
  `withdrawn_at` datetime(6) DEFAULT NULL,
  `withdrawn_by` binary(16) DEFAULT NULL,
  PRIMARY KEY (`version`,`channel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `desktop_releases`
--

LOCK TABLES `desktop_releases` WRITE;
/*!40000 ALTER TABLE `desktop_releases` DISABLE KEYS */;
/*!40000 ALTER TABLE `desktop_releases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `export_jobs`
--

DROP TABLE IF EXISTS `export_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `export_jobs` (
  `job_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `scope_node_id` binary(16) DEFAULT NULL,
  `format` enum('zip') NOT NULL,
  `restore_eol` tinyint(1) NOT NULL DEFAULT '1',
  `include_attachments` tinyint(1) NOT NULL DEFAULT '1',
  `include_trashed` tinyint(1) NOT NULL DEFAULT '0',
  `manifest` json DEFAULT NULL,
  `artifact_key` varchar(512) DEFAULT NULL,
  `artifact_sha256` binary(32) DEFAULT NULL,
  `size_bytes` bigint unsigned DEFAULT NULL,
  `expires_at` datetime(6) NOT NULL,
  PRIMARY KEY (`job_id`),
  CONSTRAINT `fk_export_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export_jobs`
--

LOCK TABLES `export_jobs` WRITE;
/*!40000 ALTER TABLE `export_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `export_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_jobs`
--

DROP TABLE IF EXISTS `import_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_jobs` (
  `job_id` binary(16) NOT NULL,
  `target_vault_id` binary(16) DEFAULT NULL,
  `target_parent_id` binary(16) DEFAULT NULL,
  `source_kind` enum('zip','files') NOT NULL,
  `source_sha256` binary(32) DEFAULT NULL,
  `staging_key` varchar(512) NOT NULL,
  `phase` enum('uploading','scanning','reported','committing','done','failed','aborted') NOT NULL,
  `report` json DEFAULT NULL,
  `options` json DEFAULT NULL,
  `stats` json DEFAULT NULL,
  `committed_at` datetime(6) DEFAULT NULL,
  `expires_at` datetime(6) NOT NULL,
  PRIMARY KEY (`job_id`),
  CONSTRAINT `fk_import_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_jobs`
--

LOCK TABLES `import_jobs` WRITE;
/*!40000 ALTER TABLE `import_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `import_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` binary(16) NOT NULL,
  `type` varchar(48) NOT NULL,
  `status` enum('queued','running','succeeded','failed','cancelled') NOT NULL,
  `vault_id` binary(16) DEFAULT NULL,
  `requested_by` binary(16) DEFAULT NULL,
  `payload` json NOT NULL,
  `progress` json DEFAULT NULL,
  `result` json DEFAULT NULL,
  `error` text,
  `attempts` tinyint unsigned NOT NULL DEFAULT '0',
  `locked_by` varchar(64) DEFAULT NULL,
  `locked_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `started_at` datetime(6) DEFAULT NULL,
  `finished_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_jobs_status` (`status`,`created_at`),
  KEY `ix_jobs_vault_type` (`vault_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kysely_migration`
--

DROP TABLE IF EXISTS `kysely_migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kysely_migration` (
  `name` varchar(255) NOT NULL,
  `timestamp` varchar(255) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kysely_migration`
--

LOCK TABLES `kysely_migration` WRITE;
/*!40000 ALTER TABLE `kysely_migration` DISABLE KEYS */;
INSERT INTO `kysely_migration` VALUES ('0001_users','2026-09-19T10:31:58.603Z'),('0002_user_credentials','2026-09-19T10:31:58.606Z'),('0003_password_setup_tokens','2026-09-19T10:31:58.610Z'),('0004_sessions','2026-09-19T10:31:58.613Z'),('0005_login_throttle','2026-09-19T10:31:58.615Z'),('0006_vaults','2026-09-19T10:31:58.618Z'),('0007_vault_members','2026-09-19T10:31:58.623Z'),('0008_access_tokens','2026-09-19T10:31:58.627Z'),('0009_access_token_vaults','2026-09-19T10:31:58.630Z'),('0010_nodes','2026-09-19T10:31:58.634Z'),('0011_nodes_uq_sibling','2026-09-19T10:31:58.640Z'),('0012_trash_entries','2026-09-19T10:31:58.643Z'),('0013_notes','2026-09-19T10:31:58.647Z'),('0014_note_docs','2026-09-19T10:31:58.651Z'),('0015_note_updates','2026-09-19T10:31:58.654Z'),('0016_note_revisions','2026-09-19T10:31:58.657Z'),('0017_note_projections','2026-09-19T10:31:58.661Z'),('0018_note_projections_fm_indexes','2026-09-19T10:31:58.667Z'),('0019_note_search','2026-09-19T10:31:58.670Z'),('0020_note_search_fulltext','2026-09-19T10:31:58.681Z'),('0021_note_links','2026-09-19T10:31:58.686Z'),('0022_attachments','2026-09-19T10:31:58.690Z'),('0023_jobs','2026-09-19T10:31:58.693Z'),('0024_import_jobs','2026-09-19T10:31:58.696Z'),('0025_export_jobs','2026-09-19T10:31:58.700Z'),('0026_audit_events','2026-09-19T10:31:58.703Z'),('0027_audit_chain_heads','2026-09-19T10:31:58.705Z'),('0028_audit_events_triggers','2026-09-19T10:31:58.708Z'),('0029_audit_events_archive','2026-09-19T10:31:58.715Z'),('0030_access_log','2026-09-19T10:31:58.720Z'),('0031_server_settings','2026-09-19T10:31:58.722Z'),('0032_schema_meta','2026-09-19T10:31:58.724Z'),('0033_desktop_releases','2026-09-19T10:31:58.726Z'),('0034_grants','2026-09-19T10:31:58.747Z'),('0035_oauth_clients','2026-09-19T10:31:58.751Z'),('0036_oauth_clients_grants','2026-09-19T10:31:58.753Z'),('0037_oauth_consents','2026-09-19T10:31:58.757Z'),('0038_oauth_consents_uq_live','2026-09-19T10:31:58.762Z'),('0039_oauth_consents_grants','2026-09-19T10:31:58.764Z'),('0040_oauth_consent_vaults','2026-09-19T10:31:58.768Z'),('0041_oauth_consent_vaults_grants','2026-09-19T10:31:58.770Z'),('0042_oauth_authorization_codes','2026-09-19T10:31:58.776Z'),('0043_oauth_authorization_codes_grants','2026-09-19T10:31:58.778Z'),('0044_oauth_refresh_tokens','2026-09-19T10:31:58.785Z'),('0045_oauth_refresh_tokens_grants','2026-09-19T10:31:58.787Z'),('0046_access_tokens_oauth_columns','2026-09-19T10:31:58.798Z'),('0047_access_tokens_oauth_indexes','2026-09-19T10:31:58.805Z'),('0048_access_log_oauth_client','2026-09-19T10:31:58.810Z'),('0049_admin_users_lock','2026-09-19T10:31:58.811Z'),('0050_session_revocation_commands','2026-09-19T10:31:58.813Z'),('0051_session_revocation_commands_grants','2026-09-19T10:31:58.815Z'),('0052_collab_owner_fence','2026-09-19T10:31:58.818Z'),('0053_collab_owner_fence_grants','2026-09-19T10:31:58.820Z'),('0054_grants_provenance','2026-09-19T10:31:58.838Z'),('0055_min_client_version','2026-09-19T10:31:58.839Z');
/*!40000 ALTER TABLE `kysely_migration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kysely_migration_lock`
--

DROP TABLE IF EXISTS `kysely_migration_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kysely_migration_lock` (
  `id` varchar(255) NOT NULL,
  `is_locked` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kysely_migration_lock`
--

LOCK TABLES `kysely_migration_lock` WRITE;
/*!40000 ALTER TABLE `kysely_migration_lock` DISABLE KEYS */;
INSERT INTO `kysely_migration_lock` VALUES ('migration_lock',0);
/*!40000 ALTER TABLE `kysely_migration_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_throttle`
--

DROP TABLE IF EXISTS `login_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_throttle` (
  `key` varchar(191) NOT NULL,
  `points` int NOT NULL,
  `expire` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_throttle`
--

LOCK TABLES `login_throttle` WRITE;
/*!40000 ALTER TABLE `login_throttle` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nodes`
--

DROP TABLE IF EXISTS `nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nodes` (
  `id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `parent_id` binary(16) NOT NULL,
  `kind` enum('category','note') NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `live` tinyint GENERATED ALWAYS AS (if((`deleted_at` is null),1,NULL)) VIRTUAL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_by` binary(16) NOT NULL,
  `updated_by` binary(16) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sibling` (`parent_id`,`name`,`live`),
  KEY `ix_nodes_vault_parent` (`vault_id`,`parent_id`,`kind`),
  KEY `ix_nodes_vault_deleted` (`vault_id`,`deleted_at`),
  KEY `ix_nodes_vault_name` (`vault_id`,`name`),
  CONSTRAINT `fk_nodes_parent` FOREIGN KEY (`parent_id`) REFERENCES `nodes` (`id`),
  CONSTRAINT `fk_nodes_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nodes`
--

LOCK TABLES `nodes` WRITE;
/*!40000 ALTER TABLE `nodes` DISABLE KEYS */;
INSERT INTO `nodes` (`id`, `vault_id`, `parent_id`, `kind`, `name`, `deleted_at`, `version`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES (0x01A0B93912CA733781E2E5ACF72411F0,0x01A0B93912CA7336A5CCC1ECB6631F4F,0x01A0B93912CA733781E2E5ACF72411F0,'category','',NULL,1,0x01A0B939122973D0A4903107FB7D87B5,0x01A0B939122973D0A4903107FB7D87B5,'2026-09-19 10:32:00.458000','2026-09-19 10:32:00.458000'),(0x01A0B93912FE74A5A0829D7AB7881277,0x01A0B93912CA7336A5CCC1ECB6631F4F,0x01A0B93912CA733781E2E5ACF72411F0,'note','Kernel Note',NULL,1,0x01A0B939122973D0A4903107FB7D87B5,0x01A0B939122973D0A4903107FB7D87B5,'2026-09-19 10:32:00.513000','2026-09-19 10:32:00.513000');
/*!40000 ALTER TABLE `nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_docs`
--

DROP TABLE IF EXISTS `note_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_docs` (
  `note_id` binary(16) NOT NULL,
  `head_seq` bigint unsigned NOT NULL DEFAULT '0',
  `snapshot_format` tinyint unsigned NOT NULL DEFAULT '2',
  `yjs_major` tinyint unsigned NOT NULL DEFAULT '13',
  `snapshot` longblob,
  `snapshot_sv` varbinary(4096) DEFAULT NULL,
  `snapshot_through_seq` bigint unsigned NOT NULL DEFAULT '0',
  `snapshot_size` int unsigned NOT NULL DEFAULT '0',
  `snapshot_at` datetime(6) DEFAULT NULL,
  `projected_seq` bigint unsigned NOT NULL DEFAULT '0',
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`note_id`),
  CONSTRAINT `fk_docs_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_docs`
--

LOCK TABLES `note_docs` WRITE;
/*!40000 ALTER TABLE `note_docs` DISABLE KEYS */;
INSERT INTO `note_docs` VALUES (0x01A0B93912FE74A5A0829D7AB7881277,1,2,13,0x00000583A5C6AE13000001042825636F6E74656E74E29FA6494D504F52542D4D41524BE29FA7206B65726E656C206E6F74650A071A0101000001010000,0x01C392A3D7091A,1,61,'2026-09-19 10:32:00.513000',1,'2026-09-19 10:32:00.513000');
/*!40000 ALTER TABLE `note_docs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_links`
--

DROP TABLE IF EXISTS `note_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `from_note_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `revision` bigint unsigned NOT NULL,
  `ordinal` int unsigned NOT NULL,
  `kind` enum('markdown','image','wikilink','embed','definition') NOT NULL,
  `raw_target` varchar(2048) NOT NULL,
  `resolved_node_id` binary(16) DEFAULT NULL,
  `resolved_attachment_id` binary(16) DEFAULT NULL,
  `fragment` varchar(255) DEFAULT NULL,
  `status` enum('resolved','ambiguous','broken','external') NOT NULL,
  `start_offset` int unsigned NOT NULL,
  `end_offset` int unsigned NOT NULL,
  `line` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_links_from_ordinal` (`from_note_id`,`ordinal`),
  KEY `ix_links_target_node` (`vault_id`,`resolved_node_id`),
  KEY `ix_links_target_attachment` (`resolved_attachment_id`),
  KEY `ix_links_status` (`vault_id`,`status`),
  CONSTRAINT `fk_links_note` FOREIGN KEY (`from_note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_links`
--

LOCK TABLES `note_links` WRITE;
/*!40000 ALTER TABLE `note_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_projections`
--

DROP TABLE IF EXISTS `note_projections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_projections` (
  `note_id` binary(16) NOT NULL,
  `revision` bigint unsigned NOT NULL,
  `markdown` mediumtext NOT NULL,
  `content_hash` binary(32) NOT NULL,
  `heading_title` varchar(255) DEFAULT NULL,
  `frontmatter_raw` text,
  `frontmatter` json DEFAULT NULL,
  `frontmatter_error` varchar(500) DEFAULT NULL,
  `fm_tags` json DEFAULT NULL,
  `fm_aliases` json DEFAULT NULL,
  `headings` json DEFAULT NULL,
  `tasks` json DEFAULT NULL,
  `code_langs` json DEFAULT NULL,
  `obsidian_findings` json DEFAULT NULL,
  `word_count` int unsigned DEFAULT NULL,
  `line_count` int unsigned DEFAULT NULL,
  `status` enum('ok','pending','too_large','too_complex','timeout','error','invalid_content') NOT NULL,
  `pipeline_version` smallint unsigned NOT NULL,
  `projected_at` datetime(6) NOT NULL,
  PRIMARY KEY (`note_id`),
  KEY `ix_proj_pipeline` (`pipeline_version`),
  KEY `ix_proj_fm_tags` ((cast(`fm_tags` as char(64) array))),
  KEY `ix_proj_fm_aliases` ((cast(`fm_aliases` as char(255) array))),
  CONSTRAINT `fk_proj_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_projections`
--

LOCK TABLES `note_projections` WRITE;
/*!40000 ALTER TABLE `note_projections` DISABLE KEYS */;
INSERT INTO `note_projections` VALUES (0x01A0B93912FE74A5A0829D7AB7881277,1,'⟦IMPORT-MARK⟧ kernel note\n',0xE2E20748D12A460DD24A3772DE532B67556FC3096F8343ED08E01149CF4310DD,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ok',1,'2026-09-19 10:32:00.513000');
/*!40000 ALTER TABLE `note_projections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_revisions`
--

DROP TABLE IF EXISTS `note_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_revisions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `note_id` binary(16) NOT NULL,
  `seq` bigint unsigned NOT NULL,
  `kind` enum('create','import','checkpoint','unload','named','pre_restore','restore','trash') NOT NULL,
  `label` varchar(200) DEFAULT NULL,
  `markdown` mediumtext NOT NULL,
  `content_hash` binary(32) NOT NULL,
  `size_chars` int unsigned NOT NULL,
  `snapshot` longblob,
  `snapshot_format` tinyint unsigned DEFAULT NULL,
  `yjs_major` tinyint unsigned DEFAULT NULL,
  `snapshot_sv` varbinary(4096) DEFAULT NULL,
  `actor_type` enum('user','token','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `restored_from_revision_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_revisions_note_seq_kind` (`note_id`,`seq`,`kind`),
  KEY `ix_revisions_note_created` (`note_id`,`created_at`),
  CONSTRAINT `fk_revisions_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_revisions`
--

LOCK TABLES `note_revisions` WRITE;
/*!40000 ALTER TABLE `note_revisions` DISABLE KEYS */;
INSERT INTO `note_revisions` VALUES (1,0x01A0B93912FE74A5A0829D7AB7881277,1,'create',NULL,'⟦IMPORT-MARK⟧ kernel note\n',0xE2E20748D12A460DD24A3772DE532B67556FC3096F8343ED08E01149CF4310DD,26,0x00000583A5C6AE13000001042825636F6E74656E74E29FA6494D504F52542D4D41524BE29FA7206B65726E656C206E6F74650A071A0101000001010000,2,13,0x01C392A3D7091A,'user',0x01A0B939122973D0A4903107FB7D87B5,NULL,'2026-09-19 10:32:00.513000');
/*!40000 ALTER TABLE `note_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_search`
--

DROP TABLE IF EXISTS `note_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_search` (
  `note_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body_text` mediumtext NOT NULL,
  `revision` bigint unsigned NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`note_id`),
  KEY `ix_search_vault` (`vault_id`),
  FULLTEXT KEY `ft_note_search` (`title`,`body_text`),
  CONSTRAINT `fk_search_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_search`
--

LOCK TABLES `note_search` WRITE;
/*!40000 ALTER TABLE `note_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_updates`
--

DROP TABLE IF EXISTS `note_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_updates` (
  `note_id` binary(16) NOT NULL,
  `seq` bigint unsigned NOT NULL,
  `update_v1` mediumblob NOT NULL,
  `yjs_major` tinyint unsigned NOT NULL DEFAULT '13',
  `sv_after` varbinary(4096) NOT NULL,
  `actor_type` enum('user','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `session_id` binary(16) DEFAULT NULL,
  `origin` enum('connection','create','import','restore','repair') NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`note_id`,`seq`),
  KEY `ix_updates_created` (`created_at`),
  CONSTRAINT `fk_updates_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_updates`
--

LOCK TABLES `note_updates` WRITE;
/*!40000 ALTER TABLE `note_updates` DISABLE KEYS */;
INSERT INTO `note_updates` VALUES (0x01A0B93912FE74A5A0829D7AB7881277,1,0x0101C392A3D70900040107636F6E74656E741EE29FA6494D504F52542D4D41524BE29FA7206B65726E656C206E6F74650A00,13,0x01C392A3D7091A,'user',0x01A0B939122973D0A4903107FB7D87B5,0x01A0B9391275789A9991C73F6156CCC7,'create','2026-09-19 10:32:00.513000');
/*!40000 ALTER TABLE `note_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `node_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `initialized_at` datetime(6) DEFAULT NULL,
  `original_eol` enum('lf','crlf','cr','mixed') NOT NULL DEFAULT 'lf',
  `had_bom` tinyint(1) NOT NULL DEFAULT '0',
  `size_chars` int unsigned NOT NULL DEFAULT '0',
  `oversize` tinyint(1) NOT NULL DEFAULT '0',
  `content_invalid` tinyint(1) NOT NULL DEFAULT '0',
  `last_edited_by` binary(16) DEFAULT NULL,
  `last_edited_at` datetime(6) DEFAULT NULL,
  `last_checkpoint_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`node_id`),
  KEY `ix_notes_vault` (`vault_id`),
  CONSTRAINT `fk_notes_node` FOREIGN KEY (`node_id`) REFERENCES `nodes` (`id`),
  CONSTRAINT `fk_notes_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES (0x01A0B93912FE74A5A0829D7AB7881277,0x01A0B93912CA7336A5CCC1ECB6631F4F,'2026-09-19 10:32:00.513000','lf',0,26,0,0,0x01A0B939122973D0A4903107FB7D87B5,'2026-09-19 10:32:00.513000',NULL,'2026-09-19 10:32:00.513000','2026-09-19 10:32:00.513000');
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_authorization_codes`
--

DROP TABLE IF EXISTS `oauth_authorization_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_authorization_codes` (
  `id` binary(16) NOT NULL,
  `code_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `client_id` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `consent_id` binary(16) NOT NULL,
  `session_id` binary(16) NOT NULL,
  `redirect_uri` varchar(512) NOT NULL,
  `code_challenge` char(43) NOT NULL,
  `code_challenge_method` enum('S256') NOT NULL,
  `resource` varchar(255) NOT NULL,
  `scopes` json NOT NULL,
  `issued_at` datetime(6) NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  `consumed_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_oauth_codes_code_id` (`code_id`),
  KEY `ix_oauth_codes_expires` (`expires_at`),
  KEY `fk_oauth_codes_client` (`client_id`),
  KEY `fk_oauth_codes_user` (`user_id`),
  KEY `fk_oauth_codes_consent` (`consent_id`),
  CONSTRAINT `fk_oauth_codes_client` FOREIGN KEY (`client_id`) REFERENCES `oauth_clients` (`id`),
  CONSTRAINT `fk_oauth_codes_consent` FOREIGN KEY (`consent_id`) REFERENCES `oauth_consents` (`id`),
  CONSTRAINT `fk_oauth_codes_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_authorization_codes`
--

LOCK TABLES `oauth_authorization_codes` WRITE;
/*!40000 ALTER TABLE `oauth_authorization_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_authorization_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_clients` (
  `id` binary(16) NOT NULL,
  `client_id` varchar(512) NOT NULL,
  `registration_kind` enum('cimd','dynamic','manual') NOT NULL,
  `client_name` varchar(120) NOT NULL,
  `client_uri` varchar(512) DEFAULT NULL,
  `logo_uri` varchar(512) DEFAULT NULL,
  `application_type` enum('native','web') NOT NULL,
  `token_endpoint_auth_method` enum('none','client_secret_basic') NOT NULL DEFAULT 'none',
  `client_secret_hash` binary(32) DEFAULT NULL,
  `client_secret_prefix` char(26) DEFAULT NULL,
  `redirect_uris` json NOT NULL,
  `grant_types` json NOT NULL,
  `scopes` json DEFAULT NULL,
  `cimd_document` json DEFAULT NULL,
  `cimd_fetched_at` datetime(6) DEFAULT NULL,
  `cimd_etag` varchar(120) DEFAULT NULL,
  `status` enum('active','disabled') NOT NULL DEFAULT 'active',
  `created_at` datetime(6) NOT NULL,
  `created_by_user_id` binary(16) DEFAULT NULL,
  `last_authorized_at` datetime(6) DEFAULT NULL,
  `disabled_at` datetime(6) DEFAULT NULL,
  `disabled_by` binary(16) DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_oauth_clients_client_id` (`client_id`(191)),
  KEY `ix_oauth_clients_status` (`status`,`created_at`),
  KEY `ix_oauth_clients_unused` (`last_authorized_at`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_consent_vaults`
--

DROP TABLE IF EXISTS `oauth_consent_vaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_consent_vaults` (
  `consent_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  PRIMARY KEY (`consent_id`,`vault_id`),
  KEY `ix_ocv_vault` (`vault_id`),
  CONSTRAINT `fk_ocv_consent` FOREIGN KEY (`consent_id`) REFERENCES `oauth_consents` (`id`),
  CONSTRAINT `fk_ocv_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_consent_vaults`
--

LOCK TABLES `oauth_consent_vaults` WRITE;
/*!40000 ALTER TABLE `oauth_consent_vaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_consent_vaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_consents`
--

DROP TABLE IF EXISTS `oauth_consents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_consents` (
  `id` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `client_id` binary(16) NOT NULL,
  `scopes` json NOT NULL,
  `all_vaults` tinyint(1) NOT NULL DEFAULT '0',
  `admin_owned` tinyint(1) NOT NULL DEFAULT '0',
  `granted_at` datetime(6) NOT NULL,
  `granted_session_id` binary(16) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `last_authorized_at` datetime(6) DEFAULT NULL,
  `revoked_at` datetime(6) DEFAULT NULL,
  `revoked_by` binary(16) DEFAULT NULL,
  `revoke_reason` varchar(120) DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `live_consent_key` varbinary(32) GENERATED ALWAYS AS (if((`revoked_at` is null),concat(`user_id`,`client_id`),NULL)) VIRTUAL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_oauth_consents_live` (`live_consent_key`),
  KEY `ix_oauth_consents_user` (`user_id`,`revoked_at`),
  KEY `ix_oauth_consents_client` (`client_id`,`revoked_at`),
  CONSTRAINT `fk_oauth_consents_client` FOREIGN KEY (`client_id`) REFERENCES `oauth_clients` (`id`),
  CONSTRAINT `fk_oauth_consents_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_consents`
--

LOCK TABLES `oauth_consents` WRITE;
/*!40000 ALTER TABLE `oauth_consents` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_consents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` binary(16) NOT NULL,
  `token_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `family_id` binary(16) NOT NULL,
  `rotated_from_id` binary(16) DEFAULT NULL,
  `client_id` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `consent_id` binary(16) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `scopes` json NOT NULL,
  `issued_at` datetime(6) NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  `absolute_expires_at` datetime(6) NOT NULL,
  `last_used_at` datetime(6) DEFAULT NULL,
  `rotated_at` datetime(6) DEFAULT NULL,
  `revoked_at` datetime(6) DEFAULT NULL,
  `revoke_reason` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_oauth_refresh_token_id` (`token_id`),
  KEY `ix_oauth_refresh_family` (`family_id`,`revoked_at`),
  KEY `ix_oauth_refresh_consent` (`consent_id`,`revoked_at`),
  KEY `ix_oauth_refresh_expires` (`absolute_expires_at`),
  KEY `fk_oauth_refresh_client` (`client_id`),
  KEY `fk_oauth_refresh_user` (`user_id`),
  CONSTRAINT `fk_oauth_refresh_client` FOREIGN KEY (`client_id`) REFERENCES `oauth_clients` (`id`),
  CONSTRAINT `fk_oauth_refresh_consent` FOREIGN KEY (`consent_id`) REFERENCES `oauth_consents` (`id`),
  CONSTRAINT `fk_oauth_refresh_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_setup_tokens`
--

DROP TABLE IF EXISTS `password_setup_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_setup_tokens` (
  `id` binary(16) NOT NULL,
  `token_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `purpose` enum('initial','reset') NOT NULL,
  `issued_by` binary(16) NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  `consumed_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_spl_token_id` (`token_id`),
  KEY `ix_spl_user` (`user_id`,`consumed_at`),
  CONSTRAINT `fk_spl_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_setup_tokens`
--

LOCK TABLES `password_setup_tokens` WRITE;
/*!40000 ALTER TABLE `password_setup_tokens` DISABLE KEYS */;
INSERT INTO `password_setup_tokens` VALUES (0x01A0B939122E7434A192F0E787B5EAB9,'gh6QgnjHYtaDwCzb',0xCF170A53264A1902C336724BCCCA7D2B8001D965548FE6561F4C6983E15059AD,0x01A0B939122973D0A4903107FB7D87B5,'initial',0x01A0B939122973D0A4903107FB7D87B5,'2026-09-20 10:32:00.301000','2026-09-19 10:32:00.349000','2026-09-19 10:32:00.301000'),(0x01A0B939129A7AF8ADF116970842F35D,'aX4eiVTUbhDMzeue',0xE1588F630E44042C413C90D08FA8093606B3719D78DF50173D2B350320D24164,0x01A0B93912947BD1B6B5232888D9BD1D,'initial',0x01A0B939122973D0A4903107FB7D87B5,'2026-09-20 10:32:00.410000','2026-09-19 10:32:00.425000','2026-09-19 10:32:00.410000'),(0x01A0B93912A07FF7BA567B74EBFA0369,'pU2JUhQnoSjnq3Jj',0xA25A41C0457888DA117A5EB6FF8DFA68DCF7F3AF3E3FB51B4BD8DD03730F7AA4,0x01A0B93912947BD29D4BA56C33A58B9D,'initial',0x01A0B939122973D0A4903107FB7D87B5,'2026-09-20 10:32:00.416000','2026-09-19 10:32:00.427000','2026-09-19 10:32:00.416000'),(0x01A0B93912A77D2E8E36816F85141E90,'99ZdDs1Gfy0VekUl',0xE959804BDDD940422ADE8758AEAE946874917D642F0A2A7BC4D35C063839B3B4,0x01A0B93912987880ACFD8BF2B9513BC7,'initial',0x01A0B939122973D0A4903107FB7D87B5,'2026-09-20 10:32:00.422000','2026-09-19 10:32:00.435000','2026-09-19 10:32:00.422000'),(0x01A0B93912AD702E8A84760DD1AF1B33,'ViyrTjp3Xe8MyuuU',0x2194E685CDEDE7E787291E29D8CA8E1A3EBBB9B435FD8E462721F1DE806E13A5,0x01A0B93912987881A432F1816775E7D1,'initial',0x01A0B939122973D0A4903107FB7D87B5,'2026-09-20 10:32:00.428000','2026-09-19 10:32:00.442000','2026-09-19 10:32:00.428000'),(0x01A0B93912B572389FFBCF0AE5EFF753,'kTYYIXIpZk59bTr0',0x711B62DEFCA8FDCF314243062B669B37C3D5659675DE0528AEA7303F02D341A3,0x01A0B93912987882947FE533AEB9000F,'initial',0x01A0B939122973D0A4903107FB7D87B5,'2026-09-20 10:32:00.435000','2026-09-19 10:32:00.448000','2026-09-19 10:32:00.435000');
/*!40000 ALTER TABLE `password_setup_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_meta`
--

DROP TABLE IF EXISTS `schema_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_meta` (
  `key` varchar(32) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_meta`
--

LOCK TABLES `schema_meta` WRITE;
/*!40000 ALTER TABLE `schema_meta` DISABLE KEYS */;
INSERT INTO `schema_meta` VALUES ('acl.access_log','{\"applied\":true,\"fingerprint\":\"3cb05ad81cb510aa65bc7dbff4b59ac9b8ccf070be4480dae6a2e5595271c8f6\"}'),('acl.access_token_vaults','{\"applied\":true,\"fingerprint\":\"68b911e5b92bb9d90846c791c74c40047a7f2da0022ae0da84d51479e9bcb7ca\"}'),('acl.access_tokens','{\"applied\":true,\"fingerprint\":\"bdfbd1c8e849e12264649353fe1032b9ca270a9e2af5ee45657e9031900c1650\"}'),('acl.attachments','{\"applied\":true,\"fingerprint\":\"723b9d57613881d040162ab632e6bcc834243e2f1e2979b1906e61411a230615\"}'),('acl.audit_chain_heads','{\"applied\":true,\"fingerprint\":\"09bbf8d7503aa4e44b7635070bb4954504e8458b2f780659cfdd306c8c035b93\"}'),('acl.audit_events','{\"applied\":true,\"fingerprint\":\"0d021f69a450993d66c44fac10e927a4d92ef76e0e136057361b526fd26eca47\"}'),('acl.audit_events_archive','{\"applied\":true,\"fingerprint\":\"9245bc26a1a2ec7a41c9151dac9b7da67463e5bb0b83f464251e06e58871daa0\"}'),('acl.collab_owner_fence','{\"applied\":true,\"fingerprint\":\"60ca2453617aefa174bbde43d3da8ba7a38f1a42c65e0c271708aa7c129dad22\"}'),('acl.desktop_releases','{\"applied\":true,\"fingerprint\":\"cbe40c21e12c5efc3c74858dfbff81d4f0f7ca072934459d3a630b090054c178\"}'),('acl.export_jobs','{\"applied\":true,\"fingerprint\":\"54166a5f90330c33611fcae2aa1d34ebb8af0e1d597f53c9d6347055c7dc9e32\"}'),('acl.import_jobs','{\"applied\":true,\"fingerprint\":\"8421e3bcf12234ffbb3368c03eead01fb4187039904df4cd17ea9d939e4bef0d\"}'),('acl.jobs','{\"applied\":true,\"fingerprint\":\"aafb728ee85aa56cb620f691a28ed571a95005ebd55b22b441c54ccb4fa20ab6\"}'),('acl.kysely_migration','{\"applied\":true,\"fingerprint\":\"b364934c8871a0572104874fc864b5b764879ddd870006f197615931e34c1c13\"}'),('acl.kysely_migration_lock','{\"applied\":true,\"fingerprint\":\"51021f74746159bf4f61ad5d713f8cb7ea8bdfdc65ec5dafeacc8f7f475000ed\"}'),('acl.login_throttle','{\"applied\":true,\"fingerprint\":\"2e0520a72039d214fe19cd34c5d11e0dbce39b5fa8eaed6217ac654cc1d53ac7\"}'),('acl.nodes','{\"applied\":true,\"fingerprint\":\"7faa7ee251146e70f596a81bfb009b162bcb6a2f33cfbd175c061106cbdf7e2a\"}'),('acl.note_docs','{\"applied\":true,\"fingerprint\":\"9be49954ad662abfe9dfc8eabbbdbd3b297d586171989e37d17f90505b4c8785\"}'),('acl.note_links','{\"applied\":true,\"fingerprint\":\"795c9fdeeafc80d5453f1df962de09d0f04ff3179eff1adb01ff9359ab67b541\"}'),('acl.note_projections','{\"applied\":true,\"fingerprint\":\"186c0c4cd81ee039b9e37b968dbd6961ec67553b898156104aa4382ca5dac89d\"}'),('acl.note_revisions','{\"applied\":true,\"fingerprint\":\"bdc901cf8bae963ea7af081ee1d534f326dc8284153f13fdc6c06233fe4739c9\"}'),('acl.note_search','{\"applied\":true,\"fingerprint\":\"2a051511f38517eadd587824a069abad3ba927b579d251ba184bed5fda603097\"}'),('acl.note_updates','{\"applied\":true,\"fingerprint\":\"071dc16dfecb9daf0acc7016c61e7f991e1da36441aaeb3877cd23fe256aa5d6\"}'),('acl.notes','{\"applied\":true,\"fingerprint\":\"d771b524137a6d8a634d3bf770b3c76c3d7ff7319ee57f4ca910a8aa2147b08b\"}'),('acl.oauth_authorization_codes','{\"applied\":true,\"fingerprint\":\"977d39eee4d1ac6af76a1a92430c602c949684ce05955506006c990741f003b1\"}'),('acl.oauth_clients','{\"applied\":true,\"fingerprint\":\"24b77335f71aeb6a23bf71d70cff6f4829329fe1147a2897d8dc0d618a1bb7f4\"}'),('acl.oauth_consent_vaults','{\"applied\":true,\"fingerprint\":\"caed8e3500fefa0e34df565008eb71ce930b2916acb44e62883a59a2f9c7a247\"}'),('acl.oauth_consents','{\"applied\":true,\"fingerprint\":\"0e644943db192f7ea9a12a09071c93e567fb1913a46cc11eb10eb2f3ab510d7d\"}'),('acl.oauth_refresh_tokens','{\"applied\":true,\"fingerprint\":\"58e7d98d6b9e595a600b6f0b59e37d31bec0ab3b422bedbb1048e70d137e9601\"}'),('acl.password_setup_tokens','{\"applied\":true,\"fingerprint\":\"338280c5b6e7046d97b1b3c8589c607af96c616c9752ee5be8013b979b85b30c\"}'),('acl.schema_meta','{\"applied\":true,\"fingerprint\":\"cb7265c4a3f24d38872b9828716c27551bbc2d0b52211d0e8761e21f4e72b444\"}'),('acl.server_settings','{\"applied\":true,\"fingerprint\":\"eb4ea243f596142a9657008af4eca3f17ea41288b4c5ccf0f1387ea847ae768c\"}'),('acl.session_revocation_commands','{\"applied\":true,\"fingerprint\":\"04105afeb1b1103d05ee6888550001576396cd8c51186fb443ba1463a5780553\"}'),('acl.sessions','{\"applied\":true,\"fingerprint\":\"4f8066e4177db802da539b9bfc1de4a4c62f5008d9fc9cf3ed33d85c5eb268bf\"}'),('acl.trash_entries','{\"applied\":true,\"fingerprint\":\"4e72de20258f7e35a7420323888ca6bbd7b9e1af1ed2d51fc9adf75e7df09f3b\"}'),('acl.user_credentials','{\"applied\":true,\"fingerprint\":\"d31f8e8409ed598603f5811ac676fb89c3cad26d913de7ce31989b9272338d67\"}'),('acl.users','{\"applied\":true,\"fingerprint\":\"a2927f57314bc380d4a91c1b106ccc1b94fadfbb27f320ac08e04020245cdb48\"}'),('acl.vault_members','{\"applied\":true,\"fingerprint\":\"def08bb5a1358fdf86c7057558280e72987b5503eed056d5ef3f6d0eae7e5f35\"}'),('acl.vaults','{\"applied\":true,\"fingerprint\":\"1af3101abc5ec86fbf8d7bdf5acb316c454d5a2a0892713d256b7e80e05637f8\"}'),('admin_users_lock','1'),('api_version','1'),('attachment_key_version','1'),('audit_key_version','1'),('cursor_key_version','1'),('iridium_version','0.0.0'),('min_client_version','0.0.0'),('pepper_version','1'),('pipeline_version','1');
/*!40000 ALTER TABLE `schema_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server_settings`
--

DROP TABLE IF EXISTS `server_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `server_settings` (
  `key` varchar(64) NOT NULL,
  `value` json NOT NULL,
  `updated_by` binary(16) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server_settings`
--

LOCK TABLES `server_settings` WRITE;
/*!40000 ALTER TABLE `server_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `server_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_revocation_commands`
--

DROP TABLE IF EXISTS `session_revocation_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session_revocation_commands` (
  `id` binary(16) NOT NULL,
  `user_id` binary(16) DEFAULT NULL,
  `actor_type` enum('user','token','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `actor_display` varchar(120) DEFAULT NULL,
  `context` json NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `result` json DEFAULT NULL,
  `delivered_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_session_commands_pending` (`delivered_at`,`created_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_revocation_commands`
--

LOCK TABLES `session_revocation_commands` WRITE;
/*!40000 ALTER TABLE `session_revocation_commands` DISABLE KEYS */;
/*!40000 ALTER TABLE `session_revocation_commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` binary(16) NOT NULL,
  `token_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `kind` enum('web','desktop') NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `last_seen_at` datetime(6) NOT NULL,
  `idle_expires_at` datetime(6) NOT NULL,
  `absolute_expires_at` datetime(6) NOT NULL,
  `last_authenticated_at` datetime(6) NOT NULL,
  `mfa_verified_at` datetime(6) DEFAULT NULL,
  `ip` varbinary(16) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `client_name` varchar(64) DEFAULT NULL,
  `device_name` varchar(120) DEFAULT NULL,
  `client_version` varchar(32) DEFAULT NULL,
  `revoked_at` datetime(6) DEFAULT NULL,
  `revoked_reason` enum('logout','admin','password_change','user_disabled','expired','replaced') DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sessions_token_id` (`token_id`),
  KEY `ix_sessions_user` (`user_id`,`revoked_at`),
  KEY `ix_sessions_absolute` (`absolute_expires_at`),
  CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (0x01A0B9391275789A9991C73F6156CCC7,'xrgk5fu8nZN23ONG',0x2820A7A64E92AE3EBAC457BE9EE36564DA9E32AB0B0B0526BBD5483325314263,0x01A0B939122973D0A4903107FB7D87B5,'web','2026-09-19 10:32:00.371000','2026-09-19 10:32:00.371000','2026-09-20 10:32:00.371000','2026-10-03 10:32:00.371000','2026-09-19 10:32:00.390000',NULL,0x7F000001,'node','web',NULL,'0.0.0',NULL,NULL);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trash_entries`
--

DROP TABLE IF EXISTS `trash_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trash_entries` (
  `node_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `cascade_root_id` binary(16) NOT NULL,
  `deleted_by` binary(16) NOT NULL,
  `deleted_at` datetime(6) NOT NULL,
  `original_parent_id` binary(16) NOT NULL,
  `original_path` text NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  PRIMARY KEY (`node_id`),
  KEY `ix_trash_vault_expires` (`vault_id`,`expires_at`),
  KEY `ix_trash_vault_root` (`vault_id`,`cascade_root_id`),
  CONSTRAINT `fk_trash_node` FOREIGN KEY (`node_id`) REFERENCES `nodes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trash_entries`
--

LOCK TABLES `trash_entries` WRITE;
/*!40000 ALTER TABLE `trash_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `trash_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_credentials`
--

DROP TABLE IF EXISTS `user_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_credentials` (
  `user_id` binary(16) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `pepper_version` tinyint unsigned NOT NULL,
  `password_changed_at` datetime(6) NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_cred_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_credentials`
--

LOCK TABLES `user_credentials` WRITE;
/*!40000 ALTER TABLE `user_credentials` DISABLE KEYS */;
INSERT INTO `user_credentials` VALUES (0x01A0B939122973D0A4903107FB7D87B5,'$argon2id$v=19$m=8192,t=1,p=1$HY9MyO6VY2E1Extv2h8HuQ$vPvebu6jXEhpXrZ/+porNiLfQl2WzFfzlPZufoFDATw',1,'2026-09-19 10:32:00.349000'),(0x01A0B93912947BD1B6B5232888D9BD1D,'$argon2id$v=19$m=8192,t=1,p=1$6bLqMadNPc666FDHf838JA$h/Y0V7CK65sc/kFIoTYx7xmnGH6U10lRY6m17x8QRsI',1,'2026-09-19 10:32:00.425000'),(0x01A0B93912947BD29D4BA56C33A58B9D,'$argon2id$v=19$m=8192,t=1,p=1$2BFO0oPphPETI1HJDSAmfQ$EeT8pyzrhRpGmPI11LG1DPvg+OmZPCQUe08z/e80WQQ',1,'2026-09-19 10:32:00.427000'),(0x01A0B93912987880ACFD8BF2B9513BC7,'$argon2id$v=19$m=8192,t=1,p=1$yPeVc9AWtsGl9L7OFwoZwg$7622VcHsBGUqbOmmfwF2HvcGfEt9KNP8PgZl3VnKBuQ',1,'2026-09-19 10:32:00.435000'),(0x01A0B93912987881A432F1816775E7D1,'$argon2id$v=19$m=8192,t=1,p=1$ZqQbYycpRVQK0hnC6ZUhVw$QrC3dV5svpi+IoWWqpVhgH35QgDAFGcDEub0T99g8TE',1,'2026-09-19 10:32:00.442000'),(0x01A0B93912987882947FE533AEB9000F,'$argon2id$v=19$m=8192,t=1,p=1$pOsSNsZdtWHbQgPXN1MOCA$L9i5UEQAnazhPOPST4QNwn/cPaa0W0rJzZoOo1QPdSw',1,'2026-09-19 10:32:00.448000');
/*!40000 ALTER TABLE `user_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` binary(16) NOT NULL,
  `email` varchar(320) NOT NULL,
  `email_key` varchar(320) GENERATED ALWAYS AS (lower(`email`)) STORED,
  `display_name` varchar(120) NOT NULL,
  `is_server_admin` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('active','disabled','deleted') NOT NULL DEFAULT 'active',
  `color_hue` smallint unsigned NOT NULL,
  `authz_version` int unsigned NOT NULL DEFAULT '1',
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `last_login_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email_key` (`email_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `email`, `display_name`, `is_server_admin`, `status`, `color_hue`, `authz_version`, `version`, `created_at`, `updated_at`, `last_login_at`) VALUES (0x01A0B939122973D0A4903107FB7D87B5,'admin@iridium.test','Kernel Admin',1,'active',0,2,1,'2026-09-19 10:32:00.297000','2026-09-19 10:32:00.349000','2026-09-19 10:32:00.371000'),(0x01A0B93912947BD1B6B5232888D9BD1D,'editorA@iridium.test','editorA',0,'active',138,3,1,'2026-09-19 10:32:00.404000','2026-09-19 10:32:00.471000',NULL),(0x01A0B93912947BD29D4BA56C33A58B9D,'editorB@iridium.test','editorB',0,'active',275,3,1,'2026-09-19 10:32:00.404000','2026-09-19 10:32:00.482000',NULL),(0x01A0B93912987880ACFD8BF2B9513BC7,'editorC@iridium.test','editorC',0,'active',53,3,1,'2026-09-19 10:32:00.408000','2026-09-19 10:32:00.491000',NULL),(0x01A0B93912987881A432F1816775E7D1,'viewer@iridium.test','viewer',0,'active',190,3,1,'2026-09-19 10:32:00.408000','2026-09-19 10:32:00.500000',NULL),(0x01A0B93912987882947FE533AEB9000F,'outsider@iridium.test','outsider',0,'active',328,2,1,'2026-09-19 10:32:00.408000','2026-09-19 10:32:00.448000',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vault_members`
--

DROP TABLE IF EXISTS `vault_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vault_members` (
  `vault_id` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `role` enum('viewer','editor','manager') NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `granted_by` binary(16) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`vault_id`,`user_id`),
  KEY `ix_members_user` (`user_id`),
  CONSTRAINT `fk_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_members_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vault_members`
--

LOCK TABLES `vault_members` WRITE;
/*!40000 ALTER TABLE `vault_members` DISABLE KEYS */;
INSERT INTO `vault_members` VALUES (0x01A0B93912CA7336A5CCC1ECB6631F4F,0x01A0B93912947BD1B6B5232888D9BD1D,'editor',1,0x01A0B939122973D0A4903107FB7D87B5,'2026-09-19 10:32:00.471000','2026-09-19 10:32:00.471000'),(0x01A0B93912CA7336A5CCC1ECB6631F4F,0x01A0B93912947BD29D4BA56C33A58B9D,'editor',1,0x01A0B939122973D0A4903107FB7D87B5,'2026-09-19 10:32:00.482000','2026-09-19 10:32:00.482000'),(0x01A0B93912CA7336A5CCC1ECB6631F4F,0x01A0B93912987880ACFD8BF2B9513BC7,'editor',1,0x01A0B939122973D0A4903107FB7D87B5,'2026-09-19 10:32:00.491000','2026-09-19 10:32:00.491000'),(0x01A0B93912CA7336A5CCC1ECB6631F4F,0x01A0B93912987881A432F1816775E7D1,'viewer',1,0x01A0B939122973D0A4903107FB7D87B5,'2026-09-19 10:32:00.500000','2026-09-19 10:32:00.500000');
/*!40000 ALTER TABLE `vault_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vaults`
--

DROP TABLE IF EXISTS `vaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vaults` (
  `id` binary(16) NOT NULL,
  `name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `slug` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `root_node_id` binary(16) DEFAULT NULL,
  `status` enum('importing','active','archived','deleting') NOT NULL DEFAULT 'active',
  `archived_at` datetime(6) DEFAULT NULL,
  `markdown_flavor` enum('gfm','obsidian-compat') NOT NULL DEFAULT 'gfm',
  `soft_breaks` tinyint(1) NOT NULL DEFAULT '0',
  `attachment_folder` varchar(255) NOT NULL DEFAULT 'attachments',
  `load_external_images` enum('never','click','always') NOT NULL DEFAULT 'click',
  `mcp_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `ai_guidance` text,
  `trash_retention_days` smallint unsigned NOT NULL DEFAULT '30',
  `auto_checkpoint_interval_min` smallint unsigned NOT NULL DEFAULT '10',
  `tree_version` bigint unsigned NOT NULL DEFAULT '0',
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_by` binary(16) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vaults_name` (`name`),
  UNIQUE KEY `uq_vaults_slug` (`slug`),
  KEY `ix_vaults_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vaults`
--

LOCK TABLES `vaults` WRITE;
/*!40000 ALTER TABLE `vaults` DISABLE KEYS */;
INSERT INTO `vaults` VALUES (0x01A0B93912CA7336A5CCC1ECB6631F4F,'Kernel','kernel',NULL,0x01A0B93912CA733781E2E5ACF72411F0,'active',NULL,'gfm',0,'attachments','click',1,NULL,30,10,1,1,0x01A0B939122973D0A4903107FB7D87B5,'2026-09-19 10:32:00.458000','2026-09-19 10:32:00.522000');
/*!40000 ALTER TABLE `vaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'iridium'
--

--
-- Dumping routines for database 'iridium'
--
--
-- WARNING: can't read the INFORMATION_SCHEMA.libraries table. It's most probably an old server 8.4.11.
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-19 10:32:02
