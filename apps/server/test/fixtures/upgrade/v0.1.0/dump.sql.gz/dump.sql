-- MySQL dump 10.13  Distrib 9.7.2, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: iridium
-- ------------------------------------------------------
-- Server version	8.4.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE REPLICATION SOURCE TO SOURCE_LOG_FILE='binlog.000003', SOURCE_LOG_POS=168451;

--
-- Current Database: `iridium`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `iridium` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `iridium`;

--
-- Table structure for table `access_log`
--

DROP TABLE IF EXISTS `access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime(6) NOT NULL,
  `token_id` binary(16) DEFAULT NULL,
  `user_id` binary(16) NOT NULL,
  `surface` enum('mcp','rest','export','oauth') NOT NULL,
  `action` varchar(64) NOT NULL,
  `vault_id` binary(16) DEFAULT NULL,
  `note_ids` json DEFAULT NULL,
  `note_ids_truncated` tinyint(1) NOT NULL DEFAULT '0',
  `revision` bigint unsigned DEFAULT NULL,
  `status` enum('ok','denied','not_found','error','rate_limited') NOT NULL,
  `latency_ms` int unsigned NOT NULL,
  `bytes_out` int unsigned DEFAULT NULL,
  `client_name` varchar(64) DEFAULT NULL,
  `client_version` varchar(32) DEFAULT NULL,
  `ip` varbinary(16) DEFAULT NULL,
  `request_id` binary(16) DEFAULT NULL,
  `oauth_client_id` binary(16) DEFAULT NULL,
  PRIMARY KEY (`id`,`occurred_at`),
  KEY `ix_access_token_time` (`token_id`,`occurred_at`),
  KEY `ix_access_vault_time` (`vault_id`,`occurred_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
/*!50500 PARTITION BY RANGE  COLUMNS(occurred_at)
(PARTITION p2026_09 VALUES LESS THAN ('2026-10-01 00:00:00.000000') ENGINE = InnoDB,
 PARTITION p2026_10 VALUES LESS THAN ('2026-11-01 00:00:00.000000') ENGINE = InnoDB,
 PARTITION p_overflow VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_log`
--

LOCK TABLES `access_log` WRITE;
/*!40000 ALTER TABLE `access_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `access_token_vaults`
--

DROP TABLE IF EXISTS `access_token_vaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_token_vaults` (
  `token_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  PRIMARY KEY (`token_id`,`vault_id`),
  KEY `ix_atv_vault` (`vault_id`),
  CONSTRAINT `fk_atv_token` FOREIGN KEY (`token_id`) REFERENCES `access_tokens` (`id`),
  CONSTRAINT `fk_atv_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_token_vaults`
--

LOCK TABLES `access_token_vaults` WRITE;
/*!40000 ALTER TABLE `access_token_vaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_token_vaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `access_tokens`
--

DROP TABLE IF EXISTS `access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_tokens` (
  `id` binary(16) NOT NULL,
  `token_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `kind` enum('pat','oauth','scim') NOT NULL DEFAULT 'pat',
  `name` varchar(120) NOT NULL,
  `display_prefix` char(26) NOT NULL,
  `scopes` json NOT NULL,
  `all_vaults` tinyint(1) NOT NULL DEFAULT '0',
  `admin_owned` tinyint(1) NOT NULL DEFAULT '0',
  `expires_at` datetime(6) NOT NULL,
  `last_used_at` datetime(6) DEFAULT NULL,
  `last_used_ip` varbinary(16) DEFAULT NULL,
  `last_client` varchar(120) DEFAULT NULL,
  `rate_limit_per_hour` int unsigned DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `created_from_session_id` binary(16) DEFAULT NULL,
  `created_ip` varbinary(16) DEFAULT NULL,
  `created_user_agent` varchar(255) DEFAULT NULL,
  `rotated_from_id` binary(16) DEFAULT NULL,
  `rotation_overlap_until` datetime(6) DEFAULT NULL,
  `revoked_at` datetime(6) DEFAULT NULL,
  `revoked_by` binary(16) DEFAULT NULL,
  `revoke_reason` varchar(120) DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `client_id` binary(16) DEFAULT NULL,
  `consent_id` binary(16) DEFAULT NULL,
  `refresh_id` binary(16) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tokens_token_id` (`token_id`),
  KEY `ix_tokens_user` (`user_id`,`revoked_at`,`expires_at`),
  KEY `ix_tokens_expires` (`expires_at`),
  KEY `ix_tokens_consent` (`consent_id`,`revoked_at`),
  KEY `ix_tokens_client` (`client_id`,`revoked_at`),
  CONSTRAINT `fk_tokens_oauth_client` FOREIGN KEY (`client_id`) REFERENCES `oauth_clients` (`id`),
  CONSTRAINT `fk_tokens_oauth_consent` FOREIGN KEY (`consent_id`) REFERENCES `oauth_consents` (`id`),
  CONSTRAINT `fk_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_tokens`
--

LOCK TABLES `access_tokens` WRITE;
/*!40000 ALTER TABLE `access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachments` (
  `id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `sha256` binary(32) NOT NULL,
  `size_bytes` bigint unsigned NOT NULL,
  `mime` varchar(127) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `path_hint` varchar(760) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci DEFAULT NULL,
  `storage_key` varchar(512) NOT NULL,
  `encryption` enum('none','aes256gcm') NOT NULL DEFAULT 'none',
  `key_version` tinyint unsigned DEFAULT NULL,
  `iv` varbinary(12) DEFAULT NULL,
  `auth_tag` varbinary(16) DEFAULT NULL,
  `uploaded_by` binary(16) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `live` tinyint GENERATED ALWAYS AS (if((`deleted_at` is null),1,NULL)) VIRTUAL,
  `version` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_attachment_vault_sha` (`vault_id`,`sha256`),
  UNIQUE KEY `uq_attachment_path` (`vault_id`,`path_hint`,`live`),
  KEY `ix_attachments_vault` (`vault_id`,`deleted_at`),
  CONSTRAINT `fk_att_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_chain_heads`
--

DROP TABLE IF EXISTS `audit_chain_heads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_chain_heads` (
  `chain_id` varchar(40) NOT NULL,
  `last_id` bigint unsigned NOT NULL,
  `last_hash` binary(32) NOT NULL,
  PRIMARY KEY (`chain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_chain_heads`
--

LOCK TABLES `audit_chain_heads` WRITE;
/*!40000 ALTER TABLE `audit_chain_heads` DISABLE KEYS */;
INSERT INTO `audit_chain_heads` VALUES ('server',69,0x88D7352B12C0EDC1B5102750C09826F4FCC05003EC64D23ADA9E1F909E285BC5),('vault:01a0bd656a15754fa3f9b8c700ad0be3',75,0xD88CCE62FC4EF2C4F29042E0E3C9688178F37803319CEF8DF779CE2E3E5378BE);
/*!40000 ALTER TABLE `audit_chain_heads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_events`
--

DROP TABLE IF EXISTS `audit_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime(6) NOT NULL,
  `schema_version` smallint unsigned NOT NULL DEFAULT '1',
  `chain_id` varchar(40) NOT NULL,
  `action` varchar(64) NOT NULL,
  `actor_type` enum('user','token','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `actor_display` varchar(160) DEFAULT NULL,
  `on_behalf_of_user_id` binary(16) DEFAULT NULL,
  `credential_type` enum('session','pat','oauth','ticket','setpw','cli','system','none') NOT NULL,
  `credential_id` binary(16) DEFAULT NULL,
  `vault_id` binary(16) DEFAULT NULL,
  `target_type` varchar(32) DEFAULT NULL,
  `target_id` binary(16) DEFAULT NULL,
  `targets` json DEFAULT NULL,
  `outcome` enum('success','failure') NOT NULL,
  `reason` varchar(128) DEFAULT NULL,
  `context` json NOT NULL,
  `metadata` json DEFAULT NULL,
  `prev_hash` binary(32) NOT NULL,
  `hash` binary(32) NOT NULL,
  `key_version` tinyint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_audit_chain` (`chain_id`,`id`),
  KEY `ix_audit_vault_time` (`vault_id`,`occurred_at`),
  KEY `ix_audit_actor_time` (`actor_id`,`occurred_at`),
  KEY `ix_audit_action_time` (`action`,`occurred_at`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_events`
--

LOCK TABLES `audit_events` WRITE;
/*!40000 ALTER TABLE `audit_events` DISABLE KEYS */;
INSERT INTO `audit_events` VALUES (1,'2026-09-20 05:58:52.136000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0001_users\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x0000000000000000000000000000000000000000000000000000000000000000,0x2A06D1F41800C0A2A40D621C6E1C647CDE6B179FFBCC62D8E7761F349CD82BE8,1),(2,'2026-09-20 05:58:52.141000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0002_user_credentials\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x2A06D1F41800C0A2A40D621C6E1C647CDE6B179FFBCC62D8E7761F349CD82BE8,0x14DC8C90C53F1357D4E3C960283322A3A4196ABC0F9012A7D004B65DCDE5B8FF,1),(3,'2026-09-20 05:58:52.143000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0003_password_setup_tokens\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x14DC8C90C53F1357D4E3C960283322A3A4196ABC0F9012A7D004B65DCDE5B8FF,0x5627E0822BAE601968103868687409B07AF54B5255274B8DC9A617030BEEAC5D,1),(4,'2026-09-20 05:58:52.145000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0004_sessions\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x5627E0822BAE601968103868687409B07AF54B5255274B8DC9A617030BEEAC5D,0x62F61282C1B4AA134AC99E248BED2777774E36F67087DD4746CC8B018D5BFDBB,1),(5,'2026-09-20 05:58:52.147000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0005_login_throttle\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x62F61282C1B4AA134AC99E248BED2777774E36F67087DD4746CC8B018D5BFDBB,0xF4F997417922C4019F0A46FD427E6C1C6C12B59B579718F0BF62415F27746FFC,1),(6,'2026-09-20 05:58:52.149000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0006_vaults\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xF4F997417922C4019F0A46FD427E6C1C6C12B59B579718F0BF62415F27746FFC,0x859965D5352D3D3AC5BFA7BE0D3DA3F610EB13CB72C66DD44ADC4A5D7CB61865,1),(7,'2026-09-20 05:58:52.151000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0007_vault_members\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x859965D5352D3D3AC5BFA7BE0D3DA3F610EB13CB72C66DD44ADC4A5D7CB61865,0x2828323DA172ED618AF20F520D03641A828FB57C6F65D167478442DE48D48A04,1),(8,'2026-09-20 05:58:52.153000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0008_access_tokens\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x2828323DA172ED618AF20F520D03641A828FB57C6F65D167478442DE48D48A04,0xCE2E1D1BAB2075757169B334C003104428C77B61C2BA65952058A2CC002AF201,1),(9,'2026-09-20 05:58:52.155000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0009_access_token_vaults\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xCE2E1D1BAB2075757169B334C003104428C77B61C2BA65952058A2CC002AF201,0x02D9BB58DEE93482C20B0DEDBE1B70A24D638AA632652B40221E7D8E48C88499,1),(10,'2026-09-20 05:58:52.157000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0010_nodes\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x02D9BB58DEE93482C20B0DEDBE1B70A24D638AA632652B40221E7D8E48C88499,0x7EA38E65421D600F0348033FD53DF77A813EF30F87A14D4C084BAE506C698123,1),(11,'2026-09-20 05:58:52.159000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0011_nodes_uq_sibling\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x7EA38E65421D600F0348033FD53DF77A813EF30F87A14D4C084BAE506C698123,0xB7E6D4FDE4A3DC837B7E2CD6B7901AA60549B6976AF3DD00ECD15E60B86C8D18,1),(12,'2026-09-20 05:58:52.160000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0012_trash_entries\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xB7E6D4FDE4A3DC837B7E2CD6B7901AA60549B6976AF3DD00ECD15E60B86C8D18,0xAC76B61A87C60AB831D30644D197EB63636842251C750C2F46FF0636E9821AAD,1),(13,'2026-09-20 05:58:52.162000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0013_notes\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xAC76B61A87C60AB831D30644D197EB63636842251C750C2F46FF0636E9821AAD,0xF5DF62A3FD95B73D3B077C1231067556A54F7EA4801D0E1CE3841CFD946DCB89,1),(14,'2026-09-20 05:58:52.164000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0014_note_docs\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xF5DF62A3FD95B73D3B077C1231067556A54F7EA4801D0E1CE3841CFD946DCB89,0xBA58EAB98DCAE1EE0F5A32C60FC2BE227AAC8CA288E66D20F70ECDDAC6863B16,1),(15,'2026-09-20 05:58:52.170000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0015_note_updates\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xBA58EAB98DCAE1EE0F5A32C60FC2BE227AAC8CA288E66D20F70ECDDAC6863B16,0xE7366EE530ECBDC81570A80AD9454EE38A2BCA692C27C148CF17D5318EC15422,1),(16,'2026-09-20 05:58:52.171000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0016_note_revisions\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xE7366EE530ECBDC81570A80AD9454EE38A2BCA692C27C148CF17D5318EC15422,0x88ADF1B68E08C68DDFDB32249ADEA56A30DC56AD6DB3505E5A02981503D1BF84,1),(17,'2026-09-20 05:58:52.173000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0017_note_projections\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x88ADF1B68E08C68DDFDB32249ADEA56A30DC56AD6DB3505E5A02981503D1BF84,0x8BA23CE6B1EF0FC41DE44ABD491DEBD1718A3E02060F3FFD533D840C1A9CF84D,1),(18,'2026-09-20 05:58:52.174000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0018_note_projections_fm_indexes\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x8BA23CE6B1EF0FC41DE44ABD491DEBD1718A3E02060F3FFD533D840C1A9CF84D,0xD168F779B1A5B0AF5CD11610738F6DE7395F29B3FBF11D5709165DE97D46A4B7,1),(19,'2026-09-20 05:58:52.176000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0019_note_search\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xD168F779B1A5B0AF5CD11610738F6DE7395F29B3FBF11D5709165DE97D46A4B7,0xF696E90ABCB9DCDC96B1742D6E50D6484FB22E39AEAF3A72FF6909899C6E7721,1),(20,'2026-09-20 05:58:52.178000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0020_note_search_fulltext\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xF696E90ABCB9DCDC96B1742D6E50D6484FB22E39AEAF3A72FF6909899C6E7721,0x075622D126FF337EECFDE651C07B28BA3D57D935827BDCDEF9B4351419C2F768,1),(21,'2026-09-20 05:58:52.179000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0021_note_links\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x075622D126FF337EECFDE651C07B28BA3D57D935827BDCDEF9B4351419C2F768,0x1356BB8233740C34E583F7875250996922B83424F8DA0D007C859D040EFD6262,1),(22,'2026-09-20 05:58:52.181000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0022_attachments\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x1356BB8233740C34E583F7875250996922B83424F8DA0D007C859D040EFD6262,0x045194DA45E440A1527CB3E46DE8CC7F54BB22C7B09668E082DBC317AA7B186C,1),(23,'2026-09-20 05:58:52.182000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0023_jobs\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x045194DA45E440A1527CB3E46DE8CC7F54BB22C7B09668E082DBC317AA7B186C,0x0A87E7D3F893E59115487008B7A34973B4C1B95BC7F72FDCB836EDD710BC7D58,1),(24,'2026-09-20 05:58:52.184000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0024_import_jobs\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x0A87E7D3F893E59115487008B7A34973B4C1B95BC7F72FDCB836EDD710BC7D58,0x39E9DB3935F8F11090E3ECBC63402F91484EBCD17716D41AB4A2CE8E593A3537,1),(25,'2026-09-20 05:58:52.185000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0025_export_jobs\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x39E9DB3935F8F11090E3ECBC63402F91484EBCD17716D41AB4A2CE8E593A3537,0xA1935B64BB8FCC12244C2AD292EECB158548182D59B8D4ABD5516DB67BC9B772,1),(26,'2026-09-20 05:58:52.187000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0026_audit_events\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xA1935B64BB8FCC12244C2AD292EECB158548182D59B8D4ABD5516DB67BC9B772,0xE6B0E49A531014EBA00378FF7A1346046C77CD14CBEA0417B39DDDAF93B6A621,1),(27,'2026-09-20 05:58:52.188000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0027_audit_chain_heads\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xE6B0E49A531014EBA00378FF7A1346046C77CD14CBEA0417B39DDDAF93B6A621,0x0F948CD4C9D129E65E51C79052594CB61B68248913E9A1E37FE636AC714C81F1,1),(28,'2026-09-20 05:58:52.190000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0028_audit_events_triggers\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x0F948CD4C9D129E65E51C79052594CB61B68248913E9A1E37FE636AC714C81F1,0x50F4221391DCE3C3FCD338E93D9627762D2791ACE297FDED7ED9D84EAE03BECA,1),(29,'2026-09-20 05:58:52.191000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0029_audit_events_archive\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x50F4221391DCE3C3FCD338E93D9627762D2791ACE297FDED7ED9D84EAE03BECA,0x21E357EF25184B79F519E144BFDC5594C18C1A5DA456E12002A343F83C35DC82,1),(30,'2026-09-20 05:58:52.193000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0030_access_log\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x21E357EF25184B79F519E144BFDC5594C18C1A5DA456E12002A343F83C35DC82,0x83A7858C73A6EFD0675E096D3DE6363CD8B4979C3AB30AB5CFD9DE9062E83AB7,1),(31,'2026-09-20 05:58:52.194000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0031_server_settings\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x83A7858C73A6EFD0675E096D3DE6363CD8B4979C3AB30AB5CFD9DE9062E83AB7,0x4E14525D3A21CFBBF946DA79CDBCD5E0D65AAB7DE2270E5066E45EDB007D4A27,1),(32,'2026-09-20 05:58:52.196000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0032_schema_meta\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x4E14525D3A21CFBBF946DA79CDBCD5E0D65AAB7DE2270E5066E45EDB007D4A27,0x8D66E7770A9110E27987ED8735B24B2EA6315BA6173862949607BE0278FC7D0A,1),(33,'2026-09-20 05:58:52.197000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0033_desktop_releases\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x8D66E7770A9110E27987ED8735B24B2EA6315BA6173862949607BE0278FC7D0A,0x31FB091DF014B632EA48C498B04A3BE635600410DBEAAD4844500A5A65FAA0E9,1),(34,'2026-09-20 05:58:52.199000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0034_grants\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x31FB091DF014B632EA48C498B04A3BE635600410DBEAAD4844500A5A65FAA0E9,0xE5792A7CF3AF927DE1E0CB00BF8A3F705A66C19E6F6EFA64A3599C0AE50C75D5,1),(35,'2026-09-20 05:58:52.201000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0035_oauth_clients\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xE5792A7CF3AF927DE1E0CB00BF8A3F705A66C19E6F6EFA64A3599C0AE50C75D5,0xE7B1B98CC1E0E8BB76DCC22D301A17D529431BCD6B973AF0A9D05DF46C01B378,1),(36,'2026-09-20 05:58:52.202000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0036_oauth_clients_grants\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xE7B1B98CC1E0E8BB76DCC22D301A17D529431BCD6B973AF0A9D05DF46C01B378,0xA7427FC1D10B48132431A7BE8CF91F429D8D58D4D8E6883E01A732BDBCC6FE05,1),(37,'2026-09-20 05:58:52.204000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0037_oauth_consents\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xA7427FC1D10B48132431A7BE8CF91F429D8D58D4D8E6883E01A732BDBCC6FE05,0x8C05D9026ECA5B28121EF2506D31F46F5694F55E3779CF8AB7ED6F3D09F29BF3,1),(38,'2026-09-20 05:58:52.205000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0038_oauth_consents_uq_live\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x8C05D9026ECA5B28121EF2506D31F46F5694F55E3779CF8AB7ED6F3D09F29BF3,0xC4024ADAC4E768D8AE0388320E7EC6AF680FDE41BCDFC657D6A0878864A209FF,1),(39,'2026-09-20 05:58:52.207000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0039_oauth_consents_grants\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xC4024ADAC4E768D8AE0388320E7EC6AF680FDE41BCDFC657D6A0878864A209FF,0xA11260AD1840ADA57A041A2AF30DA452D9682CB46E09C95787F71ABB709FD927,1),(40,'2026-09-20 05:58:52.209000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0040_oauth_consent_vaults\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xA11260AD1840ADA57A041A2AF30DA452D9682CB46E09C95787F71ABB709FD927,0x6D07C1395C0DFC9C924C2A1343F3E928FE91D3F881A57047A3680DE356AA3D26,1),(41,'2026-09-20 05:58:52.210000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0041_oauth_consent_vaults_grants\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x6D07C1395C0DFC9C924C2A1343F3E928FE91D3F881A57047A3680DE356AA3D26,0x476EACB8EDD772A3A0D09F855042F4E222526742C32988F8DD8FB1C9272690AF,1),(42,'2026-09-20 05:58:52.211000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0042_oauth_authorization_codes\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x476EACB8EDD772A3A0D09F855042F4E222526742C32988F8DD8FB1C9272690AF,0x547629FEBB3F615E6D29D0709F2D8A55284099AFF6CD896FD4A0AEB97C989D49,1),(43,'2026-09-20 05:58:52.213000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0043_oauth_authorization_codes_grants\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x547629FEBB3F615E6D29D0709F2D8A55284099AFF6CD896FD4A0AEB97C989D49,0xAD38C661536F571D5600CB7337EF5E9019A14BE6D20022676C1534AA3F7D246E,1),(44,'2026-09-20 05:58:52.215000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0044_oauth_refresh_tokens\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xAD38C661536F571D5600CB7337EF5E9019A14BE6D20022676C1534AA3F7D246E,0x0FAF26B1B8EC8FA8CCB9AA63FD282EABDDE80C5B811DA162192BC997E689EA8A,1),(45,'2026-09-20 05:58:52.216000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0045_oauth_refresh_tokens_grants\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x0FAF26B1B8EC8FA8CCB9AA63FD282EABDDE80C5B811DA162192BC997E689EA8A,0x9926F67A3E7C3DB28ECA12725CD058A5F4DE3222F7A28FB6FD2E10CA397143DF,1),(46,'2026-09-20 05:58:52.218000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0046_access_tokens_oauth_columns\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x9926F67A3E7C3DB28ECA12725CD058A5F4DE3222F7A28FB6FD2E10CA397143DF,0xA06E0B9F5221EF4ECFF79BBC32A8B481FD134C34FE14022FB4608E56CB83693F,1),(47,'2026-09-20 05:58:52.219000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0047_access_tokens_oauth_indexes\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xA06E0B9F5221EF4ECFF79BBC32A8B481FD134C34FE14022FB4608E56CB83693F,0x36CA110B3C521F2CFC4A4130EE25440B4C1DAAF024886BA5090E38C3916E22B3,1),(48,'2026-09-20 05:58:52.220000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0048_access_log_oauth_client\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x36CA110B3C521F2CFC4A4130EE25440B4C1DAAF024886BA5090E38C3916E22B3,0x16CF337B6095E6D22A76DF6BCB2B20AB04C6DA474B10267960F787D03FCF27D4,1),(49,'2026-09-20 05:58:52.222000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0049_admin_users_lock\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x16CF337B6095E6D22A76DF6BCB2B20AB04C6DA474B10267960F787D03FCF27D4,0x7F582D5E0543EB914D6727DC65BD86729B83533ABFE8A494B09F4E784DD940F4,1),(50,'2026-09-20 05:58:52.223000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0050_session_revocation_commands\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x7F582D5E0543EB914D6727DC65BD86729B83533ABFE8A494B09F4E784DD940F4,0xB2DCB4B600B8DA277006A78B4A8467B27A1ECC7373A6B5AA227288176396AD99,1),(51,'2026-09-20 05:58:52.224000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0051_session_revocation_commands_grants\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xB2DCB4B600B8DA277006A78B4A8467B27A1ECC7373A6B5AA227288176396AD99,0xA3E37917D09E5286678836209F35404B95E0CA2C9AE0F5D0C03F2143BFB8F374,1),(52,'2026-09-20 05:58:52.225000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0052_collab_owner_fence\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xA3E37917D09E5286678836209F35404B95E0CA2C9AE0F5D0C03F2143BFB8F374,0x06DF24267730EE9268DC3EC3FE4C56B63E0EC7B6D55E35247E5B1A333B277E02,1),(53,'2026-09-20 05:58:52.227000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0053_collab_owner_fence_grants\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x06DF24267730EE9268DC3EC3FE4C56B63E0EC7B6D55E35247E5B1A333B277E02,0x8CAE4DF56F337DB63F40BBF48CD26A32458F0497374A608C07EC682758A59C8C,1),(54,'2026-09-20 05:58:52.228000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0054_grants_provenance\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0x8CAE4DF56F337DB63F40BBF48CD26A32458F0497374A608C07EC682758A59C8C,0xFAE19F1F702FF66B8690B2335DD7D6B92435CD3963D7586996598D3E472C996C,1),(55,'2026-09-20 05:58:52.230000',1,'server','system.migration.applied','system',NULL,NULL,NULL,'cli',NULL,NULL,NULL,NULL,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"migrate up\", \"request_id\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\"}','{\"name\": \"0055_min_client_version\", \"batch\": \"01a0bd65-5c45-7ecd-a31b-2360efda2811\", \"duration_ms\": null}',0xFAE19F1F702FF66B8690B2335DD7D6B92435CD3963D7586996598D3E472C996C,0x8D08DD47824A02BB3A76F4E9B3055A40BD05BBD73476CA4FE893AEBA8281CEE2,1),(56,'2026-09-20 05:58:54.697000',1,'server','admin.user.created','system',NULL,NULL,NULL,'cli',NULL,NULL,'user',0x01A0BD6567C6713DB701493FACB76D31,NULL,'success',NULL,'{\"host\": \"runnervmlun5p\", \"os_user\": \"runner\", \"argv_shape\": \"admin create-user --email <value> --display-name <value> --server-admin\", \"request_id\": \"01a0bd65-6616-72ea-9b47-7c754d340eb0\"}','{\"displayName\": \"Kernel Admin\", \"isServerAdmin\": true, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0bd65-67d8-7d67-9d87-95f6f7d696f1\"}',0x8D08DD47824A02BB3A76F4E9B3055A40BD05BBD73476CA4FE893AEBA8281CEE2,0x36EA5BCDA26534AA3671BC98A24F48F12E6104624875984BE125EF9E3B6427A6,1),(57,'2026-09-20 05:58:54.951000',1,'server','user.password.set','user',0x01A0BD6567C6713DB701493FACB76D31,NULL,NULL,'setpw',0x01A0BD6567D87D679D8795F6F7D696F1,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-68b5-70e5-85e8-c82ed24541b7\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0x36EA5BCDA26534AA3671BC98A24F48F12E6104624875984BE125EF9E3B6427A6,0x82CE207774380719C837FBF030C461422028DF0AC35827CE04C364CAB8C06866,1),(58,'2026-09-20 05:58:55.026000',1,'server','user.login.succeeded','user',0x01A0BD6567C6713DB701493FACB76D31,'admin@iridium.test',NULL,'session',0x01A0BD6569297EB0950F70E73E0093F9,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-6908-7300-8609-79ad5a1b972c\", \"user_agent\": \"node\"}','{\"kind\": \"web\", \"method\": \"password\", \"clientVersion\": \"0.0.0\"}',0x82CE207774380719C837FBF030C461422028DF0AC35827CE04C364CAB8C06866,0xF060DC3E0499E96BDA14FFD3FFC440C57A25B9446CFCFD87427BF6AFF1EC037E,1),(59,'2026-09-20 05:58:55.082000',1,'server','user.reauth.succeeded','user',0x01A0BD6567C6713DB701493FACB76D31,'admin@iridium.test',NULL,'session',0x01A0BD6569297EB0950F70E73E0093F9,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-6949-745b-a8cb-9a427cbcac9b\", \"user_agent\": \"node\"}','{}',0xF060DC3E0499E96BDA14FFD3FFC440C57A25B9446CFCFD87427BF6AFF1EC037E,0x3EFE81D29D1E0F62BED5DEA86CBB88FD60E9E93F06D0BBEB2190DF7AF4C6663E,1),(60,'2026-09-20 05:58:55.127000',1,'server','admin.user.created','user',0x01A0BD6567C6713DB701493FACB76D31,'Kernel Admin',NULL,'session',0x01A0BD6569297EB0950F70E73E0093F9,NULL,'user',0x01A0BD6569857AC28706556DBE2FF5E7,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-697a-7dc1-8eb4-7b54224d916e\", \"user_agent\": \"node\"}','{\"displayName\": \"editorA\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0bd65-6992-7de0-8422-7bdf0ffb91d9\"}',0x3EFE81D29D1E0F62BED5DEA86CBB88FD60E9E93F06D0BBEB2190DF7AF4C6663E,0xB4BA16E9723C2349300E63612DD3CCCBCF44FA9A36B6AC9FA0580E143E7733A3,1),(61,'2026-09-20 05:58:55.144000',1,'server','admin.user.created','user',0x01A0BD6567C6713DB701493FACB76D31,'Kernel Admin',NULL,'session',0x01A0BD6569297EB0950F70E73E0093F9,NULL,'user',0x01A0BD65698B715895A2150D7C57E924,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-6980-7c47-a05e-4f0e6aeef3ea\", \"user_agent\": \"node\"}','{\"displayName\": \"editorB\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0bd65-69a5-71ca-8adc-7ebcc4b71099\"}',0xB4BA16E9723C2349300E63612DD3CCCBCF44FA9A36B6AC9FA0580E143E7733A3,0x042DC6F03A2DFFCBA3129D48174DBA97D9635EF186811B85555145479E171F40,1),(62,'2026-09-20 05:58:55.156000',1,'server','admin.user.created','user',0x01A0BD6567C6713DB701493FACB76D31,'Kernel Admin',NULL,'session',0x01A0BD6569297EB0950F70E73E0093F9,NULL,'user',0x01A0BD6569957F05A2746F853DA901B3,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-6983-7b28-88fe-724c56f7a697\", \"user_agent\": \"node\"}','{\"displayName\": \"editorC\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0bd65-69b1-7b4d-8094-9f877cd57efb\"}',0x042DC6F03A2DFFCBA3129D48174DBA97D9635EF186811B85555145479E171F40,0x518AE39E19B8CC43DBAABC831588040C50FA6998B600403AA9D7F7DD495A1EDF,1),(63,'2026-09-20 05:58:55.179000',1,'server','admin.user.created','user',0x01A0BD6567C6713DB701493FACB76D31,'Kernel Admin',NULL,'session',0x01A0BD6569297EB0950F70E73E0093F9,NULL,'user',0x01A0BD65699775CCB11E5E3324CE1068,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-6986-7cfa-99ef-45bfd9b3016e\", \"user_agent\": \"node\"}','{\"displayName\": \"viewer\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0bd65-69c6-7174-96f3-01d8e5e46167\"}',0x518AE39E19B8CC43DBAABC831588040C50FA6998B600403AA9D7F7DD495A1EDF,0xBC258DAA8423317917F4D80518812E19A3D48B47A535998E804DAC303D9802C4,1),(64,'2026-09-20 05:58:55.196000',1,'server','user.password.set','user',0x01A0BD6569857AC28706556DBE2FF5E7,NULL,NULL,'setpw',0x01A0BD6569927DE084227BDF0FFB91D9,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-69a3-728b-ada9-87fc7d169dcb\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0xBC258DAA8423317917F4D80518812E19A3D48B47A535998E804DAC303D9802C4,0x771AB2A0BDBEB8EE64987B351FF4C730473C6E07025F36D051150C051C4EB8C5,1),(65,'2026-09-20 05:58:55.208000',1,'server','admin.user.created','user',0x01A0BD6567C6713DB701493FACB76D31,'Kernel Admin',NULL,'session',0x01A0BD6569297EB0950F70E73E0093F9,NULL,'user',0x01A0BD65699F7A329D61AD4BC39A98AB,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-6989-7a7c-9fed-cc2e6af628d4\", \"user_agent\": \"node\"}','{\"displayName\": \"outsider\", \"isServerAdmin\": false, \"membershipCount\": 0, \"setPasswordTokenId\": \"01a0bd65-69e2-7622-9299-54979c8b13f6\"}',0x771AB2A0BDBEB8EE64987B351FF4C730473C6E07025F36D051150C051C4EB8C5,0x509F2BD7963C1A8A83C00E264FF36A2361A2DDB731DF0A9E1B96750C42FE3021,1),(66,'2026-09-20 05:58:55.215000',1,'server','user.password.set','user',0x01A0BD65698B715895A2150D7C57E924,NULL,NULL,'setpw',0x01A0BD6569A571CA8ADC7EBCC4B71099,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-69b0-70ee-97ae-a78bb698076f\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0x509F2BD7963C1A8A83C00E264FF36A2361A2DDB731DF0A9E1B96750C42FE3021,0xD399BC3A6A3E7E6F0AFC370E0325DAAD19C4C67AF6B94587C61B141605F8D3AC,1),(67,'2026-09-20 05:58:55.224000',1,'server','user.password.set','user',0x01A0BD6569957F05A2746F853DA901B3,NULL,NULL,'setpw',0x01A0BD6569B17B4D80949F877CD57EFB,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-69c2-7123-9bdb-41a04abf76ae\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0xD399BC3A6A3E7E6F0AFC370E0325DAAD19C4C67AF6B94587C61B141605F8D3AC,0xAFEECE99623196F2E84858D801E7080A1A5CFB369182060EFE1F903B55743A29,1),(68,'2026-09-20 05:58:55.237000',1,'server','user.password.set','user',0x01A0BD65699775CCB11E5E3324CE1068,NULL,NULL,'setpw',0x01A0BD6569C6717496F301D8E5E46167,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-69e1-7ce6-8718-7b8329159561\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0xAFEECE99623196F2E84858D801E7080A1A5CFB369182060EFE1F903B55743A29,0xA21EA9792A2D18836F4F0586FC8587902220756E6F87EE5BDBADD7BBA4E9B10B,1),(69,'2026-09-20 05:58:55.243000',1,'server','user.password.set','user',0x01A0BD65699F7A329D61AD4BC39A98AB,NULL,NULL,'setpw',0x01A0BD6569E27622929954979C8B13F6,NULL,NULL,NULL,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-69f2-72e4-8227-5ffe54980932\", \"user_agent\": \"node\"}','{\"purpose\": \"initial\"}',0xA21EA9792A2D18836F4F0586FC8587902220756E6F87EE5BDBADD7BBA4E9B10B,0x88D7352B12C0EDC1B5102750C09826F4FCC05003EC64D23ADA9E1F909E285BC5,1),(70,'2026-09-20 05:58:55.259000',1,'vault:01a0bd656a15754fa3f9b8c700ad0be3','vault.created','user',0x01A0BD6567C6713DB701493FACB76D31,'Kernel Admin',NULL,'session',0x01A0BD6569297EB0950F70E73E0093F9,0x01A0BD656A15754FA3F9B8C700AD0BE3,'vault',0x01A0BD656A15754FA3F9B8C700AD0BE3,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-6a10-713c-9987-2fed9177ec40\", \"user_agent\": \"node\"}','{\"name\": \"Kernel\", \"slug\": \"kernel\", \"memberCount\": 0}',0x0000000000000000000000000000000000000000000000000000000000000000,0x1D85CF73FF4724FAB51E7976A7E0325E086A94BAB6D5A5E67AAEFE5AE94526AC,1),(71,'2026-09-20 05:58:55.285000',1,'vault:01a0bd656a15754fa3f9b8c700ad0be3','vault.member.added','user',0x01A0BD6567C6713DB701493FACB76D31,'Kernel Admin',NULL,'session',0x01A0BD6569297EB0950F70E73E0093F9,0x01A0BD656A15754FA3F9B8C700AD0BE3,'user',0x01A0BD6569857AC28706556DBE2FF5E7,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-6a28-7b84-9b87-217368ec817d\", \"user_agent\": \"node\"}','{\"role\": \"editor\", \"targetDisplay\": \"editorA\"}',0x1D85CF73FF4724FAB51E7976A7E0325E086A94BAB6D5A5E67AAEFE5AE94526AC,0x8FA44C3C359E8CAA42752BEE9A0B2648F92871BD898A7D3CAF5708BB2E6C5AE3,1),(72,'2026-09-20 05:58:55.304000',1,'vault:01a0bd656a15754fa3f9b8c700ad0be3','vault.member.added','user',0x01A0BD6567C6713DB701493FACB76D31,'Kernel Admin',NULL,'session',0x01A0BD6569297EB0950F70E73E0093F9,0x01A0BD656A15754FA3F9B8C700AD0BE3,'user',0x01A0BD65698B715895A2150D7C57E924,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-6a3c-7da8-b6c0-17bdfeff36b2\", \"user_agent\": \"node\"}','{\"role\": \"editor\", \"targetDisplay\": \"editorB\"}',0x8FA44C3C359E8CAA42752BEE9A0B2648F92871BD898A7D3CAF5708BB2E6C5AE3,0x876C8F118D59EE65C22BB16BA7D1B549EA8AA276BE57DBD2613126697036FB5D,1),(73,'2026-09-20 05:58:55.318000',1,'vault:01a0bd656a15754fa3f9b8c700ad0be3','vault.member.added','user',0x01A0BD6567C6713DB701493FACB76D31,'Kernel Admin',NULL,'session',0x01A0BD6569297EB0950F70E73E0093F9,0x01A0BD656A15754FA3F9B8C700AD0BE3,'user',0x01A0BD6569957F05A2746F853DA901B3,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-6a4c-735e-aaeb-7b9b974e6ce4\", \"user_agent\": \"node\"}','{\"role\": \"editor\", \"targetDisplay\": \"editorC\"}',0x876C8F118D59EE65C22BB16BA7D1B549EA8AA276BE57DBD2613126697036FB5D,0x30E3866F5B5715C683D29E15586AEF497B169623E11E3E037630E65FCD74CE89,1),(74,'2026-09-20 05:58:55.334000',1,'vault:01a0bd656a15754fa3f9b8c700ad0be3','vault.member.added','user',0x01A0BD6567C6713DB701493FACB76D31,'Kernel Admin',NULL,'session',0x01A0BD6569297EB0950F70E73E0093F9,0x01A0BD656A15754FA3F9B8C700AD0BE3,'user',0x01A0BD65699775CCB11E5E3324CE1068,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-6a5c-75e6-931e-bcab04e89e05\", \"user_agent\": \"node\"}','{\"role\": \"viewer\", \"targetDisplay\": \"viewer\"}',0x30E3866F5B5715C683D29E15586AEF497B169623E11E3E037630E65FCD74CE89,0x6ED3B8A14D23C0DF0A1882332060D9C739086585B5670B1AEE2287A52305328B,1),(75,'2026-09-20 05:58:55.373000',1,'vault:01a0bd656a15754fa3f9b8c700ad0be3','node.created','user',0x01A0BD6567C6713DB701493FACB76D31,'Kernel Admin',NULL,'session',0x01A0BD6569297EB0950F70E73E0093F9,0x01A0BD656A15754FA3F9B8C700AD0BE3,'node',0x01A0BD656A7278A0916159BA07F2E6B7,NULL,'success',NULL,'{\"ip\": \"127.0.0.1\", \"client\": \"web\", \"request_id\": \"01a0bd65-6a6d-7bf5-af81-28d21bfd1552\", \"user_agent\": \"node\"}','{\"kind\": \"note\", \"name\": \"Kernel Note\", \"parentId\": \"01a0bd65-6a15-7550-a66b-07270b6d6405\"}',0x6ED3B8A14D23C0DF0A1882332060D9C739086585B5670B1AEE2287A52305328B,0xD88CCE62FC4EF2C4F29042E0E3C9688178F37803319CEF8DF779CE2E3E5378BE,1);
/*!40000 ALTER TABLE `audit_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_events_archive`
--

DROP TABLE IF EXISTS `audit_events_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_events_archive` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime(6) NOT NULL,
  `schema_version` smallint unsigned NOT NULL DEFAULT '1',
  `chain_id` varchar(40) NOT NULL,
  `action` varchar(64) NOT NULL,
  `actor_type` enum('user','token','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `actor_display` varchar(160) DEFAULT NULL,
  `on_behalf_of_user_id` binary(16) DEFAULT NULL,
  `credential_type` enum('session','pat','oauth','ticket','setpw','cli','system','none') NOT NULL,
  `credential_id` binary(16) DEFAULT NULL,
  `vault_id` binary(16) DEFAULT NULL,
  `target_type` varchar(32) DEFAULT NULL,
  `target_id` binary(16) DEFAULT NULL,
  `targets` json DEFAULT NULL,
  `outcome` enum('success','failure') NOT NULL,
  `reason` varchar(128) DEFAULT NULL,
  `context` json NOT NULL,
  `metadata` json DEFAULT NULL,
  `prev_hash` binary(32) NOT NULL,
  `hash` binary(32) NOT NULL,
  `key_version` tinyint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_audit_chain` (`chain_id`,`id`),
  KEY `ix_audit_vault_time` (`vault_id`,`occurred_at`),
  KEY `ix_audit_actor_time` (`actor_id`,`occurred_at`),
  KEY `ix_audit_action_time` (`action`,`occurred_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_events_archive`
--

LOCK TABLES `audit_events_archive` WRITE;
/*!40000 ALTER TABLE `audit_events_archive` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_events_archive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collab_owner_fence`
--

DROP TABLE IF EXISTS `collab_owner_fence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collab_owner_fence` (
  `id` tinyint unsigned NOT NULL,
  `generation` binary(16) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `chk_collab_owner_fence_singleton` CHECK ((`id` = 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collab_owner_fence`
--

LOCK TABLES `collab_owner_fence` WRITE;
/*!40000 ALTER TABLE `collab_owner_fence` DISABLE KEYS */;
INSERT INTO `collab_owner_fence` VALUES (1,0xEE7B55B16ECF49AD157775D1861C00F2);
/*!40000 ALTER TABLE `collab_owner_fence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `desktop_releases`
--

DROP TABLE IF EXISTS `desktop_releases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `desktop_releases` (
  `version` varchar(32) NOT NULL,
  `channel` enum('stable','beta') NOT NULL,
  `published_at` datetime(6) NOT NULL,
  `published_by` binary(16) DEFAULT NULL,
  `notes` text,
  `files` json NOT NULL,
  `withdrawn_at` datetime(6) DEFAULT NULL,
  `withdrawn_by` binary(16) DEFAULT NULL,
  PRIMARY KEY (`version`,`channel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `desktop_releases`
--

LOCK TABLES `desktop_releases` WRITE;
/*!40000 ALTER TABLE `desktop_releases` DISABLE KEYS */;
/*!40000 ALTER TABLE `desktop_releases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `export_jobs`
--

DROP TABLE IF EXISTS `export_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `export_jobs` (
  `job_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `scope_node_id` binary(16) DEFAULT NULL,
  `format` enum('zip') NOT NULL,
  `restore_eol` tinyint(1) NOT NULL DEFAULT '1',
  `include_attachments` tinyint(1) NOT NULL DEFAULT '1',
  `include_trashed` tinyint(1) NOT NULL DEFAULT '0',
  `manifest` json DEFAULT NULL,
  `artifact_key` varchar(512) DEFAULT NULL,
  `artifact_sha256` binary(32) DEFAULT NULL,
  `size_bytes` bigint unsigned DEFAULT NULL,
  `expires_at` datetime(6) NOT NULL,
  PRIMARY KEY (`job_id`),
  CONSTRAINT `fk_export_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export_jobs`
--

LOCK TABLES `export_jobs` WRITE;
/*!40000 ALTER TABLE `export_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `export_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_jobs`
--

DROP TABLE IF EXISTS `import_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_jobs` (
  `job_id` binary(16) NOT NULL,
  `target_vault_id` binary(16) DEFAULT NULL,
  `target_parent_id` binary(16) DEFAULT NULL,
  `source_kind` enum('zip','files') NOT NULL,
  `source_sha256` binary(32) DEFAULT NULL,
  `staging_key` varchar(512) NOT NULL,
  `phase` enum('uploading','scanning','reported','committing','done','failed','aborted') NOT NULL,
  `report` json DEFAULT NULL,
  `options` json DEFAULT NULL,
  `stats` json DEFAULT NULL,
  `committed_at` datetime(6) DEFAULT NULL,
  `expires_at` datetime(6) NOT NULL,
  PRIMARY KEY (`job_id`),
  CONSTRAINT `fk_import_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_jobs`
--

LOCK TABLES `import_jobs` WRITE;
/*!40000 ALTER TABLE `import_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `import_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` binary(16) NOT NULL,
  `type` varchar(48) NOT NULL,
  `status` enum('queued','running','succeeded','failed','cancelled') NOT NULL,
  `vault_id` binary(16) DEFAULT NULL,
  `requested_by` binary(16) DEFAULT NULL,
  `payload` json NOT NULL,
  `progress` json DEFAULT NULL,
  `result` json DEFAULT NULL,
  `error` text,
  `attempts` tinyint unsigned NOT NULL DEFAULT '0',
  `locked_by` varchar(64) DEFAULT NULL,
  `locked_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `started_at` datetime(6) DEFAULT NULL,
  `finished_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_jobs_status` (`status`,`created_at`),
  KEY `ix_jobs_vault_type` (`vault_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kysely_migration`
--

DROP TABLE IF EXISTS `kysely_migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kysely_migration` (
  `name` varchar(255) NOT NULL,
  `timestamp` varchar(255) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kysely_migration`
--

LOCK TABLES `kysely_migration` WRITE;
/*!40000 ALTER TABLE `kysely_migration` DISABLE KEYS */;
INSERT INTO `kysely_migration` VALUES ('0001_users','2026-09-20T05:58:51.789Z'),('0002_user_credentials','2026-09-20T05:58:51.795Z'),('0003_password_setup_tokens','2026-09-20T05:58:51.800Z'),('0004_sessions','2026-09-20T05:58:51.807Z'),('0005_login_throttle','2026-09-20T05:58:51.809Z'),('0006_vaults','2026-09-20T05:58:51.815Z'),('0007_vault_members','2026-09-20T05:58:51.824Z'),('0008_access_tokens','2026-09-20T05:58:51.831Z'),('0009_access_token_vaults','2026-09-20T05:58:51.838Z'),('0010_nodes','2026-09-20T05:58:51.845Z'),('0011_nodes_uq_sibling','2026-09-20T05:58:51.855Z'),('0012_trash_entries','2026-09-20T05:58:51.859Z'),('0013_notes','2026-09-20T05:58:51.867Z'),('0014_note_docs','2026-09-20T05:58:51.872Z'),('0015_note_updates','2026-09-20T05:58:51.878Z'),('0016_note_revisions','2026-09-20T05:58:51.884Z'),('0017_note_projections','2026-09-20T05:58:51.888Z'),('0018_note_projections_fm_indexes','2026-09-20T05:58:51.897Z'),('0019_note_search','2026-09-20T05:58:51.900Z'),('0020_note_search_fulltext','2026-09-20T05:58:51.914Z'),('0021_note_links','2026-09-20T05:58:51.919Z'),('0022_attachments','2026-09-20T05:58:51.924Z'),('0023_jobs','2026-09-20T05:58:51.927Z'),('0024_import_jobs','2026-09-20T05:58:51.931Z'),('0025_export_jobs','2026-09-20T05:58:51.935Z'),('0026_audit_events','2026-09-20T05:58:51.939Z'),('0027_audit_chain_heads','2026-09-20T05:58:51.941Z'),('0028_audit_events_triggers','2026-09-20T05:58:51.946Z'),('0029_audit_events_archive','2026-09-20T05:58:51.954Z'),('0030_access_log','2026-09-20T05:58:51.960Z'),('0031_server_settings','2026-09-20T05:58:51.962Z'),('0032_schema_meta','2026-09-20T05:58:51.966Z'),('0033_desktop_releases','2026-09-20T05:58:51.968Z'),('0034_grants','2026-09-20T05:58:51.994Z'),('0035_oauth_clients','2026-09-20T05:58:51.998Z'),('0036_oauth_clients_grants','2026-09-20T05:58:52.000Z'),('0037_oauth_consents','2026-09-20T05:58:52.005Z'),('0038_oauth_consents_uq_live','2026-09-20T05:58:52.011Z'),('0039_oauth_consents_grants','2026-09-20T05:58:52.012Z'),('0040_oauth_consent_vaults','2026-09-20T05:58:52.017Z'),('0041_oauth_consent_vaults_grants','2026-09-20T05:58:52.019Z'),('0042_oauth_authorization_codes','2026-09-20T05:58:52.027Z'),('0043_oauth_authorization_codes_grants','2026-09-20T05:58:52.030Z'),('0044_oauth_refresh_tokens','2026-09-20T05:58:52.040Z'),('0045_oauth_refresh_tokens_grants','2026-09-20T05:58:52.042Z'),('0046_access_tokens_oauth_columns','2026-09-20T05:58:52.056Z'),('0047_access_tokens_oauth_indexes','2026-09-20T05:58:52.067Z'),('0048_access_log_oauth_client','2026-09-20T05:58:52.075Z'),('0049_admin_users_lock','2026-09-20T05:58:52.076Z'),('0050_session_revocation_commands','2026-09-20T05:58:52.081Z'),('0051_session_revocation_commands_grants','2026-09-20T05:58:52.083Z'),('0052_collab_owner_fence','2026-09-20T05:58:52.088Z'),('0053_collab_owner_fence_grants','2026-09-20T05:58:52.090Z'),('0054_grants_provenance','2026-09-20T05:58:52.111Z'),('0055_min_client_version','2026-09-20T05:58:52.112Z');
/*!40000 ALTER TABLE `kysely_migration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kysely_migration_lock`
--

DROP TABLE IF EXISTS `kysely_migration_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kysely_migration_lock` (
  `id` varchar(255) NOT NULL,
  `is_locked` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kysely_migration_lock`
--

LOCK TABLES `kysely_migration_lock` WRITE;
/*!40000 ALTER TABLE `kysely_migration_lock` DISABLE KEYS */;
INSERT INTO `kysely_migration_lock` VALUES ('migration_lock',0);
/*!40000 ALTER TABLE `kysely_migration_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_throttle`
--

DROP TABLE IF EXISTS `login_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_throttle` (
  `key` varchar(191) NOT NULL,
  `points` int NOT NULL,
  `expire` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_throttle`
--

LOCK TABLES `login_throttle` WRITE;
/*!40000 ALTER TABLE `login_throttle` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nodes`
--

DROP TABLE IF EXISTS `nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nodes` (
  `id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `parent_id` binary(16) NOT NULL,
  `kind` enum('category','note') NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `live` tinyint GENERATED ALWAYS AS (if((`deleted_at` is null),1,NULL)) VIRTUAL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_by` binary(16) NOT NULL,
  `updated_by` binary(16) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sibling` (`parent_id`,`name`,`live`),
  KEY `ix_nodes_vault_parent` (`vault_id`,`parent_id`,`kind`),
  KEY `ix_nodes_vault_deleted` (`vault_id`,`deleted_at`),
  KEY `ix_nodes_vault_name` (`vault_id`,`name`),
  CONSTRAINT `fk_nodes_parent` FOREIGN KEY (`parent_id`) REFERENCES `nodes` (`id`),
  CONSTRAINT `fk_nodes_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nodes`
--

LOCK TABLES `nodes` WRITE;
/*!40000 ALTER TABLE `nodes` DISABLE KEYS */;
INSERT INTO `nodes` (`id`, `vault_id`, `parent_id`, `kind`, `name`, `deleted_at`, `version`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES (0x01A0BD656A157550A66B07270B6D6405,0x01A0BD656A15754FA3F9B8C700AD0BE3,0x01A0BD656A157550A66B07270B6D6405,'category','',NULL,1,0x01A0BD6567C6713DB701493FACB76D31,0x01A0BD6567C6713DB701493FACB76D31,'2026-09-20 05:58:55.252000','2026-09-20 05:58:55.252000'),(0x01A0BD656A7278A0916159BA07F2E6B7,0x01A0BD656A15754FA3F9B8C700AD0BE3,0x01A0BD656A157550A66B07270B6D6405,'note','Kernel Note',NULL,1,0x01A0BD6567C6713DB701493FACB76D31,0x01A0BD6567C6713DB701493FACB76D31,'2026-09-20 05:58:55.350000','2026-09-20 05:58:55.350000');
/*!40000 ALTER TABLE `nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_docs`
--

DROP TABLE IF EXISTS `note_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_docs` (
  `note_id` binary(16) NOT NULL,
  `head_seq` bigint unsigned NOT NULL DEFAULT '0',
  `snapshot_format` tinyint unsigned NOT NULL DEFAULT '2',
  `yjs_major` tinyint unsigned NOT NULL DEFAULT '13',
  `snapshot` longblob,
  `snapshot_sv` varbinary(4096) DEFAULT NULL,
  `snapshot_through_seq` bigint unsigned NOT NULL DEFAULT '0',
  `snapshot_size` int unsigned NOT NULL DEFAULT '0',
  `snapshot_at` datetime(6) DEFAULT NULL,
  `projected_seq` bigint unsigned NOT NULL DEFAULT '0',
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`note_id`),
  CONSTRAINT `fk_docs_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_docs`
--

LOCK TABLES `note_docs` WRITE;
/*!40000 ALTER TABLE `note_docs` DISABLE KEYS */;
INSERT INTO `note_docs` VALUES (0x01A0BD656A7278A0916159BA07F2E6B7,1,2,13,0x0000059C999BC105000001042825636F6E74656E74E29FA6494D504F52542D4D41524BE29FA7206B65726E656C206E6F74650A071A0101000001010000,0x01DCCCCDE0021A,1,61,'2026-09-20 05:58:55.350000',1,'2026-09-20 05:58:55.350000');
/*!40000 ALTER TABLE `note_docs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_links`
--

DROP TABLE IF EXISTS `note_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `from_note_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `revision` bigint unsigned NOT NULL,
  `ordinal` int unsigned NOT NULL,
  `kind` enum('markdown','image','wikilink','embed','definition') NOT NULL,
  `raw_target` varchar(2048) NOT NULL,
  `resolved_node_id` binary(16) DEFAULT NULL,
  `resolved_attachment_id` binary(16) DEFAULT NULL,
  `fragment` varchar(255) DEFAULT NULL,
  `status` enum('resolved','ambiguous','broken','external') NOT NULL,
  `start_offset` int unsigned NOT NULL,
  `end_offset` int unsigned NOT NULL,
  `line` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_links_from_ordinal` (`from_note_id`,`ordinal`),
  KEY `ix_links_target_node` (`vault_id`,`resolved_node_id`),
  KEY `ix_links_target_attachment` (`resolved_attachment_id`),
  KEY `ix_links_status` (`vault_id`,`status`),
  CONSTRAINT `fk_links_note` FOREIGN KEY (`from_note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_links`
--

LOCK TABLES `note_links` WRITE;
/*!40000 ALTER TABLE `note_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_projections`
--

DROP TABLE IF EXISTS `note_projections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_projections` (
  `note_id` binary(16) NOT NULL,
  `revision` bigint unsigned NOT NULL,
  `markdown` mediumtext NOT NULL,
  `content_hash` binary(32) NOT NULL,
  `heading_title` varchar(255) DEFAULT NULL,
  `frontmatter_raw` text,
  `frontmatter` json DEFAULT NULL,
  `frontmatter_error` varchar(500) DEFAULT NULL,
  `fm_tags` json DEFAULT NULL,
  `fm_aliases` json DEFAULT NULL,
  `headings` json DEFAULT NULL,
  `tasks` json DEFAULT NULL,
  `code_langs` json DEFAULT NULL,
  `obsidian_findings` json DEFAULT NULL,
  `word_count` int unsigned DEFAULT NULL,
  `line_count` int unsigned DEFAULT NULL,
  `status` enum('ok','pending','too_large','too_complex','timeout','error','invalid_content') NOT NULL,
  `pipeline_version` smallint unsigned NOT NULL,
  `projected_at` datetime(6) NOT NULL,
  PRIMARY KEY (`note_id`),
  KEY `ix_proj_pipeline` (`pipeline_version`),
  KEY `ix_proj_fm_tags` ((cast(`fm_tags` as char(64) array))),
  KEY `ix_proj_fm_aliases` ((cast(`fm_aliases` as char(255) array))),
  CONSTRAINT `fk_proj_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_projections`
--

LOCK TABLES `note_projections` WRITE;
/*!40000 ALTER TABLE `note_projections` DISABLE KEYS */;
INSERT INTO `note_projections` VALUES (0x01A0BD656A7278A0916159BA07F2E6B7,1,'⟦IMPORT-MARK⟧ kernel note\n',0xE2E20748D12A460DD24A3772DE532B67556FC3096F8343ED08E01149CF4310DD,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ok',1,'2026-09-20 05:58:55.350000');
/*!40000 ALTER TABLE `note_projections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_revisions`
--

DROP TABLE IF EXISTS `note_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_revisions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `note_id` binary(16) NOT NULL,
  `seq` bigint unsigned NOT NULL,
  `kind` enum('create','import','checkpoint','unload','named','pre_restore','restore','trash') NOT NULL,
  `label` varchar(200) DEFAULT NULL,
  `markdown` mediumtext NOT NULL,
  `content_hash` binary(32) NOT NULL,
  `size_chars` int unsigned NOT NULL,
  `snapshot` longblob,
  `snapshot_format` tinyint unsigned DEFAULT NULL,
  `yjs_major` tinyint unsigned DEFAULT NULL,
  `snapshot_sv` varbinary(4096) DEFAULT NULL,
  `actor_type` enum('user','token','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `restored_from_revision_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_revisions_note_seq_kind` (`note_id`,`seq`,`kind`),
  KEY `ix_revisions_note_created` (`note_id`,`created_at`),
  CONSTRAINT `fk_revisions_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_revisions`
--

LOCK TABLES `note_revisions` WRITE;
/*!40000 ALTER TABLE `note_revisions` DISABLE KEYS */;
INSERT INTO `note_revisions` VALUES (1,0x01A0BD656A7278A0916159BA07F2E6B7,1,'create',NULL,'⟦IMPORT-MARK⟧ kernel note\n',0xE2E20748D12A460DD24A3772DE532B67556FC3096F8343ED08E01149CF4310DD,26,0x0000059C999BC105000001042825636F6E74656E74E29FA6494D504F52542D4D41524BE29FA7206B65726E656C206E6F74650A071A0101000001010000,2,13,0x01DCCCCDE0021A,'user',0x01A0BD6567C6713DB701493FACB76D31,NULL,'2026-09-20 05:58:55.350000');
/*!40000 ALTER TABLE `note_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_search`
--

DROP TABLE IF EXISTS `note_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_search` (
  `note_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body_text` mediumtext NOT NULL,
  `revision` bigint unsigned NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`note_id`),
  KEY `ix_search_vault` (`vault_id`),
  FULLTEXT KEY `ft_note_search` (`title`,`body_text`),
  CONSTRAINT `fk_search_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_search`
--

LOCK TABLES `note_search` WRITE;
/*!40000 ALTER TABLE `note_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_updates`
--

DROP TABLE IF EXISTS `note_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_updates` (
  `note_id` binary(16) NOT NULL,
  `seq` bigint unsigned NOT NULL,
  `update_v1` mediumblob NOT NULL,
  `yjs_major` tinyint unsigned NOT NULL DEFAULT '13',
  `sv_after` varbinary(4096) NOT NULL,
  `actor_type` enum('user','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `session_id` binary(16) DEFAULT NULL,
  `origin` enum('connection','create','import','restore','repair') NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`note_id`,`seq`),
  KEY `ix_updates_created` (`created_at`),
  CONSTRAINT `fk_updates_note` FOREIGN KEY (`note_id`) REFERENCES `notes` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_updates`
--

LOCK TABLES `note_updates` WRITE;
/*!40000 ALTER TABLE `note_updates` DISABLE KEYS */;
INSERT INTO `note_updates` VALUES (0x01A0BD656A7278A0916159BA07F2E6B7,1,0x0101DCCCCDE00200040107636F6E74656E741EE29FA6494D504F52542D4D41524BE29FA7206B65726E656C206E6F74650A00,13,0x01DCCCCDE0021A,'user',0x01A0BD6567C6713DB701493FACB76D31,0x01A0BD6569297EB0950F70E73E0093F9,'create','2026-09-20 05:58:55.350000');
/*!40000 ALTER TABLE `note_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `node_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `initialized_at` datetime(6) DEFAULT NULL,
  `original_eol` enum('lf','crlf','cr','mixed') NOT NULL DEFAULT 'lf',
  `had_bom` tinyint(1) NOT NULL DEFAULT '0',
  `size_chars` int unsigned NOT NULL DEFAULT '0',
  `oversize` tinyint(1) NOT NULL DEFAULT '0',
  `content_invalid` tinyint(1) NOT NULL DEFAULT '0',
  `last_edited_by` binary(16) DEFAULT NULL,
  `last_edited_at` datetime(6) DEFAULT NULL,
  `last_checkpoint_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`node_id`),
  KEY `ix_notes_vault` (`vault_id`),
  CONSTRAINT `fk_notes_node` FOREIGN KEY (`node_id`) REFERENCES `nodes` (`id`),
  CONSTRAINT `fk_notes_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES (0x01A0BD656A7278A0916159BA07F2E6B7,0x01A0BD656A15754FA3F9B8C700AD0BE3,'2026-09-20 05:58:55.350000','lf',0,26,0,0,0x01A0BD6567C6713DB701493FACB76D31,'2026-09-20 05:58:55.350000',NULL,'2026-09-20 05:58:55.350000','2026-09-20 05:58:55.350000');
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_authorization_codes`
--

DROP TABLE IF EXISTS `oauth_authorization_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_authorization_codes` (
  `id` binary(16) NOT NULL,
  `code_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `client_id` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `consent_id` binary(16) NOT NULL,
  `session_id` binary(16) NOT NULL,
  `redirect_uri` varchar(512) NOT NULL,
  `code_challenge` char(43) NOT NULL,
  `code_challenge_method` enum('S256') NOT NULL,
  `resource` varchar(255) NOT NULL,
  `scopes` json NOT NULL,
  `issued_at` datetime(6) NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  `consumed_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_oauth_codes_code_id` (`code_id`),
  KEY `ix_oauth_codes_expires` (`expires_at`),
  KEY `fk_oauth_codes_client` (`client_id`),
  KEY `fk_oauth_codes_user` (`user_id`),
  KEY `fk_oauth_codes_consent` (`consent_id`),
  CONSTRAINT `fk_oauth_codes_client` FOREIGN KEY (`client_id`) REFERENCES `oauth_clients` (`id`),
  CONSTRAINT `fk_oauth_codes_consent` FOREIGN KEY (`consent_id`) REFERENCES `oauth_consents` (`id`),
  CONSTRAINT `fk_oauth_codes_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_authorization_codes`
--

LOCK TABLES `oauth_authorization_codes` WRITE;
/*!40000 ALTER TABLE `oauth_authorization_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_authorization_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_clients` (
  `id` binary(16) NOT NULL,
  `client_id` varchar(512) NOT NULL,
  `registration_kind` enum('cimd','dynamic','manual') NOT NULL,
  `client_name` varchar(120) NOT NULL,
  `client_uri` varchar(512) DEFAULT NULL,
  `logo_uri` varchar(512) DEFAULT NULL,
  `application_type` enum('native','web') NOT NULL,
  `token_endpoint_auth_method` enum('none','client_secret_basic') NOT NULL DEFAULT 'none',
  `client_secret_hash` binary(32) DEFAULT NULL,
  `client_secret_prefix` char(26) DEFAULT NULL,
  `redirect_uris` json NOT NULL,
  `grant_types` json NOT NULL,
  `scopes` json DEFAULT NULL,
  `cimd_document` json DEFAULT NULL,
  `cimd_fetched_at` datetime(6) DEFAULT NULL,
  `cimd_etag` varchar(120) DEFAULT NULL,
  `status` enum('active','disabled') NOT NULL DEFAULT 'active',
  `created_at` datetime(6) NOT NULL,
  `created_by_user_id` binary(16) DEFAULT NULL,
  `last_authorized_at` datetime(6) DEFAULT NULL,
  `disabled_at` datetime(6) DEFAULT NULL,
  `disabled_by` binary(16) DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_oauth_clients_client_id` (`client_id`(191)),
  KEY `ix_oauth_clients_status` (`status`,`created_at`),
  KEY `ix_oauth_clients_unused` (`last_authorized_at`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_consent_vaults`
--

DROP TABLE IF EXISTS `oauth_consent_vaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_consent_vaults` (
  `consent_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  PRIMARY KEY (`consent_id`,`vault_id`),
  KEY `ix_ocv_vault` (`vault_id`),
  CONSTRAINT `fk_ocv_consent` FOREIGN KEY (`consent_id`) REFERENCES `oauth_consents` (`id`),
  CONSTRAINT `fk_ocv_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_consent_vaults`
--

LOCK TABLES `oauth_consent_vaults` WRITE;
/*!40000 ALTER TABLE `oauth_consent_vaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_consent_vaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_consents`
--

DROP TABLE IF EXISTS `oauth_consents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_consents` (
  `id` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `client_id` binary(16) NOT NULL,
  `scopes` json NOT NULL,
  `all_vaults` tinyint(1) NOT NULL DEFAULT '0',
  `admin_owned` tinyint(1) NOT NULL DEFAULT '0',
  `granted_at` datetime(6) NOT NULL,
  `granted_session_id` binary(16) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `last_authorized_at` datetime(6) DEFAULT NULL,
  `revoked_at` datetime(6) DEFAULT NULL,
  `revoked_by` binary(16) DEFAULT NULL,
  `revoke_reason` varchar(120) DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `live_consent_key` varbinary(32) GENERATED ALWAYS AS (if((`revoked_at` is null),concat(`user_id`,`client_id`),NULL)) VIRTUAL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_oauth_consents_live` (`live_consent_key`),
  KEY `ix_oauth_consents_user` (`user_id`,`revoked_at`),
  KEY `ix_oauth_consents_client` (`client_id`,`revoked_at`),
  CONSTRAINT `fk_oauth_consents_client` FOREIGN KEY (`client_id`) REFERENCES `oauth_clients` (`id`),
  CONSTRAINT `fk_oauth_consents_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_consents`
--

LOCK TABLES `oauth_consents` WRITE;
/*!40000 ALTER TABLE `oauth_consents` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_consents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` binary(16) NOT NULL,
  `token_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `family_id` binary(16) NOT NULL,
  `rotated_from_id` binary(16) DEFAULT NULL,
  `client_id` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `consent_id` binary(16) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `scopes` json NOT NULL,
  `issued_at` datetime(6) NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  `absolute_expires_at` datetime(6) NOT NULL,
  `last_used_at` datetime(6) DEFAULT NULL,
  `rotated_at` datetime(6) DEFAULT NULL,
  `revoked_at` datetime(6) DEFAULT NULL,
  `revoke_reason` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_oauth_refresh_token_id` (`token_id`),
  KEY `ix_oauth_refresh_family` (`family_id`,`revoked_at`),
  KEY `ix_oauth_refresh_consent` (`consent_id`,`revoked_at`),
  KEY `ix_oauth_refresh_expires` (`absolute_expires_at`),
  KEY `fk_oauth_refresh_client` (`client_id`),
  KEY `fk_oauth_refresh_user` (`user_id`),
  CONSTRAINT `fk_oauth_refresh_client` FOREIGN KEY (`client_id`) REFERENCES `oauth_clients` (`id`),
  CONSTRAINT `fk_oauth_refresh_consent` FOREIGN KEY (`consent_id`) REFERENCES `oauth_consents` (`id`),
  CONSTRAINT `fk_oauth_refresh_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_setup_tokens`
--

DROP TABLE IF EXISTS `password_setup_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_setup_tokens` (
  `id` binary(16) NOT NULL,
  `token_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `purpose` enum('initial','reset') NOT NULL,
  `issued_by` binary(16) NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  `consumed_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_spl_token_id` (`token_id`),
  KEY `ix_spl_user` (`user_id`,`consumed_at`),
  CONSTRAINT `fk_spl_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_setup_tokens`
--

LOCK TABLES `password_setup_tokens` WRITE;
/*!40000 ALTER TABLE `password_setup_tokens` DISABLE KEYS */;
INSERT INTO `password_setup_tokens` VALUES (0x01A0BD6567D87D679D8795F6F7D696F1,'q2TqUWQ0rDcCUX2t',0xF9FF3112962CE23DE8BCC3C6E7B7EFECE6D83ED7EE04ED6AF8712F2138729346,0x01A0BD6567C6713DB701493FACB76D31,'initial',0x01A0BD6567C6713DB701493FACB76D31,'2026-09-21 05:58:54.676000','2026-09-20 05:58:54.935000','2026-09-20 05:58:54.676000'),(0x01A0BD6569927DE084227BDF0FFB91D9,'wf54tdxSLihislzZ',0xB69B4EF792AC333FD9C061D0C5876E10E339DE68CB5A35C4FC13BDAE1FDC706B,0x01A0BD6569857AC28706556DBE2FF5E7,'initial',0x01A0BD6567C6713DB701493FACB76D31,'2026-09-21 05:58:55.121000','2026-09-20 05:58:55.160000','2026-09-20 05:58:55.121000'),(0x01A0BD6569A571CA8ADC7EBCC4B71099,'xhdiIZzAANDVvsiu',0x6027769EBD49BF7A3A3463D25534300E5FE3F975052D24BED937685145593134,0x01A0BD65698B715895A2150D7C57E924,'initial',0x01A0BD6567C6713DB701493FACB76D31,'2026-09-21 05:58:55.140000','2026-09-20 05:58:55.173000','2026-09-20 05:58:55.140000'),(0x01A0BD6569B17B4D80949F877CD57EFB,'lQcAApL4FOzugLfC',0x3C81F87BFD48B9D188F1BBBDAFA5E95C7F33E2ECCB5570DFE6F93B3CD033406A,0x01A0BD6569957F05A2746F853DA901B3,'initial',0x01A0BD6567C6713DB701493FACB76D31,'2026-09-21 05:58:55.153000','2026-09-20 05:58:55.212000','2026-09-20 05:58:55.153000'),(0x01A0BD6569C6717496F301D8E5E46167,'cMiOkdc3vFjfClXC',0x8E7BA288039798471654DAD62CAF85597A25C31DA4AE0DE7DD3E296D55EACA4B,0x01A0BD65699775CCB11E5E3324CE1068,'initial',0x01A0BD6567C6713DB701493FACB76D31,'2026-09-21 05:58:55.172000','2026-09-20 05:58:55.226000','2026-09-20 05:58:55.172000'),(0x01A0BD6569E27622929954979C8B13F6,'X83bO6RsXUifb8qH',0xE33FB4D0FBC8B4B2940ECDAEB70B13FF389D89CB25D16C643DF81750ECB6F60C,0x01A0BD65699F7A329D61AD4BC39A98AB,'initial',0x01A0BD6567C6713DB701493FACB76D31,'2026-09-21 05:58:55.200000','2026-09-20 05:58:55.230000','2026-09-20 05:58:55.200000');
/*!40000 ALTER TABLE `password_setup_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_meta`
--

DROP TABLE IF EXISTS `schema_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_meta` (
  `key` varchar(32) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_meta`
--

LOCK TABLES `schema_meta` WRITE;
/*!40000 ALTER TABLE `schema_meta` DISABLE KEYS */;
INSERT INTO `schema_meta` VALUES ('acl.access_log','{\"applied\":true,\"fingerprint\":\"3cb05ad81cb510aa65bc7dbff4b59ac9b8ccf070be4480dae6a2e5595271c8f6\"}'),('acl.access_token_vaults','{\"applied\":true,\"fingerprint\":\"68b911e5b92bb9d90846c791c74c40047a7f2da0022ae0da84d51479e9bcb7ca\"}'),('acl.access_tokens','{\"applied\":true,\"fingerprint\":\"bdfbd1c8e849e12264649353fe1032b9ca270a9e2af5ee45657e9031900c1650\"}'),('acl.attachments','{\"applied\":true,\"fingerprint\":\"723b9d57613881d040162ab632e6bcc834243e2f1e2979b1906e61411a230615\"}'),('acl.audit_chain_heads','{\"applied\":true,\"fingerprint\":\"09bbf8d7503aa4e44b7635070bb4954504e8458b2f780659cfdd306c8c035b93\"}'),('acl.audit_events','{\"applied\":true,\"fingerprint\":\"0d021f69a450993d66c44fac10e927a4d92ef76e0e136057361b526fd26eca47\"}'),('acl.audit_events_archive','{\"applied\":true,\"fingerprint\":\"9245bc26a1a2ec7a41c9151dac9b7da67463e5bb0b83f464251e06e58871daa0\"}'),('acl.collab_owner_fence','{\"applied\":true,\"fingerprint\":\"60ca2453617aefa174bbde43d3da8ba7a38f1a42c65e0c271708aa7c129dad22\"}'),('acl.desktop_releases','{\"applied\":true,\"fingerprint\":\"cbe40c21e12c5efc3c74858dfbff81d4f0f7ca072934459d3a630b090054c178\"}'),('acl.export_jobs','{\"applied\":true,\"fingerprint\":\"54166a5f90330c33611fcae2aa1d34ebb8af0e1d597f53c9d6347055c7dc9e32\"}'),('acl.import_jobs','{\"applied\":true,\"fingerprint\":\"8421e3bcf12234ffbb3368c03eead01fb4187039904df4cd17ea9d939e4bef0d\"}'),('acl.jobs','{\"applied\":true,\"fingerprint\":\"aafb728ee85aa56cb620f691a28ed571a95005ebd55b22b441c54ccb4fa20ab6\"}'),('acl.kysely_migration','{\"applied\":true,\"fingerprint\":\"b364934c8871a0572104874fc864b5b764879ddd870006f197615931e34c1c13\"}'),('acl.kysely_migration_lock','{\"applied\":true,\"fingerprint\":\"51021f74746159bf4f61ad5d713f8cb7ea8bdfdc65ec5dafeacc8f7f475000ed\"}'),('acl.login_throttle','{\"applied\":true,\"fingerprint\":\"2e0520a72039d214fe19cd34c5d11e0dbce39b5fa8eaed6217ac654cc1d53ac7\"}'),('acl.nodes','{\"applied\":true,\"fingerprint\":\"7faa7ee251146e70f596a81bfb009b162bcb6a2f33cfbd175c061106cbdf7e2a\"}'),('acl.note_docs','{\"applied\":true,\"fingerprint\":\"9be49954ad662abfe9dfc8eabbbdbd3b297d586171989e37d17f90505b4c8785\"}'),('acl.note_links','{\"applied\":true,\"fingerprint\":\"795c9fdeeafc80d5453f1df962de09d0f04ff3179eff1adb01ff9359ab67b541\"}'),('acl.note_projections','{\"applied\":true,\"fingerprint\":\"186c0c4cd81ee039b9e37b968dbd6961ec67553b898156104aa4382ca5dac89d\"}'),('acl.note_revisions','{\"applied\":true,\"fingerprint\":\"bdc901cf8bae963ea7af081ee1d534f326dc8284153f13fdc6c06233fe4739c9\"}'),('acl.note_search','{\"applied\":true,\"fingerprint\":\"2a051511f38517eadd587824a069abad3ba927b579d251ba184bed5fda603097\"}'),('acl.note_updates','{\"applied\":true,\"fingerprint\":\"071dc16dfecb9daf0acc7016c61e7f991e1da36441aaeb3877cd23fe256aa5d6\"}'),('acl.notes','{\"applied\":true,\"fingerprint\":\"d771b524137a6d8a634d3bf770b3c76c3d7ff7319ee57f4ca910a8aa2147b08b\"}'),('acl.oauth_authorization_codes','{\"applied\":true,\"fingerprint\":\"977d39eee4d1ac6af76a1a92430c602c949684ce05955506006c990741f003b1\"}'),('acl.oauth_clients','{\"applied\":true,\"fingerprint\":\"24b77335f71aeb6a23bf71d70cff6f4829329fe1147a2897d8dc0d618a1bb7f4\"}'),('acl.oauth_consent_vaults','{\"applied\":true,\"fingerprint\":\"caed8e3500fefa0e34df565008eb71ce930b2916acb44e62883a59a2f9c7a247\"}'),('acl.oauth_consents','{\"applied\":true,\"fingerprint\":\"0e644943db192f7ea9a12a09071c93e567fb1913a46cc11eb10eb2f3ab510d7d\"}'),('acl.oauth_refresh_tokens','{\"applied\":true,\"fingerprint\":\"58e7d98d6b9e595a600b6f0b59e37d31bec0ab3b422bedbb1048e70d137e9601\"}'),('acl.password_setup_tokens','{\"applied\":true,\"fingerprint\":\"338280c5b6e7046d97b1b3c8589c607af96c616c9752ee5be8013b979b85b30c\"}'),('acl.schema_meta','{\"applied\":true,\"fingerprint\":\"cb7265c4a3f24d38872b9828716c27551bbc2d0b52211d0e8761e21f4e72b444\"}'),('acl.server_settings','{\"applied\":true,\"fingerprint\":\"eb4ea243f596142a9657008af4eca3f17ea41288b4c5ccf0f1387ea847ae768c\"}'),('acl.session_revocation_commands','{\"applied\":true,\"fingerprint\":\"04105afeb1b1103d05ee6888550001576396cd8c51186fb443ba1463a5780553\"}'),('acl.sessions','{\"applied\":true,\"fingerprint\":\"4f8066e4177db802da539b9bfc1de4a4c62f5008d9fc9cf3ed33d85c5eb268bf\"}'),('acl.trash_entries','{\"applied\":true,\"fingerprint\":\"4e72de20258f7e35a7420323888ca6bbd7b9e1af1ed2d51fc9adf75e7df09f3b\"}'),('acl.user_credentials','{\"applied\":true,\"fingerprint\":\"d31f8e8409ed598603f5811ac676fb89c3cad26d913de7ce31989b9272338d67\"}'),('acl.users','{\"applied\":true,\"fingerprint\":\"a2927f57314bc380d4a91c1b106ccc1b94fadfbb27f320ac08e04020245cdb48\"}'),('acl.vault_members','{\"applied\":true,\"fingerprint\":\"def08bb5a1358fdf86c7057558280e72987b5503eed056d5ef3f6d0eae7e5f35\"}'),('acl.vaults','{\"applied\":true,\"fingerprint\":\"1af3101abc5ec86fbf8d7bdf5acb316c454d5a2a0892713d256b7e80e05637f8\"}'),('admin_users_lock','1'),('api_version','1'),('attachment_key_version','1'),('audit_key_version','1'),('cursor_key_version','1'),('iridium_version','0.0.0'),('min_client_version','0.0.0'),('pepper_version','1'),('pipeline_version','1');
/*!40000 ALTER TABLE `schema_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server_settings`
--

DROP TABLE IF EXISTS `server_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `server_settings` (
  `key` varchar(64) NOT NULL,
  `value` json NOT NULL,
  `updated_by` binary(16) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server_settings`
--

LOCK TABLES `server_settings` WRITE;
/*!40000 ALTER TABLE `server_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `server_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_revocation_commands`
--

DROP TABLE IF EXISTS `session_revocation_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session_revocation_commands` (
  `id` binary(16) NOT NULL,
  `user_id` binary(16) DEFAULT NULL,
  `actor_type` enum('user','token','system') NOT NULL,
  `actor_id` binary(16) DEFAULT NULL,
  `actor_display` varchar(120) DEFAULT NULL,
  `context` json NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `result` json DEFAULT NULL,
  `delivered_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_session_commands_pending` (`delivered_at`,`created_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_revocation_commands`
--

LOCK TABLES `session_revocation_commands` WRITE;
/*!40000 ALTER TABLE `session_revocation_commands` DISABLE KEYS */;
/*!40000 ALTER TABLE `session_revocation_commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` binary(16) NOT NULL,
  `token_id` char(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `secret_hash` binary(32) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `kind` enum('web','desktop') NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `last_seen_at` datetime(6) NOT NULL,
  `idle_expires_at` datetime(6) NOT NULL,
  `absolute_expires_at` datetime(6) NOT NULL,
  `last_authenticated_at` datetime(6) NOT NULL,
  `mfa_verified_at` datetime(6) DEFAULT NULL,
  `ip` varbinary(16) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `client_name` varchar(64) DEFAULT NULL,
  `device_name` varchar(120) DEFAULT NULL,
  `client_version` varchar(32) DEFAULT NULL,
  `revoked_at` datetime(6) DEFAULT NULL,
  `revoked_reason` enum('logout','admin','password_change','user_disabled','expired','replaced') DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sessions_token_id` (`token_id`),
  KEY `ix_sessions_user` (`user_id`,`revoked_at`),
  KEY `ix_sessions_absolute` (`absolute_expires_at`),
  CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (0x01A0BD6569297EB0950F70E73E0093F9,'TurGToKSvn50OBM4',0xF7098508B166D6101B08E46D3653D58A1FA9F45C825BBDC36E1D07A40203BE91,0x01A0BD6567C6713DB701493FACB76D31,'web','2026-09-20 05:58:55.013000','2026-09-20 05:58:55.013000','2026-09-21 05:58:55.013000','2026-10-04 05:58:55.013000','2026-09-20 05:58:55.071000',NULL,0x7F000001,'node','web',NULL,'0.0.0',NULL,NULL);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trash_entries`
--

DROP TABLE IF EXISTS `trash_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trash_entries` (
  `node_id` binary(16) NOT NULL,
  `vault_id` binary(16) NOT NULL,
  `cascade_root_id` binary(16) NOT NULL,
  `deleted_by` binary(16) NOT NULL,
  `deleted_at` datetime(6) NOT NULL,
  `original_parent_id` binary(16) NOT NULL,
  `original_path` text NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  PRIMARY KEY (`node_id`),
  KEY `ix_trash_vault_expires` (`vault_id`,`expires_at`),
  KEY `ix_trash_vault_root` (`vault_id`,`cascade_root_id`),
  CONSTRAINT `fk_trash_node` FOREIGN KEY (`node_id`) REFERENCES `nodes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trash_entries`
--

LOCK TABLES `trash_entries` WRITE;
/*!40000 ALTER TABLE `trash_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `trash_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_credentials`
--

DROP TABLE IF EXISTS `user_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_credentials` (
  `user_id` binary(16) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `pepper_version` tinyint unsigned NOT NULL,
  `password_changed_at` datetime(6) NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_cred_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_credentials`
--

LOCK TABLES `user_credentials` WRITE;
/*!40000 ALTER TABLE `user_credentials` DISABLE KEYS */;
INSERT INTO `user_credentials` VALUES (0x01A0BD6567C6713DB701493FACB76D31,'$argon2id$v=19$m=8192,t=1,p=1$Sv4B9hkdL4S+tmqxkj6DyA$hF1mcVNZpDzode9UC7cARwi1/NBIE+UZ2/Bj3Qsm8PM',1,'2026-09-20 05:58:54.935000'),(0x01A0BD6569857AC28706556DBE2FF5E7,'$argon2id$v=19$m=8192,t=1,p=1$dAHKwtunR+F+M+Amg+oYtw$HLrflkPUc5t4UqmwjsltATPZkdQS/iwDcgZ1oB2oExo',1,'2026-09-20 05:58:55.160000'),(0x01A0BD65698B715895A2150D7C57E924,'$argon2id$v=19$m=8192,t=1,p=1$baSD7sq5yzoQNF+NkNnG3Q$yBgnwVS45kjLnsjeL6XBsbns99nk6phT4Z/KIHGEi5I',1,'2026-09-20 05:58:55.173000'),(0x01A0BD6569957F05A2746F853DA901B3,'$argon2id$v=19$m=8192,t=1,p=1$BSk8AnWwtKk2cIOIRCwohw$/hDnNSYUmcrRGnVmR1ZHjKxyBKNwkTaslRN8pb9M1sM',1,'2026-09-20 05:58:55.212000'),(0x01A0BD65699775CCB11E5E3324CE1068,'$argon2id$v=19$m=8192,t=1,p=1$Jgc7ZugpslnH96oEOVOl6g$D1y8LtE77FdsRb5Q8DvfUQzMvbr/N49OBALgoslaw7c',1,'2026-09-20 05:58:55.226000'),(0x01A0BD65699F7A329D61AD4BC39A98AB,'$argon2id$v=19$m=8192,t=1,p=1$w4i0/fvBndPldYLDO8Z1qA$GLtA6H1reTEPUBt1n7W32mfwwBZi/dW65x6C1tkcqBc',1,'2026-09-20 05:58:55.230000');
/*!40000 ALTER TABLE `user_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` binary(16) NOT NULL,
  `email` varchar(320) NOT NULL,
  `email_key` varchar(320) GENERATED ALWAYS AS (lower(`email`)) STORED,
  `display_name` varchar(120) NOT NULL,
  `is_server_admin` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('active','disabled','deleted') NOT NULL DEFAULT 'active',
  `color_hue` smallint unsigned NOT NULL,
  `authz_version` int unsigned NOT NULL DEFAULT '1',
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `last_login_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email_key` (`email_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `email`, `display_name`, `is_server_admin`, `status`, `color_hue`, `authz_version`, `version`, `created_at`, `updated_at`, `last_login_at`) VALUES (0x01A0BD6567C6713DB701493FACB76D31,'admin@iridium.test','Kernel Admin',1,'active',0,2,1,'2026-09-20 05:58:54.662000','2026-09-20 05:58:54.935000','2026-09-20 05:58:55.013000'),(0x01A0BD6569857AC28706556DBE2FF5E7,'editorA@iridium.test','editorA',0,'active',138,3,1,'2026-09-20 05:58:55.109000','2026-09-20 05:58:55.277000',NULL),(0x01A0BD65698B715895A2150D7C57E924,'editorB@iridium.test','editorB',0,'active',275,3,1,'2026-09-20 05:58:55.115000','2026-09-20 05:58:55.298000',NULL),(0x01A0BD6569957F05A2746F853DA901B3,'editorC@iridium.test','editorC',0,'active',53,3,1,'2026-09-20 05:58:55.125000','2026-09-20 05:58:55.311000',NULL),(0x01A0BD65699775CCB11E5E3324CE1068,'viewer@iridium.test','viewer',0,'active',190,3,1,'2026-09-20 05:58:55.127000','2026-09-20 05:58:55.329000',NULL),(0x01A0BD65699F7A329D61AD4BC39A98AB,'outsider@iridium.test','outsider',0,'active',328,2,1,'2026-09-20 05:58:55.135000','2026-09-20 05:58:55.230000',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vault_members`
--

DROP TABLE IF EXISTS `vault_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vault_members` (
  `vault_id` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `role` enum('viewer','editor','manager') NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `granted_by` binary(16) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`vault_id`,`user_id`),
  KEY `ix_members_user` (`user_id`),
  CONSTRAINT `fk_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_members_vault` FOREIGN KEY (`vault_id`) REFERENCES `vaults` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vault_members`
--

LOCK TABLES `vault_members` WRITE;
/*!40000 ALTER TABLE `vault_members` DISABLE KEYS */;
INSERT INTO `vault_members` VALUES (0x01A0BD656A15754FA3F9B8C700AD0BE3,0x01A0BD6569857AC28706556DBE2FF5E7,'editor',1,0x01A0BD6567C6713DB701493FACB76D31,'2026-09-20 05:58:55.277000','2026-09-20 05:58:55.277000'),(0x01A0BD656A15754FA3F9B8C700AD0BE3,0x01A0BD65698B715895A2150D7C57E924,'editor',1,0x01A0BD6567C6713DB701493FACB76D31,'2026-09-20 05:58:55.298000','2026-09-20 05:58:55.298000'),(0x01A0BD656A15754FA3F9B8C700AD0BE3,0x01A0BD6569957F05A2746F853DA901B3,'editor',1,0x01A0BD6567C6713DB701493FACB76D31,'2026-09-20 05:58:55.311000','2026-09-20 05:58:55.311000'),(0x01A0BD656A15754FA3F9B8C700AD0BE3,0x01A0BD65699775CCB11E5E3324CE1068,'viewer',1,0x01A0BD6567C6713DB701493FACB76D31,'2026-09-20 05:58:55.329000','2026-09-20 05:58:55.329000');
/*!40000 ALTER TABLE `vault_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vaults`
--

DROP TABLE IF EXISTS `vaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vaults` (
  `id` binary(16) NOT NULL,
  `name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci NOT NULL,
  `slug` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `root_node_id` binary(16) DEFAULT NULL,
  `status` enum('importing','active','archived','deleting') NOT NULL DEFAULT 'active',
  `archived_at` datetime(6) DEFAULT NULL,
  `markdown_flavor` enum('gfm','obsidian-compat') NOT NULL DEFAULT 'gfm',
  `soft_breaks` tinyint(1) NOT NULL DEFAULT '0',
  `attachment_folder` varchar(255) NOT NULL DEFAULT 'attachments',
  `load_external_images` enum('never','click','always') NOT NULL DEFAULT 'click',
  `mcp_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `ai_guidance` text,
  `trash_retention_days` smallint unsigned NOT NULL DEFAULT '30',
  `auto_checkpoint_interval_min` smallint unsigned NOT NULL DEFAULT '10',
  `tree_version` bigint unsigned NOT NULL DEFAULT '0',
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_by` binary(16) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vaults_name` (`name`),
  UNIQUE KEY `uq_vaults_slug` (`slug`),
  KEY `ix_vaults_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vaults`
--

LOCK TABLES `vaults` WRITE;
/*!40000 ALTER TABLE `vaults` DISABLE KEYS */;
INSERT INTO `vaults` VALUES (0x01A0BD656A15754FA3F9B8C700AD0BE3,'Kernel','kernel',NULL,0x01A0BD656A157550A66B07270B6D6405,'active',NULL,'gfm',0,'attachments','click',1,NULL,30,10,1,1,0x01A0BD6567C6713DB701493FACB76D31,'2026-09-20 05:58:55.252000','2026-09-20 05:58:55.370000');
/*!40000 ALTER TABLE `vaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'iridium'
--

--
-- Dumping routines for database 'iridium'
--
--
-- WARNING: can't read the INFORMATION_SCHEMA.libraries table. It's most probably an old server 8.4.11.
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-20  5:58:59
